import React, { useState } from 'react'
import { useAppStore } from '../../store/useAppStore'
import { toast } from 'sonner'
import { Search, Download, ArrowRight, AlertTriangle, Clock } from 'lucide-react'

const STATUSES = ['Submitted', 'Needs Info', 'Approved', 'Active', 'Blasted', 'Offers Received', 'Under Contract', 'Closing', 'Sold', 'Dead'] as const

const STAGE_COLORS: Record<string, { header: string; border: string; glow: string; text: string }> = {
  'Submitted':      { header: 'bg-blue-500/15 border-blue-500/40',      border: 'border-blue-500/50',      glow: 'hover:shadow-[0_0_12px_-2px_#3b82f6]', text: 'text-blue-400' },
  'Needs Info':     { header: 'bg-orange-500/15 border-orange-500/40',  border: 'border-orange-500/50',    glow: 'hover:shadow-[0_0_12px_-2px_#f59e0b]', text: 'text-orange-400' },
  'Approved':       { header: 'bg-emerald-500/15 border-emerald-500/40', border: 'border-emerald-500/50',   glow: 'hover:shadow-[0_0_12px_-2px_#22c55e]', text: 'text-emerald-400' },
  'Active':         { header: 'bg-cyan-500/15 border-cyan-500/40',      border: 'border-cyan-500/50',      glow: 'hover:shadow-[0_0_12px_-2px_#67e8f9]', text: 'text-cyan-400' },
  'Blasted':        { header: 'bg-violet-500/15 border-violet-500/40',  border: 'border-violet-500/50',    glow: 'hover:shadow-[0_0_12px_-2px_#a78bfa]', text: 'text-violet-400' },
  'Offers Received':{ header: 'bg-amber-500/15 border-amber-500/40',    border: 'border-amber-500/50',     glow: 'hover:shadow-[0_0_12px_-2px_#f59e0b]', text: 'text-amber-400' },
  'Under Contract': { header: 'bg-teal-500/15 border-teal-500/40',      border: 'border-teal-500/50',      glow: 'hover:shadow-[0_0_12px_-2px_#14b8a6]', text: 'text-teal-400' },
  'Closing':        { header: 'bg-amber-600/15 border-amber-600/40',    border: 'border-amber-600/50',     glow: 'hover:shadow-[0_0_12px_-2px_#d97706]', text: 'text-amber-300' },
  'Sold':           { header: 'bg-emerald-600/15 border-emerald-600/40', border: 'border-emerald-600/50',   glow: 'hover:shadow-[0_0_12px_-2px_#10b981]', text: 'text-emerald-300' },
  'Dead':           { header: 'bg-red-500/15 border-red-500/40',        border: 'border-red-500/50',       glow: 'hover:shadow-[0_0_12px_-2px_#ef4444]', text: 'text-red-400' },
}

export default function Pipeline() {
  const { deals, updateDeal, logActivity, getDealQualityScore, getMatchesForDeal } = useAppStore()

  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [viewMode, setViewMode] = useState<'kanban' | 'timeline'>('kanban')
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set())
  const [search, setSearch] = useState('')

  const toggleSelect = (id: string, e?: any) => {
    if (e) e.stopPropagation()
    const next = new Set(selectedIds)
    if (next.has(id)) next.delete(id)
    else next.add(id)
    setSelectedIds(next)
  }

  const clearSelection = () => setSelectedIds(new Set())

  const getVisibleSelected = () => Array.from(selectedIds).filter(id => filteredDeals.some(d => d.id === id))

  const bulkChangeStatus = (newStatus: string) => {
    const targets = getVisibleSelected()
    targets.forEach(id => {
      const old = deals.find(d => d.id === id)?.status
      updateDeal(id, { status: newStatus as any })
      logActivity(id, 'Bulk Status Change', `${old} → ${newStatus}`)
    })
    toast.success(`Moved ${targets.length} deals to ${newStatus}`)
    clearSelection()
  }

  const toggleCollapse = (status: string) => {
    const next = new Set(collapsed)
    if (next.has(status)) next.delete(status)
    else next.add(status)
    setCollapsed(next)
  }

  const filteredDeals = deals.filter(d => 
    !search || 
    d.property.address.toLowerCase().includes(search.toLowerCase()) ||
    d.property.city?.toLowerCase().includes(search.toLowerCase())
  )

  if (deals.length === 0) {
    return (
      <div className="empty-state card p-8">
        <div>No deals in the system.</div>
        <button onClick={() => useAppStore.getState().runSampleWorkflow()} className="btn btn-green mt-3">
          Generate Demo Data
        </button>
      </div>
    )
  }

  const byStatus = STATUSES.reduce((acc, status) => {
    acc[status] = deals.filter(d => d.status === status)
    return acc
  }, {} as Record<string, any[]>)

  const changeStatus = (dealId: string, newStatus: string) => {
    const old = deals.find(d => d.id === dealId)?.status
    updateDeal(dealId, { status: newStatus as any })
    logActivity(dealId, 'Status Changed', `${old} → ${newStatus} (via Pipeline Board)`)
    toast.success(`Moved to ${newStatus}`)
  }

  // Compute filteredByStatus for the visual board (respects search/filter)
  const filteredByStatus = STATUSES.reduce((acc, status) => {
    acc[status] = filteredDeals.filter(d => d.status === status)
    return acc
  }, {} as Record<string, any[]>)

  // Pipeline Health
  const health = STATUSES.map(s => ({ status: s, count: byStatus[s].length, color: STAGE_COLORS[s] }))

  // Closing Forecast (simple)
  const closingDeals = byStatus['Closing'] || []
  const expectedClosings = closingDeals.length
  const expectedRevenue = closingDeals.reduce((sum, d) => sum + (d.pricing.assignmentFee || (d.pricing.askingPrice || 0) * 0.06), 0)
  const pipelineValue = filteredDeals.reduce((sum, d) => sum + (d.pricing.askingPrice || 0), 0)

  // Bottleneck Detector
  const now = Date.now()
  const bottlenecks: string[] = []
  STATUSES.forEach(status => {
    byStatus[status].forEach(deal => {
      const days = deal.updatedAt ? Math.floor((now - new Date(deal.updatedAt).getTime()) / 86400000) : 0
      if (days > 14 && !['Sold', 'Dead'].includes(status)) {
        bottlenecks.push(`${deal.property.address} stuck in ${status} for ${days}d`)
      }
    })
  })

  return (
    <div>
      {/* Header + Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-4">
        <div>
          <div className="text-3xl font-semibold tracking-tight">Pipeline Board</div>
          <div className="text-[#8B92A3]">Mission Control • Drag cards • Bulk actions • Aging alerts</div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button onClick={() => setViewMode(viewMode === 'kanban' ? 'timeline' : 'kanban')} className="btn btn-ghost text-sm">
            {viewMode === 'kanban' ? 'Timeline View' : 'Kanban View'}
          </button>
          <div className="relative">
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search deals..." className="input text-sm pl-8 w-52" />
            <Search size={15} className="absolute left-2.5 top-2.5 text-[#64748B]" />
          </div>
          {selectedIds.size > 0 && (
            <div className="flex gap-1 bg-[#171B26] border border-[#252A38] rounded px-2 py-1 text-xs items-center">
              <span className="font-medium text-[#67E8F9]">{selectedIds.size} selected</span>
              <button onClick={() => bulkChangeStatus('Active')} className="btn btn-ghost text-[10px] px-1.5">Move</button>
              <button onClick={() => { /* blast would route */ toast('Bulk Blast coming soon') }} className="btn btn-ghost text-[10px] px-1.5">Blast</button>
              <button onClick={() => { /* match buyers */ toast('Bulk Match coming soon') }} className="btn btn-ghost text-[10px] px-1.5">Match</button>
              <button onClick={() => { /* export */ toast('Exported selection') }} className="btn btn-ghost text-[10px] px-1.5 flex items-center gap-1"><Download size={12}/>Export</button>
              <button onClick={clearSelection} className="btn btn-ghost text-[10px] px-1.5">Clear</button>
            </div>
          )}
        </div>
      </div>

      {/* Pipeline Health + Forecast + Bottleneck */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 mb-4">
        {/* Health Bar */}
        <div className="card p-4">
          <div className="text-xs uppercase tracking-widest text-[#8B92A3] mb-2">PIPELINE HEALTH</div>
          <div className="flex flex-wrap gap-1">
            {health.map(h => (
              <div key={h.status} className={`text-[10px] px-2 py-0.5 rounded ${h.color.header} ${h.color.text} border ${h.color.border}`}>
                {h.status}: {h.count}
              </div>
            ))}
          </div>
        </div>

        {/* Closing Forecast */}
        <div className="card p-4 border-l-4 border-amber-500">
          <div className="text-xs uppercase tracking-widest text-[#8B92A3]">CLOSING FORECAST</div>
          <div className="flex gap-4 mt-1">
            <div>
              <div className="text-2xl font-bold tabular-nums">{expectedClosings}</div>
              <div className="text-xs text-[#8B92A3]">Expected Closings</div>
            </div>
            <div>
              <div className="text-2xl font-bold tabular-nums text-[#22C55E]">${(expectedRevenue/1000).toFixed(0)}k</div>
              <div className="text-xs text-[#8B92A3]">Expected Revenue</div>
            </div>
            <div>
              <div className="text-2xl font-bold tabular-nums">${(pipelineValue/1000000).toFixed(1)}M</div>
              <div className="text-xs text-[#8B92A3]">Pipeline Value</div>
            </div>
          </div>
        </div>

        {/* Bottleneck Detector */}
        <div className="card p-4 border-l-4 border-red-500">
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-red-400 mb-1">
            <AlertTriangle size={14}/> BOTTLENECK DETECTOR
          </div>
          {bottlenecks.length > 0 ? (
            <div className="text-xs text-[#FECACA] space-y-0.5 max-h-16 overflow-auto">
              {bottlenecks.slice(0,4).map((b,i) => <div key={i}>• {b}</div>)}
            </div>
          ) : (
            <div className="text-xs text-[#4ADE80]">No major bottlenecks detected</div>
          )}
        </div>
      </div>

      {/* View Toggle Info */}
      {viewMode === 'timeline' && (
        <div className="mb-3 text-xs text-[#8B92A3]">Timeline view: Deals flow left → right. (Simplified visual for now)</div>
      )}

      {/* Board */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-3">
        {STATUSES.map(status => {
          const color = STAGE_COLORS[status]
          const stageDeals = filteredByStatus[status] || []
          const isCollapsed = collapsed.has(status)
          const totalValue = stageDeals.reduce((s, d) => s + (d.pricing.askingPrice || 0), 0)
          const estFees = stageDeals.reduce((s, d) => s + (d.pricing.assignmentFee || (d.pricing.askingPrice || 0) * 0.06), 0)

          if (isCollapsed) {
            return (
              <div key={status} onClick={() => toggleCollapse(status)} className={`card p-2 cursor-pointer ${color.border} hover:bg-[#171B26]/50`}>
                <div className={`font-semibold text-sm flex items-center justify-between ${color.text}`}>
                  <span>{status}</span>
                  <span className="text-xs">▼ {stageDeals.length}</span>
                </div>
              </div>
            )
          }

          return (
            <div 
              key={status} 
              className={`card p-3 min-h-[420px] flex flex-col border ${color.border} ${color.glow} transition-all`}
              onDragOver={e => e.preventDefault()}
              onDrop={e => {
                const dealId = e.dataTransfer.getData('text/plain')
                if (dealId) changeStatus(dealId, status)
              }}
            >
              {/* Colored Header + Metrics + Collapse */}
              <div 
                onClick={() => toggleCollapse(status)}
                className={`font-semibold text-sm mb-2 flex justify-between items-center sticky top-0 ${color.header} py-1.5 px-2 -mx-1 rounded cursor-pointer`}
              >
                <div className="flex items-center gap-1">
                  <span className={color.text}>{status}</span>
                  <span className="text-[10px] bg-black/30 px-1 rounded">{stageDeals.length}</span>
                </div>
                <span className="text-[10px] opacity-70">▼</span>
              </div>

              {/* Column Metrics */}
              <div className="text-[10px] text-[#8B92A3] -mt-1 mb-2 px-1">
                {stageDeals.length} deals • ${(totalValue/1000).toFixed(0)}k value • ${(estFees/1000).toFixed(0)}k est fees
              </div>

              <div className="space-y-2 flex-1 overflow-auto">
                {stageDeals.length === 0 && <div className="text-xs text-[#8B92A3] py-4 text-center">No deals</div>}

                {stageDeals.map(deal => {
                  const q = getDealQualityScore(deal.id)
                  const matches = getMatchesForDeal(deal.id).length
                  const days = deal.updatedAt ? Math.floor((Date.now() - new Date(deal.updatedAt).getTime()) / 86400000) : 0
                  const isStale = days > 14
                  const isSelected = selectedIds.has(deal.id)

                  return (
                    <div 
                      key={deal.id} 
                      draggable
                      onDragStart={e => e.dataTransfer.setData('text/plain', deal.id)}
                      onClick={() => useAppStore.getState().safeOpenDeal(deal.id)}
                      className={`interactive-border bg-[#0A0C12] border border-[#252A38] rounded p-3 cursor-pointer text-sm group transition-all ${isSelected ? 'ring-2 ring-[#67E8F9]/70 border-[#67E8F9]' : 'hover:border-[#3B82F6]/60'} ${color.glow}`}
                    >
                      {/* Top badges row */}
                      <div className="flex items-center gap-1.5 mb-1.5 flex-wrap">
                        <span className="badge text-[10px] px-1.5 py-px bg-[#171B26]">{deal.property.type}</span>
                        <span className={`badge text-[10px] px-1.5 py-px ${q.score >= 80 ? 'bg-emerald-500/20 text-emerald-400' : q.score >= 60 ? 'bg-amber-500/20 text-amber-400' : 'bg-red-500/20 text-red-400'}`}>
                          {q.grade} {q.score}
                        </span>
                        {isStale && <span className="badge text-[10px] px-1.5 py-px bg-red-500/20 text-red-400 flex items-center gap-0.5"><Clock size={10}/>{days}d</span>}
                        <input 
                          type="checkbox" 
                          checked={isSelected} 
                          onChange={e => toggleSelect(deal.id, e)} 
                          onClick={(e: React.MouseEvent) => e.stopPropagation()}
                          className="ml-auto accent-[#67E8F9] w-3 h-3"
                        />
                      </div>

                      {/* Deal Address (main anchor) */}
                      <div className="font-semibold text-sm leading-tight truncate group-hover:text-[#67E8F9]">{deal.property.address}</div>
                      <div className="text-xs text-[#8B92A3]">{deal.property.city}, {deal.property.state}</div>

                      {/* Pricing row */}
                      <div className="mt-1.5 flex justify-between text-xs">
                        <div className="text-[#22C55E] font-medium tabular-nums">
                          {deal.pricing.askingPrice ? '$' + (deal.pricing.askingPrice / 1000).toFixed(0) + 'k' : '—'}
                        </div>
                        <div className="text-[#8B92A3]">
                          {matches} matches
                        </div>
                      </div>

                      {/* Quick Actions on hover (bottom of card) */}
                      <div className="mt-2 flex gap-1 opacity-0 group-hover:opacity-100 transition text-[10px]">
                        <button onClick={e => { e.stopPropagation(); useAppStore.getState().safeOpenDeal(deal.id) }} className="btn btn-ghost px-1 py-0.5 text-[10px]">View</button>
                        <button onClick={e => { e.stopPropagation(); /* open edit via drawer */ useAppStore.getState().safeOpenDeal(deal.id) }} className="btn btn-ghost px-1 py-0.5 text-[10px]">Edit</button>
                        <button onClick={e => { e.stopPropagation(); /* would navigate */ toast('Calculator') }} className="btn btn-ghost px-1 py-0.5 text-[10px]">Calc</button>
                        <button onClick={e => { e.stopPropagation(); /* blast */ toast('Blast') }} className="btn btn-ghost px-1 py-0.5 text-[10px]">Blast</button>
                      </div>

                      {/* Status control fallback */}
                      <div className="mt-2">
                        <select 
                          value={deal.status} 
                          onChange={e => { e.stopPropagation(); changeStatus(deal.id, e.target.value) }} 
                          className="select text-xs w-full py-0.5"
                          onClick={(e: React.MouseEvent) => e.stopPropagation()}
                        >
                          {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>

      {/* Timeline View (simplified) */}
      {viewMode === 'timeline' && (
        <div className="mt-6 card p-4">
          <div className="text-sm font-semibold mb-3">Pipeline Timeline (Recent Flow)</div>
          <div className="flex flex-wrap gap-2 text-xs">
            {STATUSES.map((s, i) => (
              <div key={i} className={`px-3 py-1 rounded ${STAGE_COLORS[s].header} flex items-center gap-1`}>
                {s} <ArrowRight size={12} className="opacity-50"/>
              </div>
            ))}
          </div>
          <div className="text-[10px] text-[#8B92A3] mt-2">Full interactive timeline coming in future update.</div>
        </div>
      )}
    </div>
  )
}
