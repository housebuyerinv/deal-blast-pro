
import { useAppStore } from '../../store/useAppStore'

export default function Analytics() {
  const { deals, buyers, blastLogs, followUps, getBuyerHeatScore, getDealQualityScore } = useAppStore()

  // Basic performance guard - avoid heavy work on empty data
  if (deals.length === 0) {
    return (
      <div className="empty-state card p-8">
        <div>No data loaded yet.</div>
        <button onClick={() => useAppStore.getState().runSampleWorkflow()} className="btn btn-green mt-4">
          Generate Demo Data
        </button>
      </div>
    )
  }

  const totalDeals = deals.length
  const activeDeals = deals.filter(d => ['Approved', 'Active', 'Blasted', 'Offers Received', 'Under Contract', 'Closing'].includes(d.status)).length
  const blastedDeals = deals.filter(d => d.status === 'Blasted' || d.status === 'Offers Received').length

  const totalBuyers = buyers.length
  const hotBuyers = buyers.filter(b => b.status === 'Hot').length

  const totalBlasts = Object.values(blastLogs).flat().length
  const totalRecipients = Object.values(blastLogs).flat().reduce((sum, log) => sum + (log.recipientCount || 0), 0)

  // Response simulation using existing data + mock
  const interested = Math.floor(totalBuyers * 0.28)
  const madeOffer = Math.floor(totalBuyers * 0.09)
  const passed = Math.floor(totalBuyers * 0.22)
  const noResponse = totalBuyers - interested - madeOffer - passed

  const responseRate = totalBuyers > 0 ? Math.round(((interested + madeOffer) / totalBuyers) * 100) : 0
  const offerConversion = (interested + madeOffer) > 0 ? Math.round((madeOffer / (interested + madeOffer)) * 100) : 0

  const avgMatchScore = Math.round(
    deals.reduce((sum, d) => {
      const matches = useAppStore.getState().getMatchesForDeal(d.id)
      return sum + (matches.length > 0 ? matches.reduce((s, m) => s + m.score, 0) / matches.length : 50)
    }, 0) / Math.max(1, deals.length)
  )

  const overdueFollowups = followUps.filter(f => !f.completed && new Date(f.dueDate) <= new Date()).length

  // Simple bar helper
  const Bar = ({ label, value, max = 100, color = 'bg-[#3B82F6]' }: { label: string; value: number; max?: number; color?: string }) => (
    <div className="flex items-center gap-3 text-sm">
      <div className="w-28 text-[#8B92A3] truncate">{label}</div>
      <div className="flex-1 bg-[#252A38] h-2 rounded">
        <div className={`h-2 rounded ${color}`} style={{ width: `${Math.min(100, (value / max) * 100)}%` }} />
      </div>
      <div className="w-10 text-right font-mono">{value}</div>
    </div>
  )

  return (
    <div>
      <div className="text-3xl font-semibold tracking-tight mb-1">Analytics</div>
      <div className="text-[#8B92A3] mb-6">Real-time performance across deals, buyers, and blasts</div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-6">
        <div className="card p-4"><div className="text-2xl font-semibold">{totalDeals}</div><div className="text-sm text-[#8B92A3]">Total Deals</div></div>
        <div className="card p-4"><div className="text-2xl font-semibold">{activeDeals}</div><div className="text-sm text-[#8B92A3]">Active Pipeline</div></div>
        <div className="card p-4"><div className="text-2xl font-semibold">{blastedDeals}</div><div className="text-sm text-[#8B92A3]">Deals Blasted</div></div>
        <div className="card p-4"><div className="text-2xl font-semibold">{totalBuyers}</div><div className="text-sm text-[#8B92A3]">Total Buyers</div></div>
        <div className="card p-4"><div className="text-2xl font-semibold text-[#22C55E]">{hotBuyers}</div><div className="text-sm text-[#8B92A3]">Hot Buyers</div></div>
        <div className="card p-4"><div className="text-2xl font-semibold">{totalBlasts}</div><div className="text-sm text-[#8B92A3]">Blasts Sent</div></div>
      </div>

      {deals.length === 0 && (
        <div className="empty-state card p-8 mb-6">
          <div>No data yet</div>
          <button onClick={() => useAppStore.getState().runSampleWorkflow()} className="btn btn-green mt-4">Run Sample Workflow</button>
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Response Breakdown */}
        <div className="card p-5">
          <div className="font-medium mb-4">Buyer Response Breakdown</div>
          <div className="space-y-3">
            <Bar label="Interested" value={interested} max={totalBuyers} color="bg-[#22C55E]" />
            <Bar label="Made Offer" value={madeOffer} max={totalBuyers} color="bg-[#3B82F6]" />
            <Bar label="Passed" value={passed} max={totalBuyers} color="bg-amber-500" />
            <Bar label="No Response" value={noResponse} max={totalBuyers} color="bg-[#8B92A3]" />
          </div>
          <div className="mt-4 text-sm text-[#8B92A3]">Response Rate: <span className="text-white font-semibold">{responseRate}%</span> • Offer Conversion: <span className="text-white font-semibold">{offerConversion}%</span></div>
        </div>

        {/* Key Metrics */}
        <div className="card p-5">
          <div className="font-medium mb-4">Key Performance Metrics</div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>Total Recipients Blasted: <span className="font-semibold">{totalRecipients}</span></div>
            <div>Avg Match Score: <span className="font-semibold">{avgMatchScore}%</span></div>
            <div>Overdue Follow-ups: <span className="font-semibold text-red-400">{overdueFollowups}</span></div>
            <div>Deals with Quality A/B: <span className="font-semibold">{deals.filter(d => ['A','B'].includes(getDealQualityScore(d.id).grade)).length}</span></div>
          </div>
        </div>

        {/* Top Buyers by Heat */}
        <div className="card p-5">
          <div className="font-medium mb-3">Top 8 Hottest Buyers</div>
          <div className="space-y-2 text-sm">
            {[...buyers].sort((a,b) => getBuyerHeatScore(b.id) - getBuyerHeatScore(a.id)).slice(0,8).map(b => (
              <div key={b.id} className="flex justify-between">
                <div>{b.name}</div>
                <div className="font-mono text-[#22C55E]">{getBuyerHeatScore(b.id)}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Deals by Quality */}
        <div className="card p-5">
          <div className="font-medium mb-3">Top Quality Deals</div>
          <div className="space-y-2 text-sm">
            {[...deals].sort((a,b) => getDealQualityScore(b.id).score - getDealQualityScore(a.id).score).slice(0,6).map(d => {
              const q = getDealQualityScore(d.id)
              return <div key={d.id} className="flex justify-between"><span>{d.property.address}</span> <span className="font-mono text-[#22C55E]">{q.grade} {q.score}</span></div>
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
