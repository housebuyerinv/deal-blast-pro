import { Deal, Buyer } from './types'

interface ScoreBreakdown {
  score: number
  reasons: string[]
  missing: string[]
}

export function computeMatchScore(deal: Deal, buyer: Buyer, weights: any): ScoreBreakdown {
  let score = 0
  const reasons: string[] = []
  const missing: string[] = []
  
  const d = deal.property
  const p = deal.pricing
  const asking = p.askingPrice || p.contractPrice || 0
  
  // State / Market
  const stateMatch = buyer.markets.some(m => 
    m.toLowerCase() === d.state.toLowerCase() || 
    m.toLowerCase() === 'nationwide' || 
    m.toLowerCase() === 'any'
  )
  if (stateMatch) {
    score += weights.state
    reasons.push(`Market match (+${weights.state})`)
  } else {
    missing.push('State/market')
  }
  
  // City
  const cityMatch = buyer.cities?.some(c => c.toLowerCase() === d.city.toLowerCase())
  if (cityMatch) {
    score += weights.city
    reasons.push(`City exact (+${weights.city})`)
  }
  
  // Asset type
  const assetMatch = buyer.assetTypes.includes(d.type)
  if (assetMatch) {
    score += weights.assetType
    reasons.push(`Exact asset type (+${weights.assetType})`)
  } else if (buyer.assetTypes.length === 0) {
    // broad buyer
    score += Math.floor(weights.assetType * 0.6)
    reasons.push(`Broad asset tolerance (+${Math.floor(weights.assetType * 0.6)})`)
  } else {
    missing.push('Asset type')
  }
  
  // Budget overlap
  if (asking > 0 && buyer.budgetMin != null && buyer.budgetMax != null) {
    const within = asking >= buyer.budgetMin && asking <= buyer.budgetMax
    const near = Math.abs(asking - (buyer.budgetMax || asking)) / (buyer.budgetMax || asking) < 0.25
    if (within || near) {
      score += weights.budget
      reasons.push(`Within/near budget (+${weights.budget})`)
    } else {
      missing.push('Budget fit')
    }
  } else if (buyer.budgetMax && asking > buyer.budgetMax * 1.3) {
    missing.push('Budget (too high)')
  }
  
  // Units
  const units = d.units || 1
  if (buyer.unitMin != null && buyer.unitMax != null) {
    if (units >= buyer.unitMin && units <= buyer.unitMax) {
      score += weights.units
      reasons.push(`Unit count in range (+${weights.units})`)
    }
  }
  
  // Cap rate
  if (p.capRate != null && buyer.capRateMin != null) {
    if (p.capRate >= buyer.capRateMin) {
      score += weights.capRate
      reasons.push(`Cap rate meets requirement (+${weights.capRate})`)
    } else {
      missing.push('Cap rate')
    }
  }
  
  // Seller finance
  if (p.sellerFinance && buyer.sellerFinance) {
    score += weights.sellerFinance
    reasons.push(`Seller finance preference match (+${weights.sellerFinance})`)
  } else if (p.sellerFinance && !buyer.sellerFinance) {
    // still possible but lower
    score += 3
  }
  
  // Creative
  if (buyer.creativeFinance) {
    score += weights.creative
    reasons.push(`Creative finance open (+${weights.creative})`)
  }
  
  // Rehab tolerance (very rough heuristic)
  const rehab = p.rehab || 0
  if (buyer.rehabTolerance && rehab > 0) {
    const tol = buyer.rehabTolerance.toLowerCase()
    if ((tol.includes('heavy') && rehab > 40000) || (tol.includes('light') && rehab < 35000)) {
      score += weights.rehab
      reasons.push(`Rehab tolerance alignment (+${weights.rehab})`)
    }
  }
  
  // Tags bonus
  const dealTags = [d.type, p.sellerFinance ? 'creative' : ''].filter(Boolean).map(t => t.toLowerCase())
  const overlap = buyer.tags.filter(t => dealTags.some(dt => dt.includes(t.toLowerCase()) || t.toLowerCase().includes(dt)))
  if (overlap.length) {
    score += weights.tags
    reasons.push(`Tag synergy: ${overlap.join(', ')} (+${weights.tags})`)
  }
  
  // Nationwide bonus
  const isNationwide = buyer.markets.some(m => ['nationwide', 'any', 'all'].includes(m.toLowerCase()))
  if (isNationwide) {
    score += 6
    reasons.push('Nationwide buyer (+6)')
  }
  
  // Clamp
  const final = Math.max(0, Math.min(100, Math.round(score)))
  
  return { score: final, reasons: reasons.length ? reasons : ['Baseline profile match'], missing }
}

export function getTier(score: number): 'Strong Match' | 'Possible Match' | 'Weak Match' {
  if (score >= 70) return 'Strong Match'
  if (score >= 45) return 'Possible Match'
  return 'Weak Match'
}

export function getCreativeOnly(deal: Deal): boolean {
  return !!deal.pricing.sellerFinance || deal.property.strategy.toLowerCase().includes('seller') || deal.property.strategy.toLowerCase().includes('creative')
}
