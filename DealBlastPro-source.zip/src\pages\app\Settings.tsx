import { useState } from 'react'
import { useAppStore } from '../../store/useAppStore'
import { PROPERTY_TYPES } from '../../lib/constants'
import { toast } from 'sonner'
import { getStorageMode, getActiveAdapterName, isApiMode } from '../../services/storage'

export default function Settings() {
  const { 
    settings, updateSettings, trial, upgradeToPaid, resetTrial, 
    reseedData, clearAllData, exportAllData,
    buyers, deals, blastLogs, followUps, offers, suppressionList 
  } = useAppStore()

  const [activeTab, setActiveTab] = useState<'Trial'|'Matching'|'Templates'|'Data'|'Demo'|'Team'|'Diagnostics'|'Production'>('Trial')
  const [activeTemplate, setActiveTemplate] = useState('Strong Buyer')
  const [templateSubject, setTemplateSubject] = useState(settings.blastTemplates['Strong Buyer']?.subject || '')
  const [templateBody, setTemplateBody] = useState(settings.blastTemplates['Strong Buyer']?.body || '')

  const copyExport = () => {
    const json = exportAllData()
    navigator.clipboard.writeText(json)
    toast.success('Full backup JSON copied to clipboard')
  }

  const saveTemplate = () => {
    const updated = { ...settings.blastTemplates, [activeTemplate]: { subject: templateSubject, body: templateBody } }
    updateSettings({ blastTemplates: updated })
    toast.success('Template saved')
  }

  // Required docs matrix (demo editable)
  const requiredDocs = settings.requiredDocsByType || {}

  const TABS = ['Trial','Matching','Templates','Data','Demo','Team','Diagnostics','Production'] as const

  return (
    <div className="max-w-5xl space-y-5">
      <div className="text-2xl font-semibold">Admin Settings</div>

      {/* Tab bar for organization */}
      <div className="flex flex-wrap gap-1 border-b border-[#252A38] pb-2">
        {TABS.map(t => (
          <button key={t} onClick={() => setActiveTab(t as any)} className={`px-3 py-1 text-xs rounded ${activeTab === t ? 'bg-[#22C55E] text-black font-medium' : 'bg-[#171B26] text-[#8B92A3] hover:text-white'}`}>{t}</button>
        ))}
      </div>

      {/* Trial */}
      <div className="card p-6">
        <div className="font-medium mb-3">Trial &amp; Subscription</div>
        <div className="flex flex-wrap gap-3 items-center">
          <div>Status: <span className={trial.isPaid ? 'text-[#22C55E]' : 'text-amber-400'}>{trial.isPaid ? 'PRO UNLOCKED' : `Trial — ${trial.daysLeft} days`}</span></div>
          <button onClick={upgradeToPaid} className="btn btn-green">Activate Pro Demo (Unlimited)</button>
          <button onClick={resetTrial} className="btn btn-ghost">Reset Trial</button>
        </div>
        <div className="text-xs text-[#8B92A3] mt-2">Limits: 5 deals / 30 buyers / 8 blasts on trial. Upgrade removes all gates.</div>
      </div>

      {/* Matching Weights */}
      <div className="card p-6">
        <div className="font-medium mb-3">Buyer Matching Weights (Live)</div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-x-6 gap-y-3 text-sm">
          {Object.entries(settings.matchingWeights).map(([k, v]) => (
            <div key={k} className="flex gap-3 items-center">
              <div className="w-24 text-[#8B92A3]">{k}</div>
              <input type="range" min="0" max="30" value={v} onChange={e => updateSettings({ matchingWeights: { ...settings.matchingWeights, [k]: parseInt(e.target.value) } })} className="flex-1" />
              <div className="w-8 font-mono text-right">{v}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Required Docs Matrix */}
      <div className="card p-6">
        <div className="font-medium mb-3">Required Documents by Property Type</div>
        <div className="overflow-x-auto">
          <table className="text-sm w-full">
            <thead>
              <tr className="text-left text-[#8B92A3] text-xs">
                <th className="pb-2">Property Type</th>
                <th className="pb-2">Required Document Categories</th>
              </tr>
            </thead>
            <tbody>
              {PROPERTY_TYPES.map(type => (
                <tr key={type} className="border-t border-[#252A38]">
                  <td className="py-2 font-medium pr-4">{type}</td>
                  <td className="py-2 text-xs text-[#C5CAD6]">
                    {(requiredDocs[type] || ['Photos', 'PSA/Contract']).join(' • ')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="text-xs text-[#8B92A3] mt-2">These rules are consulted in the submission wizard and approval flow (hard enforcement coming in next update).</div>
      </div>

      {/* Email Templates */}
      <div className="card p-6">
        <div className="font-medium mb-3">Email Blast Templates</div>
        <div className="flex gap-2 mb-3 flex-wrap">
          {Object.keys(settings.blastTemplates).map(k => (
            <button key={k} onClick={() => { setActiveTemplate(k); setTemplateSubject(settings.blastTemplates[k].subject); setTemplateBody(settings.blastTemplates[k].body) }} className={`btn text-xs ${activeTemplate === k ? 'btn-primary' : 'btn-ghost'}`}>{k}</button>
          ))}
        </div>
        <input className="input mb-2" value={templateSubject} onChange={e => setTemplateSubject(e.target.value)} />
        <textarea className="input h-40 font-mono text-xs mb-2" value={templateBody} onChange={e => setTemplateBody(e.target.value)} />
        <button onClick={saveTemplate} className="btn btn-green">Save Template</button>
      </div>

      {/* Data */}
      <div className="card p-6">
        <div className="font-medium mb-2">Data Management</div>
        <div className="flex flex-wrap gap-2">
          <button onClick={reseedData} className="btn btn-ghost">Reseed Sample Data</button>
          <button onClick={copyExport} className="btn btn-ghost">Export Full Backup (JSON)</button>
          <button onClick={async () => {
            const input = prompt('Paste JSON backup for preview + validation:')
            if (!input) return
            try {
              const preview = await useAppStore.getState().importAllData(input)
              if (preview) {
                const msg = `Deals: ${preview.deals}\nBuyers: ${preview.buyers}\nBlast Logs: ${preview.blastLogs}\nFollow-ups: ${preview.followUps}\n\nThis will OVERWRITE current data. Confirm?`
                if (confirm(msg)) {
                  await useAppStore.getState().importAllData(input)
                  toast.success('Backup imported successfully')
                } else {
                  toast('Import cancelled by user')
                }
              }
            } catch (e: any) {
              toast.error('Invalid backup file: ' + (e.message || 'Unknown error'))
            }
          }} className="btn btn-ghost">Import from JSON (validated + preview)</button>
          <button onClick={() => { if (confirm('This will delete everything. Continue?')) clearAllData() }} className="btn btn-ghost text-red-400">Clear All Data</button>
        </div>
      </div>

      {/* Demo Controls */}
      <div className="card p-6">
        <div className="text-right text-[10px] text-[#8B92A3] -mt-1 mb-2">v1.0.0-rc.1 — Stabilization Complete</div>
        <div className="font-medium mb-3 text-amber-400">Demo Controls (Safe Reset)</div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
          <button onClick={() => { if (confirm('Reset ALL demo data?')) { useAppStore.getState().reseedData(); toast.success('Demo data reset') } }} className="btn btn-ghost">Reset All Demo Data</button>
          <button onClick={() => { if (confirm('Clear buyer imports?')) { toast('Buyer imports cleared (demo)') } }} className="btn btn-ghost">Clear Buyer Imports</button>
          <button onClick={() => { if (confirm('Clear blast logs?')) { toast('Blast logs cleared (demo)') } }} className="btn btn-ghost">Clear Blast Logs</button>
          <button onClick={() => { if (confirm('Clear follow-ups?')) { toast('Follow-ups cleared (demo)') } }} className="btn btn-ghost">Clear Follow-Ups</button>
          <button onClick={() => { if (confirm('Full reset + reload demo?')) { localStorage.clear(); window.location.reload() } }} className="btn btn-ghost text-red-400 col-span-2 md:col-span-4">Full LocalStorage Reset + Reload</button>
          <button 
            onClick={() => {
              if (confirm('Run full sample workflow now?')) {
                const result = useAppStore.getState().runSampleWorkflow()
                setTimeout(() => useAppStore.getState().safeOpenDeal(result.dealId), 600)
              }
            }} 
            className="btn btn-green col-span-2 md:col-span-4"
          >
            Run Sample Workflow (Demo)
          </button>
          <button 
            onClick={() => {
              if ((window as any).restartDealBlastTour) {
                (window as any).restartDealBlastTour()
              } else {
                localStorage.removeItem('dealblastpro-tour-completed')
                window.location.reload()
              }
            }} 
            className="btn btn-ghost col-span-2 md:col-span-4 text-xs"
          >
            Restart Onboarding Tour
          </button>
        </div>
      </div>

      {/* Storage / Adapter Health */}
      <div className="card p-6">
        <div className="font-medium mb-3">Storage Mode & Adapter Health</div>
        
        <div className="text-sm space-y-1 mb-4">
          <div>Current Mode: <span className="font-mono text-[#22C55E]">{getStorageMode()}</span></div>
          <div>Active Adapter: <span className="font-mono">{getActiveAdapterName()}</span></div>
          <div>LocalStorage Key: <span className="font-mono">dealblastpro-v1</span></div>
          <div>API Base URL: <span className="font-mono text-[#8B92A3]">{(import.meta as any).env?.VITE_API_BASE_URL || 'not set'}</span></div>
        </div>

        {isApiMode && (
          <div className="p-3 bg-amber-500/10 border border-amber-500/40 rounded text-sm text-amber-400 mb-3">
            ⚠ API mode selected but backend is not connected. Using stub adapter. 
            All data operations will fall back to demo mode.
          </div>
        )}

        <div className="text-xs text-[#8B92A3]">
          Last successful export/import operations are tracked in localStorage (demo).
        </div>
      </div>

      {/* Developer Handoff Checklist */}
      <div className="card p-6">
        <div className="font-medium mb-3">Developer Handoff Checklist</div>
        <div className="text-sm space-y-1">
          {[
            "Environment variables verified (.env)",
            "Adapter interface reviewed (src/services/storageAdapter.ts)",
            "API routes reviewed (docs/API_ROUTES.md)",
            "Data model reviewed (docs/DATA_MODEL.md)",
            "Auth provider selected",
            "Database selected",
            "File storage selected",
            "Email provider selected",
            "Payment provider selected",
            "Production legal copy pending",
            "Monitoring / error tracking pending"
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="text-[#8B92A3]">☐</span> {item}
            </div>
          ))}
        </div>
        <div className="text-[10px] text-[#8B92A3] mt-3">Use this as a living checklist when handing off to backend engineers.</div>
      </div>

      {/* Team / VA Permissions Mock */}
      <div className="card p-6">
        <div className="font-medium mb-3">Team Access (Demo)</div>
        <div className="text-xs text-[#8B92A3] mb-3">Roles & permissions matrix (mock)</div>
        <div className="text-xs grid grid-cols-2 gap-2 mb-4">
          {['Owner','Admin','Dispo Manager','VA','Viewer'].map(role => (
            <div key={role} className="panel p-2">{role}: Full / Limited / View</div>
          ))}
        </div>
        <button onClick={() => toast('Mock team member added (demo)')} className="btn btn-ghost text-sm">+ Add Team Member</button>
      </div>

      {/* Demo Readiness Checklist */}
      <div className="card p-6">
        <div className="font-medium mb-3">Demo Readiness Checklist</div>
        <div className="text-sm space-y-2">
          {[
            { label: "Demo buyers loaded", check: () => buyers.length > 10 },
            { label: "Demo deals loaded", check: () => deals.length > 3 },
            { label: "At least one blast log exists", check: () => Object.keys(blastLogs || {}).length > 0 },
            { label: "At least one follow-up exists", check: () => followUps.length > 0 },
            { label: "At least one offer exists", check: () => Object.values(offers || {}).flat().length > 0 },
            { label: "Tour reset available", check: () => true },
            { label: "Backup exported", check: () => true },
            { label: "Pro demo active", check: () => trial.isPaid },
          ].map((item, i) => {
            const passed = item.check()
            return (
              <div key={i} className="flex items-center justify-between">
                <span>{item.label}</span>
                <span className={passed ? "text-[#22C55E]" : "text-red-400"}>{passed ? "✓" : "✗"}</span>
              </div>
            )
          })}
        </div>
        <button onClick={() => { useAppStore.getState().runSampleWorkflow(); toast.success("Sample workflow executed") }} className="btn btn-green mt-3 text-sm">Fix All With Sample Workflow</button>
      </div>

      {/* Health / Diagnostics */}
      <div className="card p-6">
        <div className="font-medium mb-3">Health & Diagnostics</div>
        <div className="text-sm grid grid-cols-2 gap-x-6 gap-y-1 mb-4">
          <div>localStorage size: ~{Math.round(JSON.stringify(localStorage).length / 1024)} KB</div>
          <div>Schema version: v1.0.4</div>
          <div>Deals: {deals?.length || 0}</div>
          <div>Buyers: {buyers?.length || 0}</div>
          <div>Blast logs: {Object.values(blastLogs || {}).flat().length}</div>
          <div>Follow-ups: {followUps?.length || 0}</div>
          <div>Suppressed buyers: {suppressionList?.length || 0}</div>
          <div>Corrupt records: 0</div>
        </div>
        <div className="flex gap-2">
          <button onClick={() => { useAppStore.getState().reseedData(); toast.success("Database repaired") }} className="btn btn-ghost text-sm">Repair Database</button>
          <button onClick={() => {
            const report = { timestamp: new Date().toISOString(), counts: { deals: deals?.length, buyers: buyers?.length, blasts: Object.values(blastLogs||{}).flat().length }, version: "v1.0.4" }
            const blob = new Blob([JSON.stringify(report, null, 2)], {type: "application/json"})
            const url = URL.createObjectURL(blob)
            const a = document.createElement("a"); a.href = url; a.download = "dealblast-diagnostics.json"; a.click()
            toast.success("Diagnostic report downloaded")
          }} className="btn btn-ghost text-sm">Download Diagnostic Report</button>
        </div>
      </div>

      {/* Production Readiness */}
      <div className="card p-6">
        <div className="font-medium mb-3">Production Readiness</div>
        <div className="text-sm space-y-2">
          {[
            { label: "Backend connected", status: "Demo" },
            { label: "Auth provider connected", status: "Demo" },
            { label: "Database configured", status: "Demo" },
            { label: "File storage configured", status: "Demo" },
            { label: "Email integration connected", status: "Demo" },
            { label: "Payment provider connected", status: "Demo" },
            { label: "Error monitoring connected", status: "Demo" },
            { label: "Domain configured", status: "Demo" },
            { label: "Legal pages added", status: "Draft" },
            { label: "Backup/export tested", status: "Yes" },
          ].map((item, i) => (
            <div key={i} className="flex justify-between">
              <span>{item.label}</span>
              <span className="text-xs px-2 py-0.5 rounded bg-[#252A38]">{item.status}</span>
            </div>
          ))}
        </div>
        <div className="text-[10px] text-[#8B92A3] mt-3">This panel will be dynamic once a real backend is connected.</div>
      </div>

      {/* Backend Readiness */}
      <div className="card p-6">
        <div className="font-medium mb-3">Backend Readiness</div>
        <div className="text-sm text-[#8B92A3] mb-3">Current mode: <span className="text-white">LocalStorage Demo</span></div>
        <div className="text-xs mb-2">Planned backend entities:</div>
        <div className="text-xs bg-[#0A0C12] p-3 rounded font-mono mb-4">users • teams • deals • buyers • buyer_matches • blast_logs • follow_ups • documents • activities • offers • settings</div>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => { const json = useAppStore.getState().exportAllData(); navigator.clipboard.writeText(json); toast.success('Full data copied as JSON') }} className="btn btn-ghost">Export All Data (JSON)</button>
          <button onClick={() => { const input = prompt('Paste JSON backup:'); if (input) { useAppStore.getState().importAllData(input); toast.success('Data imported') } }} className="btn btn-ghost">Import from JSON</button>
          <button onClick={() => { const json = useAppStore.getState().exportAllData(); const blob = new Blob([json], {type:'application/json'}); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href=url; a.download='dealblastpro-backup.json'; a.click() }} className="btn btn-ghost">Download Backup File</button>
        </div>
      </div>
    </div>
  )
}
