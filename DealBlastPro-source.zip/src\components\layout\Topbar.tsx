import { useAppStore } from '../../store/useAppStore'
import { Menu, LogOut, CreditCard } from 'lucide-react'
import { useNavigate, Link } from 'react-router-dom'

export default function Topbar({ onMenuClick }: { onMenuClick?: () => void }) {
  const { user, trial, setRole, logout, upgradeToPaid } = useAppStore()
  const navigate = useNavigate()

  const trialDays = trial.isPaid ? 'PRO' : `${trial.daysLeft}d left`

  return (
    <header className="h-14 border-b border-[#252A38] bg-[#0A0C12]/95 backdrop-blur flex items-center justify-between px-4 lg:px-6 sticky top-0 z-[80]">
      <div className="flex items-center gap-3">
        <button 
          onClick={onMenuClick} 
          className="lg:hidden btn btn-ghost p-2"
          aria-label="Toggle menu"
        >
          <Menu size={18} />
        </button>
        <div className="hidden lg:block text-sm text-[#8B92A3]">
          {user?.company || 'Demo Workspace'} • <span className="text-[#22C55E]">{user?.role}</span>
        </div>
        <Link to="/" className="text-xs text-[#3B82F6] hover:underline ml-2 hidden md:inline">← Home / Public Site</Link>
      </div>

      <div className="flex items-center gap-3 text-sm">
        {/* Trial / Upgrade pill */}
        <button
          onClick={() => trial.isPaid ? null : upgradeToPaid()}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border ${trial.isPaid 
            ? 'bg-[#22C55E]/10 border-[#22C55E]/40 text-[#22C55E]' 
            : 'bg-[#F59E0B]/10 border-[#F59E0B]/40 text-[#FBBF24] hover:bg-[#F59E0B]/20'}`}
        >
          <CreditCard size={13} />
          {trial.isPaid ? 'PRO UNLOCKED' : `TRIAL ${trialDays}`}
        </button>

        {/* Role switcher for demo */}
        <select 
          value={user?.role} 
          onChange={(e) => setRole(e.target.value as any)}
          className="bg-[#12151F] border border-[#252A38] text-xs rounded px-2 py-1"
        >
          <option>Admin</option>
          <option>Team Member / VA</option>
          <option>Viewer</option>
          <option>Buyer</option>
          <option>Seller / Submitter</option>
        </select>

        <div className="flex items-center gap-2 pl-2 border-l border-[#252A38]">
          <div className="text-right">
            <div className="text-sm font-medium leading-none">{user?.name}</div>
            <div className="text-[10px] text-[#8B92A3]">{user?.email}</div>
          </div>
          <button onClick={() => { logout(); navigate('/login') }} className="btn btn-ghost p-2" title="Logout">
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </header>
  )
}
