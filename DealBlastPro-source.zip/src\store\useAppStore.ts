import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { toast } from 'sonner'
import { 
  Deal, Buyer, Offer, Activity, Doc, User, AppSettings, TrialState, 
  MatchResult, AppState, BuyerResponse, BlastLog, DealSuppression 
} from '../lib/types'
import { DEFAULT_SETTINGS, MOCK_USER, TRIAL_DEFAULT } from '../lib/constants'
import { seedDeals, seedBuyers, seedOffers, seedActivities } from '../lib/mockData'
import { computeMatchScore, getTier } from '../lib/matchingEngine'
import { isApiMode } from '../services/storage'

// Module-level guard so initialize is truly one-shot even if called multiple times from effects or StrictMode
let hasInitialized = false

interface AppStore extends AppState {
  // Explicit operational state (align with actual persisted/used shape + referenced by pages)
  blastLogs: Record<string, BlastLog[]>
  buyerResponses: Record<string, Record<string, BuyerResponse>>
  dealSuppressions: Record<string, DealSuppression[]>
  dismissedAttention: Record<string, { dismissedAt: string; issueKeys: string[] }>

  // Initialization
  initialize: () => void
  
  // Auth
  login: (email: string, name?: string) => void
  logout: () => void
  setRole: (role: User['role']) => void
  
  // Trial
  useTrialAction: (action: keyof TrialState['usage']) => boolean // returns false if blocked
  upgradeToPaid: () => void
  resetTrial: () => void
  
  // Deals
  addDeal: (deal: Omit<Deal, 'id' | 'createdAt' | 'updatedAt'>) => Deal
  updateDeal: (id: string, updates: Partial<Deal>) => void
  approveDeal: (id: string) => void
  setCurrentDeal: (id: string | null) => void
  safeOpenDeal: (id: string) => void
  getDeal: (id: string) => Deal | undefined
  getInventoryDeals: () => Deal[]
  getSubmissionsQueue: () => Deal[]
  // Convenience section updaters (preserve existing data)
  updateDealProperty: (id: string, updates: Partial<Deal['property']>) => void
  updateDealPricing: (id: string, updates: Partial<Deal['pricing']>) => void
  updateDealDebt: (id: string, updates: Partial<Deal['debt']>) => void
  updateDealCondition: (id: string, updates: Partial<Deal['condition']>) => void
  updateSubmitter: (id: string, updates: Partial<Deal['submitter']>) => void
  addNote: (dealId: string, note: string) => void
  updateDealClosing: (id: string, updates: Partial<Deal['closing']>) => void
  updateClosingChecklist: (id: string, key: string, value: boolean) => void
  
  // Buyers
  addBuyer: (buyer: Omit<Buyer, 'id' | 'createdAt'>) => Buyer
  updateBuyer: (id: string, updates: Partial<Buyer>) => void
  importBuyers: (newBuyers: Omit<Buyer, 'id' | 'createdAt'>[]) => { added: number; dups: number; suppressed: number }
  mergeBuyers: (primaryId: string, toMergeIds: string[]) => void
  getBuyer: (id: string) => Buyer | undefined
  addToSuppression: (email: string) => void
  
  // Matching
  getMatchesForDeal: (dealId: string) => MatchResult[]
  excludeBuyerFromDeal: (dealId: string, buyerId: string, reason: string) => void
  
  // Offers
  addOffer: (dealId: string, offer: Omit<Offer, 'id' | 'createdAt' | 'history'>) => void
  updateOfferStatus: (dealId: string, offerId: string, status: Offer['status'], counter?: number) => void
  
  // Documents
  addDocument: (dealId: string, doc: Partial<Doc> & { name: string; url: string; category: string }) => void
  removeDocument: (dealId: string, docId: string) => void
  toggleDocFlag: (dealId: string, docId: string, flag: 'isBuyerFacing' | 'requiresNDA' | 'isRequired') => void
  
  // Activity
  logActivity: (dealId: string | null, type: string, description: string) => void
  getActivities: (dealId: string) => Activity[]
  
  // Viewed / New badges
  markDealViewed: (id: string) => void
  markBuyerViewed: (id: string) => void
  isNewDeal: (id: string) => boolean
  isNewBuyer: (id: string) => boolean
  
  // Blast
  recordBlast: (dealId: string, buyerIds: string[]) => void
  
  // Settings
  updateSettings: (updates: Partial<AppSettings>) => void
  
  // UI
  toggleSidebar: () => void
  
  // Data ops
  exportAllData: () => string
  importAllData: (json: string) => Promise<{ deals: number; buyers: number; blastLogs: number; followUps: number; hasSettings: boolean } | void>
  clearAllData: () => void
  reseedData: () => void

  // Buyer Match History & Response Tracking
  setBuyerResponse: (buyerId: string, dealId: string, status: BuyerResponse['status'], notes?: string) => void
  getBuyerMatchHistory: (buyerId: string) => Array<{
    deal: Deal
    score: number
    reasons: string[]
    blasted: boolean
    response?: BuyerResponse
    offer?: Offer
  }>

  // Deal-specific Suppression
  suppressBuyerFromDeal: (dealId: string, buyerId: string, reason: string) => void
  removeDealSuppression: (dealId: string, buyerId: string) => void
  isBuyerSuppressedForDeal: (dealId: string, buyerId: string) => boolean

  // Blast History
  recordBlastLog: (dealId: string, log: Omit<BlastLog, 'id' | 'sentAt' | 'sentBy'>) => void
  getBlastLogs: (dealId: string) => BlastLog[]

  // Follow-ups (enhanced Disposition CRM)
  followUps: any[]
  scheduleFollowUp: (dealId: string, buyerId: string | undefined, delayDays: number, type: string) => void
  completeFollowUp: (id: string) => void
  getPendingFollowUps: () => Array<any>
  createTask: (task: any) => void
  generateAutoFollowUpsFromInventory: () => number
  generateAutoFollowUpsFromBuyers: () => number
  getFollowUpStats: () => { pending: number; dueToday: number; overdue: number; completedThisWeek: number; autoGenerated: number }
  prioritizeFollowUps: (followUps: any[]) => any[]

  // Attention / Needs Attention
  getDealAttentionItems: (deal: any) => string[]
  dismissDealAttention: (dealId: string, issueKeys?: string[]) => void
  clearDealAttention: (dealId: string) => void

  // Scores
  getBuyerHeatScore: (buyerId: string) => number
  getDealQualityScore: (dealId: string) => { score: number; grade: string; strengths: string[]; weaknesses: string[] }

  // Sales / Demo helpers
  runSampleWorkflow: () => { dealId: string }
}

const STORAGE_KEY = 'dealblastpro-v1'

export const useAppStore = create<AppStore>()(
  persist(
    (set, get) => ({
      // Initial state
      user: null,
      trial: TRIAL_DEFAULT,
      deals: [],
      buyers: [],
      offers: {},
      activities: {},
      documents: {},
      settings: DEFAULT_SETTINGS,
      viewedDealIds: [],
      viewedBuyerIds: [],
      suppressionList: [],
      sidebarOpen: true,
      currentDealId: null,

      // Operational blast & buyer tracking
      blastLogs: {},
      buyerResponses: {},
      dealSuppressions: {},
      followUps: [],

      // Needs Attention dismissals (explicit only)
      dismissedAttention: {},

      initialize: () => {
        if (hasInitialized) return
        hasInitialized = true

        const state = get()

        // Safety: Recover from corrupt or partial storage
        const safeDeals = Array.isArray(state.deals) ? state.deals : []

        if (safeDeals.length === 0) {
          const deals = seedDeals()
          const buyers = seedBuyers()
          const offers = seedOffers(deals)
          const activities: Record<string, Activity[]> = {}
          
          deals.forEach(d => {
            activities[d.id] = seedActivities(d.id)
          })
          
          set({
            deals,
            buyers,
            offers,
            activities,
            documents: {},
            user: MOCK_USER,
            trial: {
              ...TRIAL_DEFAULT,
              endDate: new Date(Date.now() + 7 * 86400000).toISOString()
            },
            viewedDealIds: [],
            viewedBuyerIds: [],
            suppressionList: [],
            settings: DEFAULT_SETTINGS,
            blastLogs: state.blastLogs || {},
            buyerResponses: state.buyerResponses || {},
            dealSuppressions: state.dealSuppressions || {},
            followUps: Array.isArray(state.followUps) ? state.followUps : []
          })
        } else if (!state.user) {
          set({ user: MOCK_USER })
        }

        // Final safety net - ensure critical arrays/objects exist
        const current = get()
        if (!Array.isArray(current.deals)) set({ deals: [] })
        if (!Array.isArray(current.buyers)) set({ buyers: [] })
        if (!current.settings) set({ settings: DEFAULT_SETTINGS })
      },

      // Auth
      login: (email, name) => {
        set({
          user: {
            id: 'u_' + Date.now(),
            name: name || email.split('@')[0],
            email,
            role: 'Admin',
            company: 'Demo Team'
          }
        })
      },
      logout: () => set({ user: null, currentDealId: null }),
      setRole: (role) => {
        const u = get().user
        if (u) set({ user: { ...u, role } })
      },

      // Trial gating
      useTrialAction: (action) => {
        const { trial } = get()
        if (!trial.isActive || trial.isPaid) return true
        
        const limits: Record<keyof TrialState['usage'], number> = {
          dealsSubmitted: 5,
          buyersImported: 30,
          blastsSent: 8,
          exports: 20
        }
        
        const current = trial.usage[action]
        if (current >= limits[action]) {
          return false // blocked
        }
        
        set({
          trial: {
            ...trial,
            usage: { ...trial.usage, [action]: current + 1 }
          }
        })
        return true
      },
      upgradeToPaid: () => {
        set(s => ({
          trial: { ...s.trial, isPaid: true, isActive: true, daysLeft: 999 }
        }))
      },
      resetTrial: () => set({ trial: TRIAL_DEFAULT }),

      // Deals
      addDeal: (partial) => {
        const id = 'D' + Date.now().toString(36).toUpperCase()
        const now = new Date().toISOString()
        const deal: Deal = {
          ...partial,
          id,
          createdAt: now,
          updatedAt: now,
          docs: partial.docs || [],
        } as Deal
        
        set(s => ({ deals: [...s.deals, deal] }))
        get().logActivity(id, 'Submission Created', `New deal submitted: ${deal.property.address}`)
        return deal
      },
      updateDeal: (id, updates) => {
        set(s => ({
          deals: s.deals.map(d => d.id === id ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d)
        }))
      },
      approveDeal: (id) => {
        get().updateDeal(id, { status: 'Approved' })
        get().logActivity(id, 'Deal Approved', 'Deal moved from submissions to active inventory')
      },
      setCurrentDeal: (id) => {
        set({ currentDealId: id })
        if (id) get().markDealViewed(id)
      },
      // Safe open for drawers to avoid any side effects that could cause update loops
      safeOpenDeal: (id: string) => {
        set({ currentDealId: id })
        // No markViewed, no logging, no other writes during open
      },
      getDeal: (id) => get().deals.find(d => d.id === id),
      getInventoryDeals: () => {
        const approved = ['Approved', 'Active', 'Blasted', 'Offers Received', 'Under Contract', 'Closing', 'Sold']
        return get().deals.filter(d => approved.includes(d.status))
      },
      getSubmissionsQueue: () => {
        return get().deals.filter(d => ['Submitted', 'Needs Info', 'Draft'].includes(d.status))
      },

      // Convenience section updaters
      updateDealProperty: (id, updates) => {
        set(s => ({
          deals: s.deals.map(d => d.id === id ? {
            ...d,
            property: { ...d.property, ...updates },
            updatedAt: new Date().toISOString()
          } : d)
        }))
      },
      updateDealPricing: (id, updates) => {
        set(s => ({
          deals: s.deals.map(d => d.id === id ? {
            ...d,
            pricing: { ...d.pricing, ...updates },
            updatedAt: new Date().toISOString()
          } : d)
        }))
      },
      updateDealDebt: (id, updates) => {
        set(s => ({
          deals: s.deals.map(d => d.id === id ? {
            ...d,
            debt: { ...d.debt, ...updates },
            updatedAt: new Date().toISOString()
          } : d)
        }))
      },
      updateDealCondition: (id, updates) => {
        set(s => ({
          deals: s.deals.map(d => d.id === id ? {
            ...d,
            condition: { ...d.condition, ...updates },
            updatedAt: new Date().toISOString()
          } : d)
        }))
      },
      updateSubmitter: (id, updates) => {
        set(s => ({
          deals: s.deals.map(d => d.id === id ? {
            ...d,
            submitter: { ...d.submitter, ...updates },
            updatedAt: new Date().toISOString()
          } : d)
        }))
      },
      addNote: (dealId, note) => {
        get().logActivity(dealId, 'Note Added', note)
      },
      updateDealClosing: (id, updates = {}) => {
        set(s => ({
          deals: s.deals.map(d => {
            if (d.id !== id) return d
            const currentClosing = d.closing || { checklist: {} }
            return {
              ...d,
              closing: {
                ...currentClosing,
                ...updates,
                checklist: {
                  ...currentClosing.checklist,
                  ...(updates.checklist || {})
                }
              },
              updatedAt: new Date().toISOString()
            }
          })
        }))
      },
      updateClosingChecklist: (id, key, value) => {
        set(s => ({
          deals: s.deals.map(d => {
            if (d.id !== id) return d
            const currentClosing = d.closing || { checklist: {} }
            return {
              ...d,
              closing: {
                ...currentClosing,
                checklist: {
                  ...currentClosing.checklist,
                  [key]: value
                }
              },
              updatedAt: new Date().toISOString()
            }
          })
        }))
        get().logActivity(id, 'Closing Update', `Checklist item "${key}" set to ${value}`)
      },

      // === New Operational Features ===

      setBuyerResponse: (buyerId, dealId, status, notes) => {
        set(s => {
          const current = s.buyerResponses[buyerId] || {}
          return {
            buyerResponses: {
              ...s.buyerResponses,
              [buyerId]: {
                ...current,
                [dealId]: {
                  status,
                  date: new Date().toISOString(),
                  notes
                }
              }
            }
          }
        })
        get().logActivity(dealId, 'Buyer Response', `Buyer ${buyerId} marked as ${status}`)
      },

      getBuyerMatchHistory: (buyerId) => {
        const buyer = get().buyers.find(b => b.id === buyerId)
        if (!buyer) return []

        const responses = get().buyerResponses[buyerId] || {}
        const allDeals = get().deals

        return allDeals
          .map(deal => {
            const matchResults = get().getMatchesForDeal(deal.id)
            const match = matchResults.find(m => m.buyer.id === buyerId)
            if (!match) return null

            const blasted = deal.status === 'Blasted' || deal.status === 'Offers Received'
            const response = responses[deal.id]
            const offer = (get().offers[deal.id] || []).find(o => o.buyerId === buyerId || o.buyerEmail === buyer.email)

            return {
              deal,
              score: match.score,
              reasons: match.reasons,
              blasted,
              response,
              offer
            }
          })
          .filter(Boolean) as any
      },

      suppressBuyerFromDeal: (dealId, buyerId, reason) => {
        set(s => {
          const current = s.dealSuppressions[dealId] || []
          const exists = current.some(s => s.buyerId === buyerId)
          if (exists) return s

          return {
            dealSuppressions: {
              ...s.dealSuppressions,
              [dealId]: [...current, {
                buyerId,
                reason,
                suppressedAt: new Date().toISOString()
              }]
            }
          }
        })
        get().logActivity(dealId, 'Buyer Suppressed', `Buyer ${buyerId} suppressed from this deal: ${reason}`)
      },

      removeDealSuppression: (dealId, buyerId) => {
        set(s => {
          const current = s.dealSuppressions[dealId] || []
          return {
            dealSuppressions: {
              ...s.dealSuppressions,
              [dealId]: current.filter(s => s.buyerId !== buyerId)
            }
          }
        })
        get().logActivity(dealId, 'Suppression Removed', `Buyer ${buyerId} re-enabled for this deal`)
      },

      isBuyerSuppressedForDeal: (dealId, buyerId) => {
        const list = get().dealSuppressions[dealId] || []
        return list.some(s => s.buyerId === buyerId)
      },

      recordBlastLog: (dealId, logData) => {
        const id = 'BL' + Date.now().toString(36)
        const fullLog: BlastLog = {
          ...logData,
          id,
          sentAt: new Date().toISOString(),
          sentBy: get().user?.name || 'System'
        }

        set(s => ({
          blastLogs: {
            ...s.blastLogs,
            [dealId]: [...(s.blastLogs[dealId] || []), fullLog]
          }
        }))

        get().logActivity(dealId, 'Blast Sent', `Blast sent to ${logData.recipientCount} buyers using ${logData.template}`)
      },

      getBlastLogs: (dealId) => {
        return get().blastLogs[dealId] || []
      },

      scheduleFollowUp: (dealId, buyerId, delayDays, type) => {
        const due = new Date(Date.now() + delayDays * 86400000).toISOString()
        const id = 'FU' + Date.now().toString(36)

        set(s => ({
          followUps: [
            ...s.followUps,
            { id, dealId, buyerId, dueDate: due, type, completed: false }
          ]
        }))

        get().logActivity(dealId, 'Follow-Up Scheduled', `${type} follow-up scheduled for ${delayDays} days`)
      },

      completeFollowUp: (id) => {
        set(s => ({
          followUps: s.followUps.map(f => f.id === id ? { ...f, completed: true } : f)
        }))
      },

      getPendingFollowUps: () => {
        return get().followUps.filter(f => !f.completed && new Date(f.dueDate) <= new Date())
      },

      // === Enhanced Disposition CRM / Task Center ===
      createTask: (task) => {
        const id = 'FU' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
        const dueDate = task.dueDate || new Date(Date.now() + (task.delayDays || 1) * 86400000).toISOString()

        const newTask = {
          id,
          dealId: task.dealId || '',
          buyerId: task.buyerId,
          sellerId: task.sellerId,
          dueDate,
          type: task.type || 'Buyer Follow-Up',
          priority: task.priority || 'Medium',
          notes: task.notes || '',
          completed: false,
          recurring: task.recurring || null, // { intervalDays: 3, until: 'replied' | 'sold' | null }
          history: task.history || [],
          createdAt: new Date().toISOString(),
          ...task
        }

        set(s => ({ followUps: [...s.followUps, newTask] }))

        if (newTask.dealId) {
          get().logActivity(newTask.dealId, 'Task Created', `${newTask.type}: ${newTask.notes?.slice(0, 60) || 'New task'}`)
        }
      },

      generateAutoFollowUpsFromInventory: () => {
        const deals = get().deals || []
        let created = 0
        const now = Date.now()

        deals.forEach(deal => {
          if (['Dead', 'Sold'].includes(deal.status)) return

          const existing = get().followUps.some(f => f.dealId === deal.id && !f.completed)
          if (existing) return

          const issues = get().getDealAttentionItems?.(deal) || []

          // Urgent / Needs Attention
          if (deal.status === 'Needs Info' || issues.length > 2) {
            get().createTask({
              dealId: deal.id,
              type: 'Urgent',
              priority: 'High',
              notes: `Deal needs attention: ${issues.slice(0,3).join(', ')}`,
              dueDate: new Date(now + 1 * 86400000).toISOString()
            })
            created++
          }

          // New approved deal → seller follow-up
          if (['Approved', 'Active'].includes(deal.status) && !deal.pricing?.contractPrice) {
            get().createTask({
              dealId: deal.id,
              type: 'Seller Follow-Up',
              priority: 'Medium',
              notes: 'New deal approved — follow up with seller in 24 hrs',
              dueDate: new Date(now + 1 * 86400000).toISOString()
            })
            created++
          }

          // Missing docs
          const docCount = (deal.docs?.length || 0) + (get().documents?.[deal.id]?.length || 0)
          if (docCount < 3 && ['Active', 'Blasted'].includes(deal.status)) {
            get().createTask({
              dealId: deal.id,
              type: 'Document Request',
              priority: 'Medium',
              notes: 'Request missing documents / photos / OM',
              dueDate: new Date(now + 2 * 86400000).toISOString()
            })
            created++
          }

          // Closing related
          if (deal.status === 'Closing' || deal.status === 'Under Contract') {
            get().createTask({
              dealId: deal.id,
              type: 'Title / Closing',
              priority: 'High',
              notes: 'Confirm closing details, title, EMD, funding',
              dueDate: new Date(now + 1 * 86400000).toISOString()
            })
            created++
          }
        })

        return created
      },

      generateAutoFollowUpsFromBuyers: () => {
        const deals = get().deals || []
        const buyers = get().buyers || []
        let created = 0
        const now = Date.now()

        // Simple heuristic: active deals with buyer interest but no recent follow-up
        const activeDeals = deals.filter(d => ['Active', 'Blasted', 'Offers Received'].includes(d.status))

        activeDeals.forEach(deal => {
          const matches = get().getMatchesForDeal?.(deal.id) || []
          const strong = matches.filter((m: any) => (m.score || 0) >= 90)

          strong.slice(0, 3).forEach((match: any) => {
            const buyer = buyers.find(b => b.id === match.buyerId)
            if (!buyer) return

            const hasRecent = get().followUps.some(f => 
              f.dealId === deal.id && f.buyerId === buyer.id && !f.completed && 
              new Date(f.dueDate).getTime() > now - 5*86400000
            )
            if (hasRecent) return

            get().createTask({
              dealId: deal.id,
              buyerId: buyer.id,
              type: 'Buyer Follow-Up',
              priority: match.score >= 95 ? 'High' : 'Medium',
              notes: `Strong match (${match.score}%) — follow up on ${deal.property.address}`,
              dueDate: new Date(now + 2 * 86400000).toISOString()
            })
            created++
          })
        })

        return created
      },

      getFollowUpStats: () => {
        const now = new Date()
        const startOfWeek = new Date(now.getTime() - 7 * 86400000)
        const fups = get().followUps || []

        const pending = fups.filter(f => !f.completed).length
        const overdue = fups.filter(f => !f.completed && new Date(f.dueDate) <= now).length
        const dueToday = fups.filter(f => !f.completed && new Date(f.dueDate).toDateString() === now.toDateString()).length
        const completedThisWeek = fups.filter(f => f.completed && new Date(f.dueDate) >= startOfWeek).length
        const autoGenerated = fups.filter(f => (f.notes || '').toLowerCase().includes('auto') || f.type === 'Urgent' || f.type === 'Document Request').length

        return { pending, dueToday, overdue, completedThisWeek, autoGenerated }
      },

      prioritizeFollowUps: (followUps) => {
        // AI-like priority scoring (simulated)
        return [...followUps].sort((a, b) => {
          const score = (f: any) => {
            let s = 0
            const due = new Date(f.dueDate).getTime()
            const now = Date.now()
            if (due < now) s += 100 // Overdue
            if (due < now + 86400000) s += 60 // Due today
            if (f.priority === 'High') s += 40
            if (f.type === 'Urgent' || f.type === 'Title / Closing') s += 35
            if (f.type === 'Seller Follow-Up' || f.type === 'Buyer Follow-Up') s += 20
            if ((f.notes || '').toLowerCase().includes('closing') || (f.notes || '').toLowerCase().includes('financials')) s += 25
            return s
          }
          return score(b) - score(a)
        })
      },

      getBuyerHeatScore: (buyerId) => {
        if (!buyerId || !get().buyers?.length) return 50
        const buyer = get().buyers.find(b => b.id === buyerId)
        if (!buyer) return 50

        let score = 50
        if (buyer.status === 'Hot') score += 20
        if (buyer.strengthScore) score += Math.min(15, buyer.strengthScore / 6)

        const responses = get().buyerResponses[buyerId] || {}
        const interested = Object.values(responses).filter(r => r.status === 'Interested' || r.status === 'Made Offer').length
        score += Math.min(15, interested * 5)

        const offers = Object.values(get().offers).flat().filter(o => o.buyerId === buyerId || o.buyerEmail === buyer.email).length
        score += Math.min(10, offers * 3)

        const suppressions = Object.values(get().dealSuppressions).flat().filter(s => s.buyerId === buyerId).length
        score -= Math.min(15, suppressions * 4)

        return Math.max(20, Math.min(100, Math.round(score)))
      },

      getDealQualityScore: (dealId) => {
        if (!dealId || !get().deals?.length) return { score: 50, grade: 'C', strengths: [], weaknesses: ['No data loaded'] }
        const deal = get().deals.find(d => d.id === dealId)
        if (!deal) return { score: 50, grade: 'C', strengths: [], weaknesses: ['Deal not found'] }

        let score = 40
        const strengths: string[] = []
        const weaknesses: string[] = []

        // Completeness
        const hasDocs = (deal.docs?.length || 0) >= 2
        if (hasDocs) { score += 12; strengths.push('Good documentation') } else { weaknesses.push('Few documents') }

        if (deal.submitter.consent) { score += 8; strengths.push('Consent recorded') } else { weaknesses.push('No consent') }

        if (deal.debt.isFreeClear || deal.debt.titleCompany) { score += 8; strengths.push('Title clarity') } else { weaknesses.push('Title/Debt unclear') }

        // Matches
        const matches = get().getMatchesForDeal(dealId).length
        if (matches >= 8) { score += 12; strengths.push('Strong buyer interest') } 
        else if (matches < 3) { weaknesses.push('Low buyer matches') }

        // Financials
        if (deal.pricing.capRate && deal.pricing.capRate > 7) { score += 8; strengths.push('Solid cap rate') }
        if (deal.pricing.arv && deal.pricing.askingPrice && (deal.pricing.arv / deal.pricing.askingPrice) > 1.4) { score += 8; strengths.push('Good equity spread') }

        // Risk
        if (deal.debt.foreclosure || deal.debt.codeViolations) { score -= 10; weaknesses.push('Title/condition risk') }

        const final = Math.max(25, Math.min(100, Math.round(score)))
        const grade = final >= 85 ? 'A' : final >= 70 ? 'B' : final >= 55 ? 'C' : 'D'

        return { score: final, grade, strengths, weaknesses }
      },

      runSampleWorkflow: () => {
        // Create a realistic sample submitted deal
        const sampleDeal = get().addDeal({
          status: 'Submitted',
          submitter: { name: 'Demo Submitter', email: 'demo@submitter.com', phone: '(555) 123-4567', role: 'Wholesaler', isOwner: false, consent: true },
          property: { address: '456 Demo Lane', city: 'Birmingham', state: 'AL', zip: '35203', county: 'Jefferson', type: 'Multifamily', strategy: 'Value-Add', units: 8, sqft: 6200, occupancy: 'Tenant Occupied' },
          pricing: { askingPrice: 485000, arv: 720000, rehab: 95000, noi: 68000, capRate: 9.2, sellerFinance: false },
          debt: { isFreeClear: false, mortgageBalance: 265000, titleCompany: 'First Title Co' },
          condition: { occupancyStatus: 'Tenant Occupied', walkthroughAvailable: true },
          docs: []
        })

        // Approve it
        get().approveDeal(sampleDeal.id)

        // Simulate buyer matches and a blast
        const topMatches = get().getMatchesForDeal(sampleDeal.id).slice(0, 6)
        const buyerIds = topMatches.map(m => m.buyer.id)
        get().recordBlast(sampleDeal.id, buyerIds)

        get().recordBlastLog(sampleDeal.id, {
          template: 'Multifamily',
          subject: `8-Unit Value-Add in Birmingham — ${sampleDeal.pricing.askingPrice}`,
          recipientCount: buyerIds.length,
          suppressedCount: 0,
          duplicateCount: 0,
          selectedDocNames: ['Photos', 'Rent Roll'],
          ndaRequired: true,
          status: 'Sent'
        })

        // Add mock responses and an offer
        if (topMatches[0]) {
          get().setBuyerResponse(topMatches[0].buyer.id, sampleDeal.id, 'Interested')
        }
        if (topMatches[1]) {
          get().setBuyerResponse(topMatches[1].buyer.id, sampleDeal.id, 'Made Offer')
          get().addOffer(sampleDeal.id, {
            buyerName: topMatches[1].buyer.name,
            buyerEmail: topMatches[1].buyer.email,
            amount: 452000,
            emd: 15000,
            financingType: 'Conventional',
            closingTimeline: '30 days',
            status: 'Reviewing'
          })
        }

        // Schedule follow-up
        get().scheduleFollowUp(sampleDeal.id, undefined, 2, 'Buyer response follow-up')

        // Update status
        get().updateDeal(sampleDeal.id, { status: 'Offers Received' })

        get().logActivity(sampleDeal.id, 'Sample Workflow', 'Auto-generated full demo workflow')

        toast.success('Sample workflow created! Opening the deal...')
        return { dealId: sampleDeal.id }
      },

      // Buyers
      addBuyer: (partial) => {
        const id = 'B' + Date.now().toString(36).toUpperCase()
        const buyer: Buyer = {
          ...partial,
          id,
          createdAt: new Date().toISOString(),
          tags: partial.tags || [],
          assetTypes: partial.assetTypes || [],
          markets: partial.markets || []
        }
        set(s => ({ buyers: [...s.buyers, buyer] }))
        return buyer
      },
      updateBuyer: (id, updates) => {
        set(s => ({
          buyers: s.buyers.map(b => b.id === id ? { ...b, ...updates } : b)
        }))
      },
      importBuyers: (incoming) => {
        const state = get()
        let added = 0, dups = 0, suppressed = 0
        const toAdd: Buyer[] = []
        
        incoming.forEach(b => {
          const emailNorm = b.email.toLowerCase().trim()
          if (state.suppressionList.includes(emailNorm)) {
            suppressed++
            return
          }
          const exists = state.buyers.some(x => x.email.toLowerCase() === emailNorm)
          if (exists) {
            dups++
          } else {
            toAdd.push({
              ...b,
              id: 'B' + Date.now().toString(36).toUpperCase() + added,
              createdAt: new Date().toISOString(),
              tags: b.tags || [],
              assetTypes: b.assetTypes || [],
              markets: b.markets || []
            } as Buyer)
            added++
          }
        })
        
        if (toAdd.length) {
          set(s => ({ buyers: [...s.buyers, ...toAdd] }))
        }
        return { added, dups, suppressed }
      },
      mergeBuyers: (primaryId, toMergeIds) => {
        const state = get()
        const primary = state.buyers.find(b => b.id === primaryId)
        if (!primary) return
        
        const mergedTags = new Set(primary.tags)
        let mergedNotes = primary.notes || ''
        
        toMergeIds.forEach(id => {
          const victim = state.buyers.find(b => b.id === id)
          if (victim) {
            victim.tags.forEach(t => mergedTags.add(t))
            if (victim.notes) mergedNotes += ` | ${victim.notes}`
          }
        })
        
        set(s => ({
          buyers: s.buyers
            .map(b => b.id === primaryId ? { ...b, tags: Array.from(mergedTags), notes: mergedNotes } : b)
            .filter(b => !toMergeIds.includes(b.id))
        }))
      },
      getBuyer: (id) => get().buyers.find(b => b.id === id),
      addToSuppression: (email) => {
        const norm = email.toLowerCase().trim()
        set(s => ({ suppressionList: [...new Set([...s.suppressionList, norm])] }))
      },

      // Matching
      getMatchesForDeal: (dealId) => {
        const deal = get().deals.find(d => d.id === dealId)
        if (!deal) return []
        
        const weights = get().settings.matchingWeights
        const suppressed = get().suppressionList
        
        const results: MatchResult[] = get().buyers
          .filter(b => !suppressed.includes(b.email.toLowerCase()))
          .map(buyer => {
            const { score, reasons, missing } = computeMatchScore(deal, buyer, weights)
            return {
              buyer,
              score,
              tier: getTier(score),
              reasons,
              missing
            }
          })
          .sort((a, b) => b.score - a.score)
        
        return results
      },
      excludeBuyerFromDeal: (dealId, buyerId, reason) => {
        // For demo we just log; real impl could store per-deal exclusions
        get().logActivity(dealId, 'Buyer Excluded', `Buyer ${buyerId} excluded: ${reason}`)
      },

      // Offers
      addOffer: (dealId, offer) => {
        const id = 'O' + Date.now().toString(36)
        const fullOffer: Offer = {
          ...offer,
          id,
          createdAt: new Date().toISOString(),
          history: [{ ts: new Date().toISOString(), note: 'Offer recorded' }]
        }
        set(s => ({
          offers: {
            ...s.offers,
            [dealId]: [...(s.offers[dealId] || []), fullOffer]
          }
        }))
        get().logActivity(dealId, 'Offer Received', `${offer.buyerName} offered $${offer.amount.toLocaleString()}`)
        get().updateDeal(dealId, { status: 'Offers Received' })
      },
      updateOfferStatus: (dealId, offerId, status, counter) => {
        set(s => ({
          offers: {
            ...s.offers,
            [dealId]: (s.offers[dealId] || []).map(o =>
              o.id === offerId
                ? { 
                    ...o, 
                    status, 
                    counterAmount: counter, 
                    history: [...o.history, { ts: new Date().toISOString(), note: `Status → ${status}${counter ? ` (counter $${counter})` : ''}` }] 
                  }
                : o
            )
          }
        }))
      },

      // Documents
      addDocument: (dealId, doc) => {
        const full: Doc = { ...doc, id: 'doc_' + Date.now(), uploadedAt: new Date().toISOString() }
        set(s => ({
          documents: {
            ...s.documents,
            [dealId]: [...(s.documents[dealId] || []), full]
          }
        }))
        get().logActivity(dealId, 'Document Uploaded', `${doc.category}: ${doc.name}`)
      },
      removeDocument: (dealId, docId) => {
        set(s => ({
          documents: {
            ...s.documents,
            [dealId]: (s.documents[dealId] || []).filter(d => d.id !== docId)
          }
        }))
      },
      toggleDocFlag: (dealId, docId, flag) => {
        set(s => ({
          documents: {
            ...s.documents,
            [dealId]: (s.documents[dealId] || []).map(d =>
              d.id === docId ? { ...d, [flag]: !d[flag] } : d
            )
          }
        }))
      },

      // Activity
      logActivity: (dealId, type, description) => {
        const act: Activity = {
          id: 'a' + Date.now(),
          timestamp: new Date().toISOString(),
          type,
          description,
          user: get().user?.name || 'System'
        }
        if (dealId) {
          set(s => ({
            activities: {
              ...s.activities,
              [dealId]: [act, ...(s.activities[dealId] || [])]
            }
          }))
        }
      },
      getActivities: (dealId) => get().activities[dealId] || [],

      // Single source of truth for Needs Attention (pure + respects dismissals)
      getDealAttentionItems: (deal) => {
        if (!deal) return []
        const items: string[] = []
        const docs = deal.docs || []
        const storeDocs = (get().documents?.[deal.id] || [])
        const effectiveDocs = [...docs, ...storeDocs.filter((sd: any) => !docs.some((dd: any) => dd.id === sd.id))]

        const photoCount = effectiveDocs.filter((d: any) => (d.category || '').toLowerCase().includes('photo') || /\.(png|jpe?g|gif|webp)$/i.test(d.name || '')).length

        if ((effectiveDocs.length || 0) < 2 && photoCount === 0) items.push('Photos/Documents')
        if (!deal.pricing?.askingPrice) items.push('Asking Price')
        if (!deal.pricing?.arv) items.push('ARV')
        if (!deal.debt?.isFreeClear && !deal.debt?.titleCompany) items.push('Title/Debt clarity')
        if (!deal.submitter?.consent) items.push('Submitter consent')
        if (deal.status === 'Closing' && !deal.closing?.closingDate) items.push('Closing date')
        if (!deal.condition?.walkthroughAvailable && !deal.condition?.lockbox) items.push('Access info')

        // Filter dismissed
        const dismissed = get().dismissedAttention?.[deal.id]
        if (dismissed && dismissed.issueKeys) {
          return items.filter(it => !dismissed.issueKeys.includes(it))
        }
        return items
      },

      dismissDealAttention: (dealId, issueKeys = []) => {
        const now = new Date().toISOString()
        set(s => ({
          dismissedAttention: {
            ...s.dismissedAttention,
            [dealId]: { dismissedAt: now, issueKeys }
          }
        }))
      },

      clearDealAttention: (dealId) => {
        set(s => {
          const copy = { ...s.dismissedAttention }
          delete copy[dealId]
          return { dismissedAttention: copy }
        })
      },

      // Viewed badges
      markDealViewed: (id) => {
        set(s => ({ viewedDealIds: [...new Set([...s.viewedDealIds, id])] }))
      },
      markBuyerViewed: (id) => {
        set(s => ({ viewedBuyerIds: [...new Set([...s.viewedBuyerIds, id])] }))
      },
      isNewDeal: (id) => {
        const d = get().deals.find(x => x.id === id)
        if (!d) return false
        const viewed = get().viewedDealIds.includes(id)
        const recent = Date.now() - new Date(d.createdAt).getTime() < 1000 * 86400 * 3 // 3 days
        return !viewed && recent
      },
      isNewBuyer: (id) => {
        const b = get().buyers.find(x => x.id === id)
        if (!b) return false
        const viewed = get().viewedBuyerIds.includes(id)
        const recent = Date.now() - new Date(b.createdAt).getTime() < 1000 * 86400 * 2
        return !viewed && recent
      },

      // Blast
      recordBlast: (dealId, buyerIds) => {
        const ok = get().useTrialAction('blastsSent')
        if (!ok) return
        
        get().updateDeal(dealId, { status: 'Blasted' })
        get().logActivity(dealId, 'Deal Blasted', `Blast sent to ${buyerIds.length} buyers`)
        
        // Mark buyers contacted
        buyerIds.forEach(bid => {
          const b = get().getBuyer(bid)
          if (b) get().updateBuyer(bid, { lastContacted: new Date().toISOString(), status: 'Contacted' })
        })
      },

      // Settings
      updateSettings: (updates) => {
        set(s => ({ settings: { ...s.settings, ...updates } }))
      },

      // UI
      toggleSidebar: () => set(s => ({ sidebarOpen: !s.sidebarOpen })),

      // Data
      exportAllData: () => {
        if (isApiMode) {
          // In API mode we would call storage.exportAllData()
          return JSON.stringify({ 
            mode: 'api', 
            message: 'Export via backend not yet implemented',
            exportedAt: new Date().toISOString() 
          }, null, 2)
        }

        const state = get()
        return JSON.stringify({
          deals: state.deals,
          buyers: state.buyers,
          offers: state.offers,
          activities: state.activities,
          settings: state.settings,
          trial: state.trial,
          viewedDealIds: state.viewedDealIds,
          viewedBuyerIds: state.viewedBuyerIds,
          suppressionList: state.suppressionList,
          exportedAt: new Date().toISOString()
        }, null, 2)
      },

      importAllData: async (json) => {
        try {
          const data = JSON.parse(json)

          // Basic shape validation
          if (!data || typeof data !== 'object') {
            throw new Error('Invalid backup format')
          }

          if (isApiMode) {
            // Future: await storage.importAllData(json)
            console.warn('[Storage] API import not implemented yet')
            return
          }

          // Preview counts for safety (we'll surface this in UI later)
          const preview = {
            deals: (data.deals || []).length,
            buyers: (data.buyers || []).length,
            blastLogs: Object.keys(data.blastLogs || {}).length,
            followUps: (data.followUps || []).length,
            hasSettings: !!data.settings
          }

          // Apply data (current demo behavior)
          set({
            deals: data.deals || [],
            buyers: data.buyers || [],
            offers: data.offers || {},
            activities: data.activities || {},
            settings: data.settings || DEFAULT_SETTINGS,
            trial: data.trial || TRIAL_DEFAULT,
            viewedDealIds: data.viewedDealIds || [],
            viewedBuyerIds: data.viewedBuyerIds || [],
            suppressionList: data.suppressionList || [],
            blastLogs: data.blastLogs || {},
            followUps: data.followUps || []
          })

          return preview
        } catch (e) {
          console.error('Import failed', e)
          throw e
        }
      },
      clearAllData: () => {
        set({
          deals: [], buyers: [], offers: {}, activities: {}, documents: {},
          viewedDealIds: [], viewedBuyerIds: [], suppressionList: [],
          trial: TRIAL_DEFAULT
        })
      },
      reseedData: () => {
        const deals = seedDeals()
        const buyers = seedBuyers()
        const offers = seedOffers(deals)
        const activities: Record<string, Activity[]> = {}
        deals.forEach(d => { activities[d.id] = seedActivities(d.id) })
        
        set({
          deals, buyers, offers, activities, documents: {},
          viewedDealIds: [], viewedBuyerIds: []
        })
      }
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        user: state.user,
        trial: state.trial,
        deals: state.deals,
        buyers: state.buyers,
        offers: state.offers,
        activities: state.activities,
        documents: state.documents,
        settings: state.settings,
        viewedDealIds: state.viewedDealIds,
        viewedBuyerIds: state.viewedBuyerIds,
        suppressionList: state.suppressionList,
        blastLogs: state.blastLogs,
        buyerResponses: state.buyerResponses,
        dealSuppressions: state.dealSuppressions,
        followUps: state.followUps,
        dismissedAttention: state.dismissedAttention
      })
    }
  )
)
