
import { Link } from 'react-router-dom'

export default function Security() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12 text-[#E6E8EE]">
      <Link to="/" className="text-sm text-[#3B82F6]">← Back to home</Link>
      <h1 className="text-3xl font-semibold mt-6 mb-4">Security</h1>

      <div className="prose prose-invert text-sm">
        <p className="text-amber-400 font-medium">⚠️ DRAFT PLACEHOLDER — Replace with real security documentation before launch.</p>

        <h2 className="mt-6">Current Demo Security Posture</h2>
        <ul>
          <li>All data lives only in your browser's localStorage.</li>
          <li>No data is transmitted to any server.</li>
          <li>No authentication or user accounts exist in the demo.</li>
          <li>The demo is intended for evaluation only.</li>
        </ul>

        <h2 className="mt-6">Future Production Security</h2>
        <p>Production version will include (at minimum):</p>
        <ul>
          <li>Encryption in transit and at rest</li>
          <li>Proper authentication and authorization</li>
          <li>Team-level data isolation</li>
          <li>Audit logging</li>
          <li>Regular security reviews</li>
        </ul>

        <p className="mt-8 text-xs text-[#8B92A3]">Last updated: Demo version • This is not legal advice.</p>

        <footer className="border-t border-[#252A38] mt-12 py-6 text-center text-xs text-[#8B92A3]">
          House Buyer Investments • Deal Blast Pro<br />
          <Link to="/pricing" className="hover:text-white">Pricing</Link> · 
          <Link to="/portal" className="hover:text-white">Submit Deal</Link> · 
          <Link to="/contact" className="hover:text-white">Contact</Link> · 
          <Link to="/privacy" className="hover:text-white">Privacy</Link> · 
          <Link to="/terms" className="hover:text-white">Terms</Link> · 
          <Link to="/security" className="hover:text-white">Security</Link>
        </footer>
      </div>
    </div>
  )
}
