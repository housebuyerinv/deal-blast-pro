import React, { useEffect } from 'react'
import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { useAppStore } from './store/useAppStore'

// Public pages
import Landing from './pages/public/Landing'
import Portal from './pages/public/Portal'
import Login from './pages/public/Login'
import Register from './pages/public/Register'
import ForgotPassword from './pages/public/ForgotPassword'

// App shell + protected pages
import AppShell from './components/layout/AppShell'
import Dashboard from './pages/app/Dashboard'
import Submissions from './pages/app/Submissions'
import Inventory from './pages/app/Inventory'
import Buyers from './pages/app/Buyers'
import Blast from './pages/app/Blast'
import DealCalculator from './pages/app/DealCalculator'
import Settings from './pages/app/Settings'
import ManualIntake from './pages/app/ManualIntake'
import FollowUps from './pages/app/FollowUps'
import Analytics from './pages/app/Analytics'
import Pipeline from './pages/app/Pipeline'
import OnboardingTour from './components/OnboardingTour'
import Privacy from './pages/public/Privacy'
import Terms from './pages/public/Terms'
import Security from './pages/public/Security'
import Pricing from './pages/public/Pricing'
import Contact from './pages/public/Contact'

// Shared
import { ErrorBoundary } from './components/ui/ErrorBoundary'

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const user = useAppStore(s => s.user)
  const location = useLocation()
  
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }
  return <>{children}</>
}

function App() {
  const initializeStore = useAppStore(s => s.initialize)

  useEffect(() => {
    // Initialize store with mock data + persisted state on first mount. Empty deps + internal guards prevent any repeated sets or loops.
    initializeStore()
  }, [])

  return (
    <ErrorBoundary>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Landing />} />
        <Route path="/portal" element={<Portal />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/security" element={<Security />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/contact" element={<Contact />} />

        {/* Protected app routes - persistent sidebar always present */}
        <Route
          path="/app/*"
          element={
            <ProtectedRoute>
              <AppShell>
                <OnboardingTour />
                <Routes>
                  <Route path="dashboard" element={<Dashboard />} />
                  <Route path="submissions" element={<Submissions />} />
                  <Route path="inventory" element={<Inventory />} />
                  <Route path="buyers" element={<Buyers />} />
                  <Route path="blast" element={<Blast />} />
                  <Route path="calculator" element={<DealCalculator />} />
                  <Route path="settings" element={<Settings />} />
                  <Route path="intake" element={<ManualIntake />} />
                  <Route path="followups" element={<FollowUps />} />
                  <Route path="analytics" element={<Analytics />} />
                  <Route path="pipeline" element={<Pipeline />} />
                  <Route path="*" element={<Navigate to="dashboard" replace />} />
                </Routes>
              </AppShell>
            </ProtectedRoute>
          }
        />

        {/* Fallbacks */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </ErrorBoundary>
  )
}

export default App
