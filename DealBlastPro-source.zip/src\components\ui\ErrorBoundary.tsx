import React from 'react'

interface Props {
  children: React.ReactNode
  fallback?: React.ReactNode
}

interface State {
  hasError: boolean
  error?: Error
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Deal Blast Pro ErrorBoundary caught:', error, errorInfo)
  }

  reset = () => {
    this.setState({ hasError: false, error: undefined })
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="card p-8 m-6 text-center">
          <div className="text-4xl mb-4">⚠️</div>
          <h2 className="text-xl font-semibold mb-2">Something went wrong</h2>
          <p className="text-[#8B92A3] mb-4">A component failed to render. This deal may have corrupted data.</p>
          <div className="flex gap-3 justify-center">
            <button onClick={this.reset} className="btn btn-ghost">Try Again</button>
            <button 
              onClick={() => window.location.reload()} 
              className="btn btn-primary"
            >
              Reload App
            </button>
          </div>
          {this.state.error && (
            <div className="mt-4 text-left text-xs font-mono bg-black/40 p-3 rounded text-red-400 overflow-auto max-h-32">
              {this.state.error.message}
            </div>
          )}
        </div>
      )
    }
    return this.props.children
  }
}

export function SectionErrorBoundary({ children }: { children: React.ReactNode }) {
  return (
    <ErrorBoundary fallback={
      <div className="panel p-4 text-sm text-[#8B92A3]">
        Section failed to load. <button onClick={() => window.location.reload()} className="underline">Refresh</button>
      </div>
    }>
      {children}
    </ErrorBoundary>
  )
}
