import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAppStore } from '../../store/useAppStore'

export default function Login() {
  const [email, setEmail] = useState('alex@dealblast.pro')
  const [password, setPassword] = useState('demo123')
  const login = useAppStore(s => s.login)
  const navigate = useNavigate()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    login(email, 'Alex Rivera')
    navigate('/app/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0A0C12] p-6">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 bg-[#22C55E] rounded flex items-center justify-center text-black font-black text-2xl">D</div>
            <span className="font-semibold text-2xl tracking-[-1px]">DEAL BLAST PRO</span>
          </Link>
        </div>

        <div className="card p-8">
          <div className="text-2xl font-semibold mb-1">Welcome back</div>
          <div className="text-[#8B92A3] mb-6">Sign in to your workspace</div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <div className="text-xs text-[#8B92A3] mb-1.5">EMAIL</div>
              <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} required />
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1.5">PASSWORD</div>
              <input className="input" type="password" value={password} onChange={e => setPassword(e.target.value)} required />
            </div>
            <button type="submit" className="btn btn-primary w-full py-3">Sign In</button>
          </form>

          <div className="mt-4 text-center text-sm">
            <Link to="/forgot-password" className="text-[#3B82F6]">Forgot password?</Link>
            <span className="mx-2 text-[#8B92A3]">·</span>
            <Link to="/register" className="text-[#3B82F6]">Create account</Link> · 
            <Link to="/pricing" className="text-[#3B82F6]">Pricing</Link>
          </div>
        </div>

        <div className="mt-6 text-center">
          <button 
            onClick={() => {
              login('demo@dealblast.pro', 'Demo User')
              navigate('/app/dashboard')
            }} 
            className="btn btn-ghost w-full mb-3"
          >
            Use Demo Login
          </button>
          <div className="text-xs text-[#8B92A3] mb-2">No real account is required for the local demo.</div>
          <Link to="/portal" className="text-sm text-[#3B82F6]">Submit a Deal Without Logging In →</Link>
        </div>

        <footer className="border-t border-[#252A38] mt-8 py-6 text-center text-xs text-[#8B92A3]">
          House Buyer Investments • Deal Blast Pro<br />
          <Link to="/pricing" className="hover:text-white">Pricing</Link> · 
          <Link to="/portal" className="hover:text-white">Submit Deal</Link> · 
          <Link to="/contact" className="hover:text-white">Contact</Link> · 
          <Link to="/privacy" className="hover:text-white">Privacy</Link> · 
          <Link to="/terms" className="hover:text-white">Terms</Link> · 
          <Link to="/security" className="hover:text-white">Security</Link>
        </footer>
      </div>
    </div>
  )
}
