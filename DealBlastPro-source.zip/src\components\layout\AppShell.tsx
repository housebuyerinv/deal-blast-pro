import React, { useState, useEffect } from 'react'
import Sidebar from './Sidebar'
import Topbar from './Topbar'
import { useAppStore } from '../../store/useAppStore'
import { SectionErrorBoundary } from '../ui/ErrorBoundary'
import { useNavigate } from 'react-router-dom'
import { isApiMode } from '../../services/storage'

export default function AppShell({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [cmdOpen, setCmdOpen] = useState(false)
  const [cmdQuery, setCmdQuery] = useState('')

  const { deals, buyers, followUps, setCurrentDeal } = useAppStore()
  const navigate = useNavigate()

  const currentDealId = useAppStore(s => s.currentDealId)

  // Command palette hotkey (Cmd/Ctrl + K)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setCmdOpen(o => !o)
        setCmdQuery('')
      }
      if (e.key === 'Escape') setCmdOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const q = cmdQuery.toLowerCase().trim()

  const dealResults = deals.filter(d => 
    d.property.address.toLowerCase().includes(q) || 
    d.property.city.toLowerCase().includes(q) ||
    d.status.toLowerCase().includes(q)
  ).slice(0, 5).map(d => ({ 
    group: "Deals", 
    label: `${d.property.address} (${d.status})`, 
    action: () => { useAppStore.getState().safeOpenDeal(d.id); setCmdOpen(false) } 
  }))

  const buyerResults = buyers.filter(b => 
    b.name.toLowerCase().includes(q) || 
    b.email.toLowerCase().includes(q) ||
    b.markets?.some(m => m.toLowerCase().includes(q))
  ).slice(0, 5).map(b => ({ 
    group: "Buyers", 
    label: `${b.name} — ${b.email}`, 
    action: () => { navigate('/app/buyers'); setCmdOpen(false) } 
  }))

  const followupResults = followUps.filter(f => !f.completed).slice(0, 3).map(f => ({
    group: "Follow-Ups",
    label: `Follow-up on Deal ${f.dealId}`,
    action: () => { navigate('/app/followups'); setCmdOpen(false) }
  }))

  const pageResults = [
    { group: 'Pages', label: "Dashboard", action: () => { navigate('/app/dashboard'); setCmdOpen(false) } },
    { group: 'Pages', label: "Pipeline Board", action: () => { navigate('/app/pipeline'); setCmdOpen(false) } },
    { group: 'Pages', label: "Analytics", action: () => { navigate('/app/analytics'); setCmdOpen(false) } },
    { group: 'Pages', label: "Blast Builder", action: () => { navigate('/app/blast'); setCmdOpen(false) } },
    { group: 'Pages', label: "Follow-Up Center", action: () => { navigate('/app/followups'); setCmdOpen(false) } },
  ].filter(p => p.label.toLowerCase().includes(q))

  const filteredCommands = [...dealResults, ...buyerResults, ...followupResults, ...pageResults]
    .filter(c => !q || c.label.toLowerCase().includes(q))

  return (
    <div className="min-h-screen flex bg-[#0A0C12] text-[#E6E8EE]">
      <Sidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />

      <div className="flex-1 flex flex-col min-w-0">
        {isApiMode && (
          <div className="bg-amber-500/10 text-amber-400 text-xs text-center py-1 border-b border-amber-500/30">
            API mode active — backend not connected (using stub). All data is in demo mode.
          </div>
        )}
        <Topbar onMenuClick={() => setMobileOpen(!mobileOpen)} />
        
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          <SectionErrorBoundary>
            {children}
          </SectionErrorBoundary>
        </main>
      </div>

      {/* Global Deal Terminal Drawer */}
      {currentDealId && (
        <DealTerminalDrawer dealId={currentDealId} onClose={() => setCurrentDeal(null)} />
      )}

      {/* Command Palette */}
      {cmdOpen && (
        <div className="fixed inset-0 z-[300] flex items-start justify-center pt-24 bg-black/60" onClick={() => setCmdOpen(false)}>
          <div className="card w-full max-w-lg mx-4" onClick={e => e.stopPropagation()}>
            <input 
              autoFocus 
              className="input rounded-b-none border-b-0 text-lg" 
              placeholder="Type to search deals, buyers, pages... (Esc to close)" 
              value={cmdQuery} 
              onChange={e => setCmdQuery(e.target.value)} 
            />
            <div className="max-h-80 overflow-auto p-1 text-sm">
              {filteredCommands.length === 0 && <div className="p-4 text-[#8B92A3]">No matches</div>}
              {filteredCommands.map((cmd, i) => (
                <div key={i} onClick={cmd.action} className="px-3 py-2 hover:bg-[#171B26] rounded cursor-pointer">
                  {cmd.group && <span className="text-[#8B92A3] text-[10px] mr-2">[{cmd.group}]</span>}
                  {cmd.label}
                </div>
              ))}
            </div>
            <div className="text-[10px] text-[#8B92A3] p-2 border-t border-[#252A38]">Cmd/Ctrl+K to toggle • Esc to close</div>
          </div>
        </div>
      )}
    </div>
  )
}

// Lazy import to avoid circular issues during early scaffold
import DealTerminalDrawer from '../inventory/DealTerminalDrawer'
