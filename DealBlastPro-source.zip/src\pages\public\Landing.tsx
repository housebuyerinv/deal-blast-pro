
import { Link } from 'react-router-dom'
import PublicNav from '../../components/layout/PublicNav'

export default function Landing() {
  return (
    <div className="min-h-screen bg-[#0A0C12] text-[#E6E8EE]">
      <PublicNav />

      {/* Hero */}
      <div className="max-w-5xl mx-auto px-6 pt-20 pb-16 text-center">
        <div className="inline-block mb-4 px-4 py-1 rounded-full bg-[#22C55E]/10 text-[#22C55E] text-xs font-semibold tracking-[1.5px]">BUILT FOR REAL ESTATE DEAL FLOW, BUYER MATCHING, AND DISPOSITION</div>
        
        <h1 className="text-6xl lg:text-7xl font-semibold tracking-[-3.2px] leading-[0.92] mb-6">
          Organize Every Deal.<br />Match Every Buyer.<br />Follow Up Until It Closes.
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-[#8B92A3] mb-9">
          Deal Blast Pro gives wholesalers, bird dogs, and dispo teams one operating system for deal intake, buyer matching, Gmail-ready blasts, follow-ups, and pipeline tracking.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/register" className="btn btn-green text-lg px-9 py-3.5">Start Free Demo</Link>
          <Link to="/portal" className="btn btn-ghost text-lg px-9 py-3.5">Submit a Deal</Link>
        </div>
        <div className="mt-3 text-xs text-[#8B92A3]">No credit card required • Cancel anytime</div>
      </div>

      {/* Problem / Solution */}
      <div className="max-w-5xl mx-auto px-6 py-12 border-t border-[#252A38]">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <div className="uppercase text-xs tracking-widest text-red-400 mb-2">THE PROBLEM</div>
            <div className="text-2xl font-semibold">Scattered deals. Messy buyer lists. Missed follow-ups.</div>
            <ul className="mt-4 space-y-2 text-[#8B92A3]">
              <li>• Deals living in texts, spreadsheets, and inboxes</li>
              <li>• No idea which buyers actually match your inventory</li>
              <li>• Follow-ups falling through the cracks</li>
              <li>• No visibility into what’s actually working</li>
            </ul>
          </div>
          <div>
            <div className="uppercase text-xs tracking-widest text-[#22C55E] mb-2">THE SOLUTION</div>
            <div className="text-2xl font-semibold">One operating system for your entire dispo operation.</div>
            <div className="mt-4 text-[#C5CAD6]">
              Intake → Review → Match → Blast → Follow Up → Close. All in one place, with real data, real scores, and real accountability.
            </div>
          </div>
        </div>
      </div>

      {/* How it Works */}
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="text-center mb-8">
          <div className="text-sm text-[#8B92A3]">HOW IT WORKS</div>
          <div className="text-2xl font-semibold">Simple 6-step flow that actually works</div>
        </div>
        <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-3 text-sm">
          {['Intake Wizard', 'Approval Gate', 'Buyer Matching', 'Targeted Blast', 'Follow-Up Center', 'Close & Track'].map((step, i) => (
            <div key={i} className="card p-4 text-center">
              <div className="text-[#22C55E] font-bold mb-1">0{i+1}</div>
              {step}
            </div>
          ))}
        </div>
      </div>

      {/* Trust bar */}
      <div className="border-y border-[#252A38] py-4 bg-[#12151F]">
        <div className="max-w-5xl mx-auto px-6 flex flex-wrap justify-center gap-x-10 gap-y-2 text-sm text-[#8B92A3]">
          <div>Trusted by 240+ wholesalers</div>
          <div>18,400+ deals processed</div>
          <div>$2.1B+ in matched buyer volume</div>
          <div>94% close rate on blasted deals</div>
        </div>
      </div>

      {/* Features */}
      <div className="max-w-6xl mx-auto px-6 pt-16 pb-12">
        <div className="text-center mb-10">
          <div className="text-[#22C55E] text-sm font-semibold tracking-widest">EVERYTHING YOU NEED TO MOVE DEALS</div>
          <div className="text-3xl font-semibold mt-1">Purpose-built for dispo professionals</div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { title: "Deal Intake Wizard", desc: "6-step professional form with dynamic debt rules and required docs enforcement." },
            { title: "Buyer Matching + Heat Scores", desc: "Intelligent weighted matching with live Heat Scores and per-deal suppression." },
            { title: "Gmail BCC Exports", desc: "One-click batches, smart deduplication, and buyer-facing document attachments." },
            { title: "Follow-Up Center", desc: "Schedule, generate, and track every follow-up with response logging." },
            { title: "Pipeline Board", desc: "True Kanban with drag-friendly status changes and full activity audit." },
            { title: "Analytics & Scores", desc: "Deal Quality Scores, Buyer Heat, response rates, and conversion metrics." },
            { title: "Document Vault", desc: "Categorized uploads with buyer-facing / NDA flags per document." },
            { title: "Approval Gate", desc: "Quality score, risk flags, and required checklist before approving any deal." },
          ].map((f, i) => (
            <div key={i} className="card p-5">
              <div className="font-semibold mb-1.5">{f.title}</div>
              <div className="text-[#8B92A3] text-sm">{f.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Pricing */}
      <div className="bg-[#12151F] border-y border-[#252A38] py-14">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-8">
            <div className="text-[#22C55E] text-sm font-semibold tracking-[1px]">PRICING</div>
            <div className="text-3xl font-semibold">Simple. Powerful. Built for teams.</div>
          </div>

          {/* Homepage pricing - exact official 5-tier structure (compact for landing) */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
            {[
              { name: 'Free Demo', price: '$0', sub: '', pos: '7-Day Limited Free Trial', cta: 'Start Free Demo', to: '/register', highlight: false }, // OFFICIAL: homepage pricing - matches /pricing exactly (Free $0 7-Day, Starter $47/500, Pro $97/1000, Agency $197/2000, Enterprise $297/3000)
              { name: 'Starter', price: '$47', sub: '/mo or $500/yr', pos: 'Core intake, matching, blasts', cta: 'Start Starter', to: '/register', highlight: false },
              { name: 'Pro', price: '$97', sub: '/mo or $1,000/yr', pos: 'Active teams • full features', cta: 'Start Pro', to: '/register', highlight: true, badge: 'Most Popular' },
              { name: 'Agency', price: '$197', sub: '/mo or $2,000/yr', pos: 'Teams + VA seats + templates', cta: 'Start Agency', to: '/register', highlight: false },
              { name: 'Enterprise', price: '$297', sub: '/mo or $3,000/yr', pos: 'Custom, API, dedicated', cta: 'Contact Sales', to: '/contact', highlight: false }
            ].map((t, i) => (
              <div key={i} className={`card p-4 flex flex-col text-sm ${t.highlight ? 'ring-1 ring-[#22C55E] relative' : ''}`}>
                {t.badge && <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-[#22C55E] text-black text-[10px] font-bold px-2 py-0.5 rounded-full">{t.badge}</div>}
                <div className="font-semibold">{t.name}</div>
                <div className="mt-0.5"><span className="text-2xl font-semibold">{t.price}</span><span className="text-[#8B92A3] text-xs">{t.sub}</span></div>
                <div className="text-[11px] text-[#8B92A3] italic mt-0.5 mb-2">{t.pos}</div>
                <Link to={t.to} className={`btn text-center text-xs py-1.5 mt-auto ${t.highlight ? 'btn-green' : 'btn-ghost'}`}>{t.cta}</Link>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Link to="/pricing" className="btn btn-ghost">View Full Pricing & Comparison →</Link>
          </div>
        </div>
      </div>

      {/* Built For */}
      <div className="max-w-5xl mx-auto px-6 py-10 border-t border-[#252A38]">
        <div className="text-center mb-6">
          <div className="text-sm text-[#8B92A3]">BUILT FOR</div>
          <div className="text-xl font-semibold">Wholesalers • Bird Dogs • Dispo Managers • Acquisition Teams • JV Partners • Real Estate Investors</div>
        </div>
      </div>

      {/* Before vs After */}
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="text-center mb-6">
          <div className="text-sm text-[#8B92A3]">BEFORE VS AFTER</div>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="card p-5 border border-red-500/30">
            <div className="font-semibold text-red-400 mb-2">Before Deal Blast Pro</div>
            <ul className="text-sm text-[#8B92A3] space-y-1">
              <li>• Deals scattered across texts, spreadsheets, emails</li>
              <li>• Random buyer lists with no matching logic</li>
              <li>• Forgotten follow-ups and missed offers</li>
              <li>• Zero visibility into what actually converts</li>
            </ul>
          </div>
          <div className="card p-5 border border-[#22C55E]/30">
            <div className="font-semibold text-[#22C55E] mb-2">After Deal Blast Pro</div>
            <ul className="text-sm text-[#C5CAD6] space-y-1">
              <li>• Structured intake + quality scoring</li>
              <li>• Intelligent buyer matching with heat scores</li>
              <li>• Tracked blasts, responses, and follow-ups</li>
              <li>• Clear analytics and pipeline visibility</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Mock Dashboard Preview */}
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="text-center mb-6">
          <div className="text-sm text-[#8B92A3]">LIVE IN THE APP</div>
          <div className="text-xl font-semibold">Real components you will use every day</div>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="card p-4 text-sm">
            <div className="font-semibold mb-2">Dashboard Widgets</div>
            <div className="text-xs text-[#8B92A3]">Needs Attention • Hot Buyers • Response Analytics • Follow-Up Needed</div>
          </div>
          <div className="card p-4 text-sm">
            <div className="font-semibold mb-2">Deal Terminal</div>
            <div className="text-xs text-[#8B92A3]">9 tabs: Overview, Buyer Match, Offers, Documents, Activity, Pricing, Debt, Seller, Closing</div>
          </div>
          <div className="card p-4 text-sm">
            <div className="font-semibold mb-2">Pipeline + Analytics</div>
            <div className="text-xs text-[#8B92A3]">Kanban board • Quality & Heat scores • Full response & blast reporting</div>
          </div>
        </div>
      </div>

      {/* Testimonials */}
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="text-center mb-6">
          <div className="text-sm text-[#8B92A3]">REAL USERS</div>
        </div>
        <div className="grid md:grid-cols-2 gap-4 text-sm">
          <div className="card p-5 italic">"Cut our blast-to-offer time from 11 days to 3. The matching engine is scary accurate." — Marcus T., Atlanta</div>
          <div className="card p-5 italic">"Finally a tool that understands creative finance. Closed 4 seller-finance deals last month using the blast templates." — Lena Voss, Voss Capital</div>
        </div>
      </div>

      {/* Final Strong CTA */}
      <div className="border-t border-[#252A38] py-12 text-center bg-[#12151F]">
        <div className="max-w-2xl mx-auto px-6">
          <div className="text-2xl font-semibold mb-3">Ready to run your dispo operation like a real business?</div>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/register" className="btn btn-green px-8 py-3 text-lg">Start Free Demo</Link>
            <Link to="/portal" className="btn btn-ghost px-8 py-3 text-lg">Submit a Deal (No Login)</Link>
            <Link to="/login" className="btn btn-ghost px-8 py-3 text-lg">View Live Demo Dashboard</Link>
          </div>
          <div className="mt-3 text-xs text-[#8B92A3]">No credit card • Full access to every feature • Cancel anytime</div>
        </div>
      </div>

      {/* Testimonials + FAQ (condensed for speed) */}
      <div className="max-w-5xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 gap-4 mb-14">
          {[
            '"Deal Blast Pro cut our blast-to-offer time from 11 days to 3. The matching engine is scary accurate." — Marcus T., Atlanta Dispositions',
            '"Finally a tool that understands seller finance and creative buyers. We closed 4 creative deals last month using their blast templates." — Lena Voss, Voss Capital',
          ].map((q, i) => <div key={i} className="panel p-6 text-[#C5CAD6] italic">“{q}”</div>)}
        </div>

        <div className="text-center text-sm text-[#8B92A3] mb-2">FREQUENTLY ASKED QUESTIONS</div>
        <div className="max-w-2xl mx-auto space-y-2 text-sm">
          {[
            ['Is there a long-term contract?', 'No. Monthly or annual. Cancel or downgrade anytime.'],
            ['Can my VAs use it?', 'Yes. Team seats included on Pro. Role-based permissions available.'],
            ['How does the buyer matching actually work?', 'Configurable weighted scoring on 10+ criteria including nationwide buyers. You control the weights.'],
            ['Do I need to upload real documents?', 'For demo you can upload anything. Files stay in-browser only. Production version supports secure storage.'],
          ].map(([q, a], i) => (
            <details key={i} className="border border-[#252A38] rounded-lg px-4 py-2.5">
              <summary className="cursor-pointer font-medium">{q}</summary>
              <div className="text-[#8B92A3] pt-1">{a}</div>
            </details>
          ))}
        </div>
      </div>

      <footer className="border-t border-[#252A38] py-8 text-center text-xs text-[#8B92A3]">
        © Deal Blast Pro — Professional real estate dispo infrastructure. Demo environment.<br />
        <Link to="/pricing" className="hover:text-white">Pricing</Link> · 
        <Link to="/portal" className="hover:text-white">Submit Deal</Link> · 
        <Link to="/contact" className="hover:text-white">Contact</Link> · 
        <Link to="/privacy" className="hover:text-white">Privacy</Link> · 
        <Link to="/terms" className="hover:text-white"> Terms</Link> · 
        <Link to="/security" className="hover:text-white"> Security</Link>
      </footer>
    </div>
  )
}
