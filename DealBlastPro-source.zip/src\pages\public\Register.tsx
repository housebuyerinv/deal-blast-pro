import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAppStore } from '../../store/useAppStore'

export default function Register() {
  const [form, setForm] = useState({ name: 'Alex Rivera', email: 'alex@dealblast.pro', company: 'Apex Acquisitions', role: 'Admin' as const })
  const login = useAppStore(s => s.login)
  const navigate = useNavigate()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    login(form.email, form.name)
    navigate('/app/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0A0C12] p-6">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-6">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 bg-[#22C55E] rounded flex items-center justify-center text-black font-black text-2xl">D</div>
            <span className="font-semibold text-2xl tracking-[-1px]">DEAL BLAST PRO</span>
          </Link>
        </div>

        <div className="card p-8">
          <div className="text-2xl font-semibold mb-1">Create your account</div>
          <div className="text-[#8B92A3] mb-6">Start your free demo — full access, no card required</div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <div className="text-xs text-[#8B92A3] mb-1.5">FULL NAME</div>
              <input className="input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-[#8B92A3] mb-1.5">EMAIL</div>
                <input className="input" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
              </div>
              <div>
                <div className="text-xs text-[#8B92A3] mb-1.5">COMPANY</div>
                <input className="input" value={form.company} onChange={e => setForm({ ...form, company: e.target.value })} />
              </div>
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1.5">YOUR ROLE</div>
              <select className="select w-full" value={form.role} onChange={e => setForm({ ...form, role: e.target.value as any })}>
                <option>Admin</option><option>Team Member / VA</option><option>Buyer</option><option>Seller / Submitter</option>
              </select>
            </div>
            <button type="submit" className="btn btn-green w-full py-3">Create Account &amp; Enter Trial</button>
          </form>
        </div>
        <div className="text-center text-sm mt-4">Already have an account? <Link to="/login" className="text-[#3B82F6]">Sign in</Link> · <Link to="/pricing" className="text-[#3B82F6]">Pricing</Link></div>

        <footer className="border-t border-[#252A38] mt-8 py-6 text-center text-xs text-[#8B92A3]">
          House Buyer Investments • Deal Blast Pro<br />
          <Link to="/pricing" className="hover:text-white">Pricing</Link> · 
          <Link to="/portal" className="hover:text-white">Submit Deal</Link> · 
          <Link to="/contact" className="hover:text-white">Contact</Link> · 
          <Link to="/privacy" className="hover:text-white">Privacy</Link> · 
          <Link to="/terms" className="hover:text-white">Terms</Link> · 
          <Link to="/security" className="hover:text-white">Security</Link>
        </footer>
      </div>
    </div>
  )
}
