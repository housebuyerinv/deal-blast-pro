import { useState } from 'react'
import { useAppStore } from '../../store/useAppStore'
import { Link } from 'react-router-dom'
import { toast } from 'sonner'

export default function Submissions() {
  const { getSubmissionsQueue, approveDeal, markDealViewed, updateDeal, logActivity } = useAppStore()
  const subs = getSubmissionsQueue()
  const [approvalDeal, setApprovalDeal] = useState<any>(null)

  return (
    <div>
      <div className="flex justify-between mb-5 items-center">
        <div>
          <div className="text-xs tracking-widest text-[#8B92A3]">DEAL FLOW</div>
          <div className="text-2xl font-semibold">Deal Submissions Queue</div>
        </div>
        <Link to="/portal" className="btn btn-green">+ New Submission</Link>
      </div>

      {subs.length === 0 && <div className="panel p-8 text-center text-[#8B92A3]">No pending submissions. Submit via the Public Portal.</div>}

      {/* Stronger Approval Gate Modal */}
      {approvalDeal && (
        <div className="fixed inset-0 bg-black/70 z-[200] flex items-center justify-center p-4">
          <div className="card w-full max-w-2xl p-6">
            <div className="font-semibold mb-1">Approval Gate — {approvalDeal.property.address}</div>
            <div className="text-sm text-[#8B92A3] mb-4">Review quality before moving to Inventory</div>

            {(() => {
              const q = useAppStore.getState().getDealQualityScore(approvalDeal.id)
              return (
                <div className="mb-4">
                  <div className="flex items-center gap-3">
                    <div className="text-3xl font-semibold">{q.score}</div>
                    <div><span className="badge text-lg px-3 py-1">{q.grade}</span></div>
                  </div>
                  <div className="text-xs mt-1">Strengths: {q.strengths.join(' • ') || 'None flagged'}<br />Weaknesses: {q.weaknesses.join(' • ') || 'None flagged'}</div>
                </div>
              )
            })()}

            <div className="flex flex-wrap gap-2 mt-4">
              <button onClick={() => { approveDeal(approvalDeal.id); setApprovalDeal(null); toast.success('Approved to Inventory') }} className="btn btn-green">Approve to Inventory</button>
              <button onClick={() => { updateDeal(approvalDeal.id, { status: 'Needs Info' }); logActivity(approvalDeal.id, 'Approval Decision', 'Request More Info'); setApprovalDeal(null); toast('Marked Needs Info') }} className="btn btn-ghost">Request More Info</button>
              <button onClick={() => { updateDeal(approvalDeal.id, { status: 'Dead' }); logActivity(approvalDeal.id, 'Approval Decision', 'Rejected'); setApprovalDeal(null); toast('Rejected') }} className="btn btn-ghost text-red-400">Reject</button>
              <button onClick={() => setApprovalDeal(null)} className="btn btn-ghost ml-auto">Cancel</button>
            </div>
          </div>
        </div>
      )}

      <div className="grid gap-3">
        {subs.map(deal => (
          <div key={deal.id} className="card p-4 flex justify-between items-center">
            <div>
              <div className="font-medium">{deal.property.address}</div>
              <div className="text-sm text-[#8B92A3]">{deal.property.city}, {deal.property.state} • {deal.submitter.name} {deal.source ? `• ${deal.source}` : ''}</div>
              {useAppStore.getState().isNewDeal(deal.id) && <span className="badge bg-[#22C55E] text-black text-xs ml-2">NEW</span>}
            </div>
            <div className="flex gap-2">
              <button onClick={() => { markDealViewed(deal.id); useAppStore.getState().safeOpenDeal(deal.id) }} className="btn btn-ghost">Review Full Deal</button>
              <button onClick={() => setApprovalDeal(deal)} className="btn btn-green">Review & Approve</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
