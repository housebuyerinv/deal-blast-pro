import React, { useState, useEffect } from 'react'
import { useAppStore } from '../../store/useAppStore'
import { toast } from 'sonner'
import { Calculator, Copy, Save, Download, ChevronLeft, TrendingUp, Wrench, Target, Home, Coins } from 'lucide-react'
import { Link, useSearchParams } from 'react-router-dom'

type CalcTab = 'arv' | 'rehab' | 'mao' | 'rental' | 'creative'

interface TabDef {
  id: CalcTab
  label: string
  icon: React.ComponentType<any>
}

const tabs: TabDef[] = [
  { id: 'arv', label: 'ARV Calculator', icon: TrendingUp },
  { id: 'rehab', label: 'Rehab Calculator', icon: Wrench },
  { id: 'mao', label: 'MAO / Offer Calculator', icon: Target },
  { id: 'rental', label: 'Rental Deal Calculator', icon: Home },
  { id: 'creative', label: 'Creative Finance Calculator', icon: Coins },
]

// Local ErrorBoundary — defined only inside this file.
// Any future error inside Deal Calculator is caught here and cannot poison
// the shared AppShell, SectionErrorBoundary, or sibling routes.
class LocalDealCalcBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: any) {
    super(props)
    this.state = { hasError: false }
  }
  static getDerivedStateFromError() {
    return { hasError: true }
  }
  componentDidCatch(error: Error, info: any) {
    console.error('Deal Calculator local boundary caught (isolated):', error, info)
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 text-center">
          <div className="text-2xl font-semibold mb-3">Deal Calculator</div>
          <p className="text-[#8B92A3] mb-4">
            Calculator tools temporarily disabled while repair is completed.
          </p>
          <Link to="/app/inventory" className="btn btn-primary">
            Back to Inventory Hub
          </Link>
        </div>
      )
    }
    return this.props.children
  }
}

export default function DealCalculator() {
  // ARV-only state for Step 1 (safe defaults, no selected deal required)
  const [activeTab, setActiveTab] = useState<'arv' | 'rehab' | 'mao' | 'rental' | 'creative'>('arv')

  const [arvComps, setArvComps] = useState<Array<{
    salePrice: number;
    beds?: number;
    baths?: number;
    sqft: number;
    distance?: number;
    conditionNotes?: string;
    optionalAdj?: number;
  }>>([
    { salePrice: 0, sqft: 0 }, { salePrice: 0, sqft: 0 }, { salePrice: 0, sqft: 0 }, { salePrice: 0, sqft: 0 }, { salePrice: 0, sqft: 0 }
  ])
  const [subjectSqft, setSubjectSqft] = useState<number>(0)
  const [subjectBeds, setSubjectBeds] = useState<number>(0)
  const [subjectBaths, setSubjectBaths] = useState<number>(0)
  const [subjectAddress, setSubjectAddress] = useState('')
  const [subjectPropertyType, setSubjectPropertyType] = useState('')
  const [subjectConditionNotes, setSubjectConditionNotes] = useState('')
  const [adjustment, setAdjustment] = useState<number>(0)
  const [adjType, setAdjType] = useState<'$' | '%'>('$')

  const [arvNotes, setArvNotes] = useState('')

  // Rehab state - safe default shape only (Step 2)
  const [rehabItems, setRehabItems] = useState([
    { id: 1, category: 'Kitchen', scope: 'Medium', cost: 3800, notes: '' },
    { id: 2, category: 'Bathrooms', scope: 'Medium', cost: 2400, notes: '' },
    { id: 3, category: 'Paint', scope: 'Light', cost: 1200, notes: '' },
    { id: 4, category: 'Flooring', scope: 'Light', cost: 1800, notes: '' },
  ])

  // MAO / Offer state - safe defaults only
  const [maoArv, setMaoArv] = useState(0)
  const [maoRehab, setMaoRehab] = useState(0)
  const [maoClosing, setMaoClosing] = useState(0)
  const [maoHolding, setMaoHolding] = useState(0)
  const [maoFee, setMaoFee] = useState(0)
  const [maoProfit, setMaoProfit] = useState(0)
  const [maoRule, setMaoRule] = useState('70')
  const [maoCustomRule, setMaoCustomRule] = useState(70)
  const [maoSellerBottom, setMaoSellerBottom] = useState(0)
  const [maoAsking, setMaoAsking] = useState(0)

  // Deal selection for prefill and Save to Deal (safe, isolated to this page)
  const [selectedDealId, setSelectedDealId] = useState<string | null>(null)
  const [dealSearchTerm, setDealSearchTerm] = useState('')

  // Preselect from drawer via ?dealId or store currentDealId (no route changes needed elsewhere)
  const [searchParams] = useSearchParams()
  useEffect(() => {
    const paramId = searchParams.get('dealId')
    const storeId = useAppStore.getState().currentDealId
    const target = paramId || storeId
    if (target) {
      setSelectedDealId(target)
      // Immediately prefill Subject fields (not comps) so drawer "Open Full" works without extra click
      doPrefillFromDeal(target)
    }
  }, []) // mount only; drawer link + store currentDealId enable full roundtrip

  // Rental Deal Calculator - safe defaults (all numbers)
  const [rentPurchase, setRentPurchase] = useState(0)
  const [rentRehab, setRentRehab] = useState(0)
  const [rentClosing, setRentClosing] = useState(0)
  const [rentDown, setRentDown] = useState(0)
  const [rentLoan, setRentLoan] = useState(0)
  const [rentRate, setRentRate] = useState(0)
  const [rentTerm, setRentTerm] = useState(0)
  const [rentMonthly, setRentMonthly] = useState(0)
  const [rentOtherIncome, setRentOtherIncome] = useState(0)
  const [rentTaxes, setRentTaxes] = useState(0)
  const [rentIns, setRentIns] = useState(0)
  const [rentHOA, setRentHOA] = useState(0)
  const [rentUtil, setRentUtil] = useState(0)
  const [rentMgmt, setRentMgmt] = useState(0)
  const [rentVac, setRentVac] = useState(0)
  const [rentMaint, setRentMaint] = useState(0)
  const [rentCapex, setRentCapex] = useState(0)
  const [rentRepairPct, setRentRepairPct] = useState(0)
  const [rentDebtService, setRentDebtService] = useState(0)

  // Creative Finance - safe defaults (all numbers)
  const [crePurchase, setCrePurchase] = useState(0)
  const [creDown, setCreDown] = useState(0)
  const [creSellerPmt, setCreSellerPmt] = useState(0)
  const [creExistingPmt, setCreExistingPmt] = useState(0)
  const [creRate, setCreRate] = useState(0)
  const [creAmort, setCreAmort] = useState(0)
  const [creBalloon, setCreBalloon] = useState(0)
  const [creEntry, setCreEntry] = useState(0)
  const [creClosing, setCreClosing] = useState(0)
  const [creFee, setCreFee] = useState(0)
  const [creRent, setCreRent] = useState(0)
  const [creOtherIncome, setCreOtherIncome] = useState(0)
  const [creTaxes, setCreTaxes] = useState(0)
  const [creIns, setCreIns] = useState(0)
  const [creHOA, setCreHOA] = useState(0)
  const [creUtil, setCreUtil] = useState(0)
  const [creVac, setCreVac] = useState(0)
  const [creMaint, setCreMaint] = useState(0)
  const [creMgmt, setCreMgmt] = useState(0)

  // Safe ARV helpers (all guarded)
  const formatCurrency = (n: any) => {
    const num = Number(n)
    return '$' + (isFinite(num) ? Math.round(Math.max(0, num)).toLocaleString() : '0')
  }
  const formatPpsqft = (n: any) => {
    const num = Number(n)
    return '$' + (isFinite(num) ? num.toFixed(2) : '0.00')
  }

  // Shared saver (notes hack, no schema change) — used by all tabs + drawer Quick Calc
  const saveCalcResultToDeal = (type: CalcTab, data: Record<string, any>) => {
    const id = selectedDealId
    if (!id) { toast.error('Select a deal first to save'); return }
    const deal = useAppStore.getState().getDeal(id)
    if (!deal) return
    const now = new Date().toISOString()
    const block = `\n===CALC:${type.toUpperCase()}:${now}===\n${JSON.stringify({ type, savedAt: now, ...data })}\n`
    const current = deal.notes || ''
    useAppStore.getState().updateDeal(id, { notes: current + block })
    toast.success(`${type.toUpperCase()} result saved to deal`)
  }

  // Safe prefill ONLY to Subject fields (never comps). Used by dropdown + drawer ?dealId link.
  const doPrefillFromDeal = (id: string | null) => {
    if (!id) return
    const deal = useAppStore.getState().getDeal(id)
    if (!deal) return
    const p: any = deal.property || {}
    const pr: any = deal.pricing || {}
    const c: any = deal.condition || {}
    // Subject fields (ARV card + common) - all optional / null-safe
    if (p.address) setSubjectAddress(p.address)
    if (p.beds != null) setSubjectBeds(Number(p.beds) || 0)
    if (p.baths != null) setSubjectBaths(Number(p.baths) || 0)
    if (p.sqft != null) setSubjectSqft(Number(p.sqft) || 0)
    if (p.type || p.propertyType) setSubjectPropertyType(p.type || p.propertyType || '')
    if (c.rehabNotes || c.conditionNotes) setSubjectConditionNotes(c.rehabNotes || c.conditionNotes || '')
    // MAO related
    if (pr.askingPrice) setMaoAsking(Number(pr.askingPrice) || 0)
    if (pr.arv) setMaoArv(Number(pr.arv) || 0)
    if (pr.rehab) setMaoRehab(Number(pr.rehab) || 0)
  }

  const updateComp = (index: number, field: 'salePrice' | 'sqft' | 'beds' | 'baths' | 'distance' | 'conditionNotes' | 'optionalAdj', value: any) => {
    setArvComps(prev => {
      const next = [...(prev || [])]
      if (!next[index]) next[index] = { salePrice: 0, sqft: 0 }
      next[index] = { ...next[index], [field]: field === 'salePrice' || field === 'sqft' || field === 'beds' || field === 'baths' || field === 'distance' || field === 'optionalAdj' ? Math.max(0, Number(value) || 0) : value }
      return next
    })
  }

  const clearArv = () => {
    setArvComps([{ salePrice: 0, sqft: 0 }, { salePrice: 0, sqft: 0 }, { salePrice: 0, sqft: 0 }, { salePrice: 0, sqft: 0 }, { salePrice: 0, sqft: 0 }])
    setSubjectSqft(0)
    setSubjectBeds(0)
    setSubjectBaths(0)
    setAdjustment(0)
    setAdjType('$')
    setArvNotes('')
    setSubjectAddress('')
    setSubjectPropertyType('')
    setSubjectConditionNotes('')
  }

  // ARV calculations (fully guarded)
  const safeArvComps = arvComps || []
  const validComps = safeArvComps.filter(c => (c?.salePrice || 0) > 0 && (c?.sqft || 0) > 0)
  const totalPrice = validComps.reduce((s, c) => s + (c?.salePrice || 0), 0)
  const totalSqft = validComps.reduce((s, c) => s + (c?.sqft || 0), 0)
  const avgPpsqft = totalSqft > 0 ? totalPrice / totalSqft : 0
  const baseArv = avgPpsqft * (subjectSqft || 0)
  const adjustedArv = adjType === '$'
    ? baseArv + (adjustment || 0)
    : baseArv * (1 + ((adjustment || 0) / 100))

  const copyArv = () => {
    const text = `ARV Calculator\nComps used: ${validComps.length}\nAvg $/sqft: ${formatPpsqft(avgPpsqft)}\nSubject sqft: ${subjectSqft || 0}\nBase ARV: ${formatCurrency(baseArv)}\nAdjustment: ${adjType === '%' ? (adjustment || 0) + '%' : formatCurrency(adjustment)}\nEst. ARV: ${formatCurrency(adjustedArv)}\n\nNotes:\n${arvNotes || '(none)'}\n(Deal Blast Pro)`
    navigator.clipboard.writeText(text).then(() => toast.success('ARV results copied'))
  }

  const saveArv = () => {
    saveCalcResultToDeal('arv', {
      estARV: adjustedArv,
      avgPpsqft: Math.round(avgPpsqft * 100) / 100,
      subjectSqft,
      adjustment,
      adjType,
      compsUsed: validComps.length,
      notes: arvNotes || ''
    })
  }

  const exportArvPDF = () => {
    const w = window.open('', '_blank', 'width=800,height=600')
    if (!w) {
      toast.error('Popup blocked')
      return
    }
    const summary = `ARV Calculator\nComps used: ${validComps.length}\nAvg $/sqft: ${formatPpsqft(avgPpsqft)}\nSubject sqft: ${subjectSqft || 0}\nBase ARV: ${formatCurrency(baseArv)}\nAdjustment: ${adjType === '%' ? (adjustment || 0) + '%' : formatCurrency(adjustment)}\nEst. ARV: ${formatCurrency(adjustedArv)}\n\nNotes:\n${arvNotes || '(none)'}\n(Deal Blast Pro)`
    w.document.write(`<html><head><title>ARV Summary</title><style>body{font-family:system-ui;padding:30px;background:#fff;color:#111}</style></head><body><h2>ARV Calculator Results</h2><pre style="white-space:pre-wrap">${summary}</pre><p>Print → Save as PDF</p></body></html>`)
    w.document.close()
    setTimeout(() => w.print(), 200)
  }

  const resetArv = () => {
    clearArv()
  }

  // Rehab helpers - all safe, guarded (Step 2)
  const updateRehabItem = (id: any, field: any, value: any) => {
    setRehabItems(prev => (prev || []).map(item =>
      item.id === id
        ? { ...item, [field]: field === 'cost' ? Math.max(0, Number(value) || 0) : value }
        : item
    ))
  }

  const removeRehabItem = (id: any) => {
    setRehabItems(prev => (prev || []).filter(item => item.id !== id))
  }

  const addCustomRehabItem = () => {
    const newId = Date.now()
    setRehabItems(prev => [
      ...(prev || []),
      { id: newId, category: 'Custom Item', scope: 'Custom', cost: 500, notes: '' }
    ])
  }

  const applyRehabPreset = (preset: any) => {
    let base: any[] = []
    const mult = preset === 'Light Rehab' ? 0.6 : preset === 'Heavy Rehab' ? 1.6 : preset === 'Full Gut' ? 2.0 : 1.0

    if (preset === 'Light Rehab' || preset === 'Medium Rehab' || preset === 'Heavy Rehab' || preset === 'Full Gut') {
      base = [
        { id: 10, category: 'Kitchen', scope: 'Medium', cost: Math.round(3800 * mult), notes: '' },
        { id: 11, category: 'Bathrooms', scope: 'Medium', cost: Math.round(2400 * mult), notes: '' },
        { id: 12, category: 'Paint', scope: 'Light', cost: Math.round(1200 * mult), notes: '' },
        { id: 13, category: 'Flooring', scope: 'Light', cost: Math.round(1800 * mult), notes: '' },
        { id: 14, category: 'HVAC', scope: 'Light', cost: Math.round(2200 * mult), notes: '' },
      ]
    } else if (preset === 'Full Gut') {
      base = [
        { id: 10, category: 'Kitchen', scope: 'Heavy', cost: Math.round(3800 * 2), notes: '' },
        { id: 11, category: 'Bathrooms', scope: 'Heavy', cost: Math.round(2400 * 2), notes: '' },
        { id: 12, category: 'Paint', scope: 'Heavy', cost: Math.round(1200 * 2), notes: '' },
        { id: 13, category: 'Flooring', scope: 'Heavy', cost: Math.round(1800 * 2), notes: '' },
        { id: 14, category: 'HVAC', scope: 'Heavy', cost: Math.round(2200 * 2), notes: '' },
        { id: 15, category: 'Roof', scope: 'Heavy', cost: Math.round(6500), notes: '' },
        { id: 16, category: 'Electrical', scope: 'Heavy', cost: Math.round(3200), notes: '' },
        { id: 17, category: 'Plumbing', scope: 'Heavy', cost: Math.round(2800), notes: '' },
      ]
    }

    setRehabItems(base)
  }

  const clearRehab = () => {
    setRehabItems([])
  }

  // MAO helpers - fully guarded calculations
  const getMaoRulePercent = () => {
    if (maoRule === 'custom') return maoCustomRule || 0
    return parseFloat(maoRule) || 0
  }

  const maoPercent = getMaoRulePercent() / 100

  const grossMAO = (maoArv || 0) * maoPercent
  const totalDeductions = (maoRehab || 0) + (maoClosing || 0) + (maoHolding || 0) + (maoFee || 0) + (maoProfit || 0)
  const maoValue = Math.max(0, Math.round(grossMAO - totalDeductions))

  const buyerAllIn = (maoArv || 0) - maoValue   // rough all-in view
  const spread = maoValue - (maoSellerBottom || 0)
  const discountFromArv = maoArv > 0 ? ((maoArv - maoValue) / maoArv * 100) : 0

  const recommendedLow = Math.max(0, maoValue - 15000)
  const recommendedHigh = Math.max(0, maoValue - 5000)

  const dealStrength = () => {
    if (maoValue <= 0) return 'Weak'
    if (maoSellerBottom && maoSellerBottom > maoValue) return 'Weak'

    const asking = maoAsking || 0
    if (asking > maoValue) return 'Weak'
    if (asking > 0 && asking < maoValue * 0.85) return 'Strong' // meaningfully below MAO
    if (asking > 0 && asking <= maoValue) return 'Moderate'

    if (spread >= 20000 && maoProfit >= 10000) return 'Strong'
    if (spread >= 5000) return 'Moderate'
    return 'Weak'
  }

  const maoStrength = dealStrength()

  // New: Asking Price impact (null-safe)
  const askingVsMaoDiff = (maoAsking && maoAsking > 0) ? maoValue - maoAsking : null

  let negotiationTarget = 'N/A'
  if (maoAsking && maoAsking > 0) {
    if (maoAsking <= maoValue) {
      negotiationTarget = 'Asking price is within target range.'
      if (maoSellerBottom && maoSellerBottom > maoAsking) {
        negotiationTarget += ` Seller bottom line (${formatCurrency(maoSellerBottom)}) is higher.`
      }
    } else {
      const targetLow = Math.max(0, maoValue - 10000)
      const targetHigh = maoValue
      negotiationTarget = `Target offer: ${formatCurrency(targetLow)} – ${formatCurrency(targetHigh)}`
      if (maoSellerBottom && maoSellerBottom < maoAsking) {
        negotiationTarget += ` (Seller bottom ${formatCurrency(maoSellerBottom)} may be flexible)`
      }
    }
  }

  const profitRoomAfterAsking = askingVsMaoDiff // positive = good for buyer

  const copyMao = () => {
    const askingInfo = askingVsMaoDiff !== null 
      ? `\nAsking vs MAO: ${askingVsMaoDiff >= 0 ? 'Under by ' : 'Over by '}${formatCurrency(Math.abs(askingVsMaoDiff))}`
      : '\nAsking vs MAO: N/A'
    const text = `MAO Calculator\nMAO: ${formatCurrency(maoValue)}\nRecommended Seller Offer: ${formatCurrency(recommendedLow)} - ${formatCurrency(recommendedHigh)}\nBuyer All-In: ${formatCurrency(buyerAllIn)}\nSpread: ${formatCurrency(spread)}\nDiscount from ARV: ${discountFromArv.toFixed(1)}%\nDeal Strength: ${maoStrength}${askingInfo}\n(Deal Blast Pro)`
    navigator.clipboard.writeText(text).then(() => toast.success('MAO results copied'))
  }

  const saveMao = () => {
    saveCalcResultToDeal('mao', {
      mao: maoValue,
      recommendedLow,
      recommendedHigh,
      buyerAllIn,
      spread,
      discountFromArv: Math.round(discountFromArv * 10) / 10,
      strength: maoStrength,
      askingVsMaoDiff: askingVsMaoDiff,
      askingPrice: maoAsking || 0
    })
  }

  const exportMaoPDF = () => {
    const w = window.open('', '_blank', 'width=800,height=600')
    if (!w) { toast.error('Popup blocked'); return }
    const askingInfo = askingVsMaoDiff !== null 
      ? `\nAsking vs MAO Diff: ${askingVsMaoDiff >= 0 ? '+' : ''}${formatCurrency(askingVsMaoDiff)}`
      : '\nAsking vs MAO: N/A'
    const summary = `MAO / Offer Calculator\nARV: ${formatCurrency(maoArv)}\nMAO: ${formatCurrency(maoValue)}\nRecommended: ${formatCurrency(recommendedLow)} - ${formatCurrency(recommendedHigh)}\nStrength: ${maoStrength}${askingInfo}`
    w.document.write(`<html><head><title>MAO Summary</title><style>body{font-family:system-ui;padding:30px;background:#fff;color:#111}</style></head><body><h2>MAO / Offer Results</h2><pre style="white-space:pre-wrap">${summary}</pre><p>Print → Save as PDF</p></body></html>`)
    w.document.close()
    setTimeout(() => w.print(), 200)
  }

  // Rental calculations - all guarded against blank/0
  const rentGrossMonthly = (rentMonthly || 0) + (rentOtherIncome || 0)
  const rentOpExMonthly = (rentTaxes || 0) + (rentIns || 0) + (rentHOA || 0) + (rentUtil || 0) +
    (rentGrossMonthly * ((rentMgmt || 0) + (rentVac || 0) + (rentMaint || 0) + (rentCapex || 0) + (rentRepairPct || 0)) / 100)
  const rentNOIMonthly = rentGrossMonthly - rentOpExMonthly
  const rentNOI = rentNOIMonthly * 12
  const rentMonthlyCF = rentGrossMonthly - rentOpExMonthly - (rentDebtService || 0)
  const rentAnnualCF = rentMonthlyCF * 12
  const rentTotalCost = (rentPurchase || 0) + (rentRehab || 0) + (rentClosing || 0)
  const rentCapRate = rentTotalCost > 0 ? (rentNOI / rentTotalCost * 100) : 0
  const rentCoC = (rentDown || 0) > 0 ? (rentAnnualCF / (rentDown || 0) * 100) : 0
  const rentDSCR = (rentDebtService || 0) > 0 ? (rentNOI / ((rentDebtService || 0) * 12)) : 0
  const rentOnePercent = (rentPurchase || 0) > 0 ? ((rentMonthly || 0) >= 0.01 * (rentPurchase || 0)) : false
  const rentBreakEven = rentOpExMonthly + (rentDebtService || 0)

  const rentStrength = () => {
    if (rentMonthlyCF <= 0) return 'Weak'
    if (rentDSCR < 1.0) return 'Weak'
    if (rentCoC >= 10 && rentDSCR >= 1.25) return 'Strong'
    if (rentCoC >= 6 || rentDSCR >= 1.1) return 'Moderate'
    return 'Weak'
  }

  // Creative calculations - all guarded
  const creGrossMonthly = (creRent || 0) + (creOtherIncome || 0)
  const creOpExMonthly = (creTaxes || 0) + (creIns || 0) + (creHOA || 0) + (creUtil || 0) +
    (creGrossMonthly * ((creVac || 0) + (creMaint || 0) + (creMgmt || 0)) / 100)
  const creMonthlyCF = creGrossMonthly - (creSellerPmt || 0) - (creExistingPmt || 0) - creOpExMonthly
  const creAnnualCF = creMonthlyCF * 12
  const creTotalEntry = (creDown || 0) + (creEntry || 0) + (creClosing || 0) + (creFee || 0)
  const crePaybackMo = creMonthlyCF > 0 ? Math.ceil(creTotalEntry / creMonthlyCF) : 999
  const creCoC = creTotalEntry > 0 ? (creAnnualCF / creTotalEntry * 100) : 0

  const creStrength = () => {
    if (creMonthlyCF <= 0) return 'Weak'
    if (creCoC >= 12) return 'Strong'
    if (creCoC >= 6) return 'Moderate'
    return 'Weak'
  }

  // Simple tab content renderer (only ARV active)
  const renderTabContent = () => {
    if (activeTab === 'arv') {
      return (
        <div>
          <div className="mb-4 flex items-start justify-between">
            <div>
              <div className="text-lg font-semibold text-white">ARV Calculator</div>
              <div className="text-sm text-[#8B92A3]">Comps → Avg $/sqft → Subject ARV with adjustment</div>
            </div>
            <button onClick={resetArv} className="text-xs px-3 py-1 rounded border border-[#252A38] hover:bg-[#252A38] text-[#8B92A3]">Clear</button>
          </div>

          {/* Subject Property card (matches comp card visual style exactly) */}
          <div className="mb-4">
            <div className="text-xs uppercase tracking-widest text-[#8B92A3] mb-2">Subject Property</div>
            <div className="bg-[#0A0C12] border border-[#252A38] rounded-lg p-3">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 text-xs">
                <div className="md:col-span-3">
                  <div className="text-[#8B92A3]">Address</div>
                  <input type="text" value={subjectAddress} onChange={e => setSubjectAddress(e.target.value)} className="input py-1 text-sm w-full" placeholder="123 Main St" />
                </div>
                <div>
                  <div className="text-[#8B92A3]">Beds</div>
                  <input type="number" value={subjectBeds || ''} onChange={e => setSubjectBeds(Math.max(0, parseFloat(e.target.value) || 0))} className="input py-1 text-sm w-full" placeholder="" />
                </div>
                <div>
                  <div className="text-[#8B92A3]">Baths</div>
                  <input type="number" value={subjectBaths || ''} onChange={e => setSubjectBaths(Math.max(0, parseFloat(e.target.value) || 0))} className="input py-1 text-sm w-full" placeholder="" />
                </div>
                <div>
                  <div className="text-[#8B92A3]">Sq Ft</div>
                  <input type="number" value={subjectSqft || ''} onChange={e => setSubjectSqft(Math.max(0, parseFloat(e.target.value) || 0))} className="input py-1 text-sm w-full" placeholder="e.g. 1850" />
                </div>
                <div>
                  <div className="text-[#8B92A3]">Property Type</div>
                  <input type="text" value={subjectPropertyType} onChange={e => setSubjectPropertyType(e.target.value)} className="input py-1 text-sm w-full" placeholder="SFH / Multifamily..." />
                </div>
                <div>
                  <div className="text-[#8B92A3]">Condition / Notes</div>
                  <input type="text" value={subjectConditionNotes} onChange={e => setSubjectConditionNotes(e.target.value)} className="input py-1 text-sm w-full" placeholder="Updated, needs paint..." />
                </div>
                <div className="md:col-span-3">
                  <div className="flex items-center justify-between mb-1">
                    <div className="text-[#8B92A3] text-[10px]">Optional Adjustment</div>
                    <div className="flex rounded overflow-hidden text-xs border border-[#252A38]">
                      <button onClick={() => setAdjType('$')} className={`px-3 py-0.5 ${adjType === '$' ? 'bg-[#22C55E] text-black' : 'hover:bg-[#171B26]'}`}>$</button>
                      <button onClick={() => setAdjType('%')} className={`px-3 py-0.5 ${adjType === '%' ? 'bg-[#22C55E] text-black' : 'hover:bg-[#171B26]'}`}>%</button>
                    </div>
                  </div>
                  <input type="number" value={adjustment || ''} onChange={e => setAdjustment(parseFloat(e.target.value) || 0)} className="input py-1 text-sm w-full" placeholder={adjType === '$' ? 'e.g. 8000 or -3000' : 'e.g. 3 or -2'} />
                </div>
              </div>
            </div>
          </div>

          {/* Comp Inputs - enhanced with quality fields (safe, guarded) */}
          <div className="mb-5">
            <div className="text-xs uppercase tracking-widest text-[#8B92A3] mb-2">Comparable Sales</div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {[0,1,2,3,4].map(i => {
                const comp = safeArvComps[i] || { salePrice: 0, sqft: 0 }
                const subjBeds = subjectBeds || 0
                const subjBaths = subjectBaths || 0
                const subjSqft = subjectSqft || 0

                // Simple quality score (0-100) based on similarity
                const bedsDiff = Math.abs((comp.beds || 0) - subjBeds)
                const bathsDiff = Math.abs((comp.baths || 0) - subjBaths)
                const sqftDiffPct = subjSqft > 0 ? Math.abs((comp.sqft - subjSqft) / subjSqft) : 1
                const qualityScore = Math.max(0, Math.min(100, Math.round(100 - (bedsDiff * 8 + bathsDiff * 10 + sqftDiffPct * 50))))

                return (
                  <div key={i} className="bg-[#0A0C12] border border-[#252A38] rounded-lg p-3">
                    <div className="flex justify-between items-center mb-1.5">
                      <div className="text-[11px] font-medium text-[#CBD5E1]">Comp {i+1}{i > 2 ? ' (optional)' : ''}</div>
                      <div className="text-[10px] px-1.5 py-0.5 rounded bg-[#252A38] text-[#8B92A3]">
                        Quality: {qualityScore}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <div className="text-[#8B92A3]">Sale Price</div>
                        <input type="number" value={comp.salePrice || ''} onChange={e => updateComp(i, 'salePrice', parseFloat(e.target.value))} className="input py-1 text-sm" placeholder="0" />
                      </div>
                      <div>
                        <div className="text-[#8B92A3]">Sq Ft</div>
                        <input type="number" value={comp.sqft || ''} onChange={e => updateComp(i, 'sqft', parseFloat(e.target.value))} className="input py-1 text-sm" placeholder="0" />
                      </div>
                      <div>
                        <div className="text-[#8B92A3]">Beds</div>
                        <input type="number" value={comp.beds || ''} onChange={e => updateComp(i, 'beds', parseFloat(e.target.value))} className="input py-1 text-sm" placeholder="" />
                      </div>
                      <div>
                        <div className="text-[#8B92A3]">Baths</div>
                        <input type="number" value={comp.baths || ''} onChange={e => updateComp(i, 'baths', parseFloat(e.target.value))} className="input py-1 text-sm" placeholder="" />
                      </div>
                      <div>
                        <div className="text-[#8B92A3]">Distance (mi)</div>
                        <input type="number" value={comp.distance || ''} onChange={e => updateComp(i, 'distance', parseFloat(e.target.value))} className="input py-1 text-sm" placeholder="0" />
                      </div>
                      <div>
                        <div className="text-[#8B92A3]">Adj (+/- $)</div>
                        <input type="number" value={comp.optionalAdj || ''} onChange={e => updateComp(i, 'optionalAdj', parseFloat(e.target.value))} className="input py-1 text-sm" placeholder="0" />
                      </div>
                    </div>

                    <div className="mt-1">
                      <div className="text-[#8B92A3] text-[10px]">Condition / Notes</div>
                      <input type="text" value={comp.conditionNotes || ''} onChange={e => updateComp(i, 'conditionNotes', e.target.value)} className="input py-1 text-xs w-full" placeholder="Good condition, updated kitchen..." />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* (Subject fields now live in the dedicated Subject Property card above; math still driven exclusively by comp Sale Price + SqFt) */}

          {/* Live KPI Results - safe */}
          <div className="text-xs uppercase tracking-widest text-[#8B92A3] mb-2">Live Results</div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-[10px] text-[#8B92A3] tracking-widest">AVG PRICE / SQFT</div>
              <div className="text-2xl font-semibold tabular-nums text-[#22C55E] mt-1">{formatPpsqft(avgPpsqft)}</div>
              <div className="text-[10px] text-[#6B7280] mt-0.5">{validComps.length} comps used</div>
            </div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-[10px] text-[#8B92A3] tracking-widest">BASE ARV (NO ADJ)</div>
              <div className="text-2xl font-semibold tabular-nums text-[#E6E8EE] mt-1">{formatCurrency(baseArv)}</div>
            </div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-[10px] text-[#8B92A3] tracking-widest">ADJUSTMENT</div>
              <div className="text-2xl font-semibold tabular-nums text-[#E6E8EE] mt-1">
                {adjType === '%' ? `${adjustment || 0}%` : formatCurrency(adjustment)}
              </div>
            </div>
            <div className="bg-[#052E16] border border-[#22C55E]/40 rounded-lg p-3 text-center">
              <div className="text-[10px] text-[#4ADE80] tracking-widest">ESTIMATED ARV</div>
              <div className="text-2xl font-bold tabular-nums text-[#22C55E] mt-1">{formatCurrency(adjustedArv)}</div>
            </div>
          </div>

          {/* Notes */}
          <div className="mb-4">
            <div className="text-xs text-[#8B92A3] mb-1">Notes for this ARV analysis</div>
            <textarea
              value={arvNotes}
              onChange={e => setArvNotes(e.target.value)}
              className="input w-full h-16 text-sm resize-y"
              placeholder="Comp adjustments, condition notes..."
            />
          </div>

          {/* Actions for ARV only - Save disabled (no selector in Step 1) */}
          <div className="pt-4 border-t border-[#252A38] flex flex-wrap items-center gap-2">
            <button onClick={copyArv} className="btn btn-ghost text-sm px-3 py-1.5"><Copy size={15} /> Copy Results</button>
            <button
              onClick={saveArv}
              disabled={!selectedDealId}
              className="btn btn-ghost text-sm px-3 py-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
              title={!selectedDealId ? 'Select a deal above first' : 'Save result to this deal'}
            >
              <Save size={15} /> Save to Deal
            </button>
            <button onClick={exportArvPDF} className="btn btn-ghost text-sm px-3 py-1.5"><Download size={15} /> Export PDF</button>
            <button onClick={resetArv} className="btn btn-ghost text-sm px-3 py-1.5 text-[#8B92A3]">Reset ARV</button>
            <div className="ml-auto text-[11px] text-[#6B7280] hidden sm:block">All math is local • instant</div>
          </div>
        </div>
      )
    }

    if (activeTab === 'rehab') {
      const safeRehab = rehabItems || []
      const total = safeRehab.reduce((sum, item) => sum + (item?.cost || 0), 0)
      const count = safeRehab.length
      const highest = safeRehab.length > 0
        ? safeRehab.reduce((max, item) => (item?.cost || 0) > (max?.cost || 0) ? item : max, safeRehab[0])
        : null
      const costPerSqft = (subjectSqft || 0) > 0 ? total / (subjectSqft || 0) : 0

      const copyRehab = () => {
        const text = `Rehab Estimate\nTotal: ${formatCurrency(total)}\nItems: ${count}\nHighest: ${highest?.category || '—'} (${formatCurrency(highest?.cost || 0)})\n\n(Deal Blast Pro)`
        navigator.clipboard.writeText(text).then(() => toast.success('Rehab results copied'))
      }

      const saveRehab = () => {
        const safeRehab = rehabItems || []
        const total = safeRehab.reduce((sum, item) => sum + (item?.cost || 0), 0)
        saveCalcResultToDeal('rehab', {
          totalRehab: total,
          itemCount: safeRehab.length,
          highestCategory: safeRehab.length > 0 ? safeRehab.reduce((max, item) => (item?.cost || 0) > (max?.cost || 0) ? item : max, safeRehab[0])?.category : null,
          costPerSqft: (subjectSqft || 0) > 0 ? Math.round((total / (subjectSqft || 0)) * 100) / 100 : 0
        })
      }

      const exportRehabPDF = () => {
        const w = window.open('', '_blank', 'width=800,height=600')
        if (!w) { toast.error('Popup blocked'); return }
        const summary = `Rehab Estimate\nTotal: ${formatCurrency(total)}\nCost/SqFt: ${costPerSqft.toFixed(2)}\nLine Items: ${count}\nHighest: ${highest?.category || '—'} (${formatCurrency(highest?.cost || 0)})`
        w.document.write(`<html><head><title>Rehab Summary</title><style>body{font-family:system-ui;padding:30px;background:#fff;color:#111}</style></head><body><h2>Rehab Calculator Results</h2><pre style="white-space:pre-wrap">${summary}</pre><p>Print → Save as PDF</p></body></html>`)
        w.document.close()
        setTimeout(() => w.print(), 200)
      }

      return (
        <div>
          <div className="mb-4 flex items-start justify-between">
            <div>
              <div className="text-lg font-semibold text-white">Rehab Calculator</div>
              <div className="text-sm text-[#8B92A3]">Presets + editable line items → Total rehab cost</div>
            </div>
            <button onClick={clearRehab} className="text-xs px-3 py-1 rounded border border-[#252A38] hover:bg-[#252A38] text-[#8B92A3]">Clear</button>
          </div>

          {/* Presets */}
          <div className="flex flex-wrap gap-1.5 mb-4">
            {['Light Rehab', 'Medium Rehab', 'Heavy Rehab', 'Full Gut'].map(p => (
              <button key={p} onClick={() => applyRehabPreset(p)} className="btn btn-ghost px-2.5 py-1 text-xs">{p} Preset</button>
            ))}
            <button onClick={addCustomRehabItem} className="btn btn-green px-3 py-1 text-xs">+ Add Custom Item</button>
          </div>

          {/* Line Items - safe */}
          <div className="space-y-2 mb-4">
            {safeRehab.map(item => (
              <div key={item.id} className="grid grid-cols-12 gap-2 items-center bg-[#0A0C12] border border-[#252A38] rounded-lg px-3 py-2 text-sm">
                <input
                  type="text"
                  value={item.category || ''}
                  onChange={e => updateRehabItem(item.id, 'category', e.target.value)}
                  className="col-span-3 input py-1 text-sm font-medium"
                  placeholder="Item name"
                />

                <select
                  value={item.scope}
                  onChange={e => updateRehabItem(item.id, 'scope', e.target.value)}
                  className="col-span-2 select py-1 text-xs"
                >
                  {['None', 'Light', 'Medium', 'Heavy', 'Custom'].map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>

                <input
                  type="number"
                  value={item.cost || ''}
                  onChange={e => updateRehabItem(item.id, 'cost', e.target.value)}
                  className="col-span-2 input py-1 text-sm"
                  placeholder="Cost"
                />

                <input
                  value={item.notes || ''}
                  onChange={e => updateRehabItem(item.id, 'notes', e.target.value)}
                  placeholder="Notes..."
                  className="col-span-4 input py-1 text-xs"
                />

                <button onClick={() => removeRehabItem(item.id)} className="col-span-1 text-red-400 hover:text-red-300 text-lg leading-none">×</button>
              </div>
            ))}
            {safeRehab.length === 0 && (
              <div className="text-sm text-[#8B92A3] text-center py-4">No line items. Use presets or add custom.</div>
            )}
          </div>

          {/* Outputs - safe */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <div className="bg-[#052E16] border border-[#22C55E]/40 rounded-lg p-3 text-center">
              <div className="text-xs text-[#4ADE80]">TOTAL REHAB</div>
              <div className="text-2xl font-bold text-[#22C55E]">{formatCurrency(total)}</div>
            </div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3]">COST / SQFT</div>
              <div className="text-2xl font-semibold">{(subjectSqft || 0) > 0 ? costPerSqft.toFixed(2) : '—'}</div>
            </div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3]">LINE ITEMS</div>
              <div className="text-2xl font-semibold">{count}</div>
            </div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3]">HIGHEST COST</div>
              <div className="text-lg font-semibold truncate">{highest?.category || '—'}</div>
              <div className="text-sm">{formatCurrency(highest?.cost || 0)}</div>
            </div>
          </div>

          {/* Bottom actions for Rehab */}
          <div className="pt-4 border-t border-[#252A38] flex flex-wrap items-center gap-2">
            <button onClick={copyRehab} className="btn btn-ghost text-sm px-3 py-1.5"><Copy size={15} /> Copy Results</button>
            <button
              onClick={saveRehab}
              disabled={!selectedDealId}
              className="btn btn-ghost text-sm px-3 py-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
              title={!selectedDealId ? 'Select a deal above first' : 'Save result to this deal'}
            >
              <Save size={15} /> Save to Deal
            </button>
            <button onClick={exportRehabPDF} className="btn btn-ghost text-sm px-3 py-1.5"><Download size={15} /> Export PDF</button>
            <button onClick={clearRehab} className="btn btn-ghost text-sm px-3 py-1.5 text-[#8B92A3]">Clear</button>
            <div className="ml-auto text-[11px] text-[#6B7280] hidden sm:block">All math is local • instant</div>
          </div>
        </div>
      )
    }

    if (activeTab === 'mao') {
      const ruleOptions = ['65', '70', '75', 'custom']

      return (
        <div>
          <div className="mb-4">
            <div className="text-lg font-semibold text-white">MAO / Offer Calculator</div>
            <div className="text-sm text-[#8B92A3]">Calculate maximum allowable offer and recommended seller price</div>
          </div>

          {/* Inputs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5">
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">ARV</div>
              <input type="number" value={maoArv || ''} onChange={e => setMaoArv(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" />
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">Rehab Estimate</div>
              <input type="number" value={maoRehab || ''} onChange={e => setMaoRehab(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" />
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">Closing Costs</div>
              <input type="number" value={maoClosing || ''} onChange={e => setMaoClosing(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" />
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">Holding Costs</div>
              <input type="number" value={maoHolding || ''} onChange={e => setMaoHolding(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" />
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">Assignment / Wholesale Fee</div>
              <input type="number" value={maoFee || ''} onChange={e => setMaoFee(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" />
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">Buyer Profit / Safety Buffer</div>
              <input type="number" value={maoProfit || ''} onChange={e => setMaoProfit(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" />
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">Rule %</div>
              <div className="flex gap-1 flex-wrap">
                {ruleOptions.map(r => (
                  <button
                    key={r}
                    onClick={() => setMaoRule(r)}
                    className={`px-2.5 py-0.5 text-xs rounded ${maoRule === r ? 'bg-[#22C55E] text-black' : 'bg-[#171B26] border border-[#252A38]'}`}
                  >
                    {r === 'custom' ? 'Custom' : r + '%'}
                  </button>
                ))}
              </div>
            </div>
            {maoRule === 'custom' && (
              <div>
                <div className="text-xs text-[#8B92A3] mb-1">Custom Rule %</div>
                <input type="number" value={maoCustomRule || ''} onChange={e => setMaoCustomRule(Math.max(0, Math.min(100, parseFloat(e.target.value) || 0)))} className="input" placeholder="70" />
              </div>
            )}
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">Seller Bottom Line (optional)</div>
              <input type="number" value={maoSellerBottom || ''} onChange={e => setMaoSellerBottom(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" />
            </div>
            <div>
              <div className="text-xs text-[#8B92A3] mb-1">Current Asking Price (optional)</div>
              <input type="number" value={maoAsking || ''} onChange={e => setMaoAsking(Math.max(0, parseFloat(e.target.value) || 0))} className="input" placeholder="0" />
            </div>
          </div>

          {/* Outputs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
            <div className="bg-[#052E16] border border-[#22C55E]/40 rounded-lg p-3 text-center">
              <div className="text-xs text-[#4ADE80]">MAO / MAX ALLOWABLE OFFER</div>
              <div className="text-2xl font-bold text-[#22C55E] mt-1">{formatCurrency(maoValue)}</div>
            </div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3]">RECOMMENDED SELLER OFFER</div>
              <div className="text-xl font-semibold mt-1">{formatCurrency(recommendedLow)} — {formatCurrency(recommendedHigh)}</div>
            </div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3]">BUYER ALL-IN COST</div>
              <div className="text-2xl font-semibold mt-1">{formatCurrency(buyerAllIn)}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3]">PROFIT / SPREAD ROOM</div>
              <div className="text-2xl font-semibold">{formatCurrency(spread)}</div>
            </div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3]">DISCOUNT FROM ARV</div>
              <div className="text-2xl font-semibold">{discountFromArv.toFixed(1)}%</div>
            </div>
            <div className={`bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center ${maoStrength === 'Strong' ? 'border-[#22C55E]' : maoStrength === 'Moderate' ? 'border-[#FBBF24]' : ''}`}>
              <div className="text-xs text-[#8B92A3]">DEAL STRENGTH</div>
              <div className={`text-2xl font-bold mt-1 ${maoStrength === 'Strong' ? 'text-[#22C55E]' : maoStrength === 'Moderate' ? 'text-[#FBBF24]' : 'text-red-400'}`}>{maoStrength}</div>
            </div>
          </div>

          {/* New Asking Price Impact KPIs (null-safe) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3] tracking-widest">ASKING VS MAO DIFFERENCE</div>
              <div className={`text-2xl font-semibold mt-1 ${askingVsMaoDiff === null ? 'text-[#8B92A3]' : askingVsMaoDiff >= 0 ? 'text-[#22C55E]' : 'text-red-400'}`}>
                {askingVsMaoDiff === null ? 'N/A' : askingVsMaoDiff >= 0 ? `Under MAO by ${formatCurrency(askingVsMaoDiff)}` : `Over MAO by ${formatCurrency(Math.abs(askingVsMaoDiff))}`}
              </div>
            </div>

            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3] tracking-widest">SUGGESTED NEGOTIATION TARGET</div>
              <div className="text-lg font-semibold mt-1 leading-tight">
                {negotiationTarget}
              </div>
            </div>

            <div className="bg-[#0F111A] border border-[#252A38] rounded-lg p-3 text-center">
              <div className="text-xs text-[#8B92A3] tracking-widest">PROFIT ROOM AFTER ASKING</div>
              <div className={`text-2xl font-semibold mt-1 ${profitRoomAfterAsking === null ? 'text-[#8B92A3]' : profitRoomAfterAsking >= 0 ? 'text-[#22C55E]' : 'text-red-400'}`}>
                {profitRoomAfterAsking === null ? 'N/A' : formatCurrency(profitRoomAfterAsking)}
              </div>
              <div className="text-[10px] text-[#6B7280] mt-0.5">
                {profitRoomAfterAsking === null ? '' : profitRoomAfterAsking >= 0 ? 'Positive for buyer' : 'Negative — negotiate'}
              </div>
            </div>
          </div>

          {/* Bottom actions for MAO */}
          <div className="pt-4 border-t border-[#252A38] flex flex-wrap items-center gap-2">
            <button onClick={copyMao} className="btn btn-ghost text-sm px-3 py-1.5"><Copy size={15} /> Copy Results</button>
            <button
              onClick={saveMao}
              disabled={!selectedDealId}
              className="btn btn-ghost text-sm px-3 py-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
              title={!selectedDealId ? 'Select a deal above first' : 'Save result to this deal'}
            >
              <Save size={15} /> Save to Deal
            </button>
            <button onClick={exportMaoPDF} className="btn btn-ghost text-sm px-3 py-1.5"><Download size={15} /> Export PDF</button>
            <div className="ml-auto text-[11px] text-[#6B7280] hidden sm:block">All math is local • instant</div>
          </div>
        </div>
      )
    }

    if (activeTab === 'rental') {
      const rentStrengthVal = rentStrength()

      const copyRental = () => {
        const text = `Rental Deal\nMonthly CF: ${formatCurrency(rentMonthlyCF)}\nAnnual CF: ${formatCurrency(rentAnnualCF)}\nNOI: ${formatCurrency(rentNOI)}\nCap Rate: ${rentCapRate.toFixed(1)}%\nCash-on-Cash: ${rentCoC.toFixed(1)}%\nDSCR: ${rentDSCR.toFixed(2)}\n1% Rule: ${rentOnePercent ? 'PASS' : 'FAIL'}\nBreak-even Rent: ${formatCurrency(rentBreakEven)}\nStrength: ${rentStrengthVal}\n(Deal Blast Pro)`
        navigator.clipboard.writeText(text).then(() => toast.success('Rental results copied'))
      }

      const saveRental = () => {
        saveCalcResultToDeal('rental', {
          monthlyCF: rentMonthlyCF,
          annualCF: rentAnnualCF,
          noi: rentNOI,
          capRate: Math.round(rentCapRate * 10) / 10,
          cashOnCash: Math.round(rentCoC * 10) / 10,
          dscr: Math.round(rentDSCR * 100) / 100,
          strength: rentStrength()
        })
      }

      const exportRentalPDF = () => {
        const w = window.open('', '_blank', 'width=800,height=600')
        if (!w) { toast.error('Popup blocked'); return }
        const summary = `Rental Deal Calculator\nMonthly CF: ${formatCurrency(rentMonthlyCF)}\nCap Rate: ${rentCapRate.toFixed(1)}%\nCoC: ${rentCoC.toFixed(1)}%\nDSCR: ${rentDSCR.toFixed(2)}\nStrength: ${rentStrengthVal}`
        w.document.write(`<html><head><title>Rental Summary</title><style>body{font-family:system-ui;padding:30px;background:#fff;color:#111}</style></head><body><h2>Rental Deal Results</h2><pre style="white-space:pre-wrap">${summary}</pre><p>Print → Save as PDF</p></body></html>`)
        w.document.close()
        setTimeout(() => w.print(), 200)
      }

      return (
        <div>
          <div className="mb-4">
            <div className="text-lg font-semibold text-white">Rental Deal Calculator</div>
            <div className="text-sm text-[#8B92A3]">Full pro-forma with financing and all expenses</div>
          </div>

          {/* Inputs - grouped for readability, all safe */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-5">
            <div><div className="text-xs mb-1">Purchase Price</div><input type="number" value={rentPurchase || ''} onChange={e => setRentPurchase(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Rehab / Repairs</div><input type="number" value={rentRehab || ''} onChange={e => setRentRehab(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Closing Costs</div><input type="number" value={rentClosing || ''} onChange={e => setRentClosing(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Down Payment</div><input type="number" value={rentDown || ''} onChange={e => setRentDown(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Loan Amount</div><input type="number" value={rentLoan || ''} onChange={e => setRentLoan(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Interest Rate %</div><input type="number" value={rentRate || ''} onChange={e => setRentRate(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Loan Term (months)</div><input type="number" value={rentTerm || ''} onChange={e => setRentTerm(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Monthly Rent</div><input type="number" value={rentMonthly || ''} onChange={e => setRentMonthly(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Other Monthly Income</div><input type="number" value={rentOtherIncome || ''} onChange={e => setRentOtherIncome(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Taxes (mo)</div><input type="number" value={rentTaxes || ''} onChange={e => setRentTaxes(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Insurance (mo)</div><input type="number" value={rentIns || ''} onChange={e => setRentIns(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">HOA (mo)</div><input type="number" value={rentHOA || ''} onChange={e => setRentHOA(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Utilities (owner mo)</div><input type="number" value={rentUtil || ''} onChange={e => setRentUtil(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Prop Mgmt %</div><input type="number" value={rentMgmt || ''} onChange={e => setRentMgmt(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Vacancy %</div><input type="number" value={rentVac || ''} onChange={e => setRentVac(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Maintenance %</div><input type="number" value={rentMaint || ''} onChange={e => setRentMaint(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">CapEx Reserve %</div><input type="number" value={rentCapex || ''} onChange={e => setRentCapex(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Repairs % of rent</div><input type="number" value={rentRepairPct || ''} onChange={e => setRentRepairPct(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Monthly Debt Service</div><input type="number" value={rentDebtService || ''} onChange={e => setRentDebtService(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
          </div>

          {/* Outputs */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
            <div className="bg-[#052E16] border border-[#22C55E]/40 rounded p-3 text-center"><div className="text-xs text-[#4ADE80]">MONTHLY CASH FLOW</div><div className="text-2xl font-bold text-[#22C55E] mt-1">{formatCurrency(rentMonthlyCF)}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">ANNUAL CASH FLOW</div><div className="text-2xl font-bold mt-1">{formatCurrency(rentAnnualCF)}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">NOI (Annual)</div><div className="text-2xl font-bold mt-1">{formatCurrency(rentNOI)}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">CAP RATE</div><div className="text-2xl font-bold mt-1">{rentCapRate.toFixed(1)}%</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">CASH-ON-CASH</div><div className="text-2xl font-bold mt-1">{rentCoC.toFixed(1)}%</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">DSCR</div><div className="text-2xl font-bold mt-1">{rentDSCR.toFixed(2)}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">1% RULE</div><div className={`text-2xl font-bold mt-1 ${rentOnePercent ? 'text-[#22C55E]' : 'text-red-400'}`}>{rentOnePercent ? 'PASS' : 'FAIL'}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">BREAK-EVEN RENT</div><div className="text-2xl font-bold mt-1">{formatCurrency(rentBreakEven)}</div></div>
            <div className={`bg-[#0F111A] border border-[#252A38] rounded p-3 text-center ${rentStrengthVal === 'Strong' ? 'border-[#22C55E]' : rentStrengthVal === 'Moderate' ? 'border-[#FBBF24]' : ''}`}>
              <div className="text-xs">DEAL STRENGTH</div>
              <div className={`text-2xl font-bold mt-1 ${rentStrengthVal === 'Strong' ? 'text-[#22C55E]' : rentStrengthVal === 'Moderate' ? 'text-[#FBBF24]' : 'text-red-400'}`}>{rentStrengthVal}</div>
            </div>
          </div>

          <div className="pt-4 border-t border-[#252A38] flex flex-wrap items-center gap-2">
            <button onClick={copyRental} className="btn btn-ghost text-sm px-3 py-1.5"><Copy size={15} /> Copy Results</button>
            <button onClick={saveRental} disabled={!selectedDealId} className="btn btn-ghost text-sm px-3 py-1.5 disabled:opacity-40 disabled:cursor-not-allowed" title={!selectedDealId ? 'Select a deal above first' : 'Save result to this deal'}><Save size={15} /> Save to Deal</button>
            <button onClick={exportRentalPDF} className="btn btn-ghost text-sm px-3 py-1.5"><Download size={15} /> Export PDF</button>
            <div className="ml-auto text-[11px] text-[#6B7280] hidden sm:block">All math is local • instant</div>
          </div>
        </div>
      )
    }

    if (activeTab === 'creative') {
      const creStrengthVal = creStrength()

      const copyCreative = () => {
        const text = `Creative Finance\nTotal Entry: ${formatCurrency(creTotalEntry)}\nMonthly CF: ${formatCurrency(creMonthlyCF)}\nAnnual CF: ${formatCurrency(creAnnualCF)}\nPayback (mo): ${crePaybackMo}\nCash-on-Cash: ${creCoC.toFixed(1)}%\nStrength: ${creStrengthVal}\n(Deal Blast Pro)`
        navigator.clipboard.writeText(text).then(() => toast.success('Creative results copied'))
      }

      const saveCreative = () => {
        saveCalcResultToDeal('creative', {
          entryCost: creTotalEntry,
          monthlyCF: creMonthlyCF,
          annualCF: creAnnualCF,
          paybackMo: crePaybackMo,
          cashOnCash: Math.round(creCoC * 10) / 10,
          strength: creStrengthVal
        })
      }

      const exportCreativePDF = () => {
        const w = window.open('', '_blank', 'width=800,height=600')
        if (!w) { toast.error('Popup blocked'); return }
        const summary = `Creative Finance\nEntry Cost: ${formatCurrency(creTotalEntry)}\nMonthly CF: ${formatCurrency(creMonthlyCF)}\nPayback: ${crePaybackMo} mo\nCoC: ${creCoC.toFixed(1)}%\nStrength: ${creStrengthVal}`
        w.document.write(`<html><head><title>Creative Summary</title><style>body{font-family:system-ui;padding:30px;background:#fff;color:#111}</style></head><body><h2>Creative Finance Results</h2><pre style="white-space:pre-wrap">${summary}</pre><p>Print → Save as PDF</p></body></html>`)
        w.document.close()
        setTimeout(() => w.print(), 200)
      }

      return (
        <div>
          <div className="mb-4">
            <div className="text-lg font-semibold text-white">Creative Finance Calculator</div>
            <div className="text-sm text-[#8B92A3]">Seller finance / subject-to pro-forma</div>
          </div>

          {/* Inputs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-5">
            <div><div className="text-xs mb-1">Purchase Price</div><input type="number" value={crePurchase || ''} onChange={e => setCrePurchase(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Down Payment</div><input type="number" value={creDown || ''} onChange={e => setCreDown(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Seller Monthly Payment</div><input type="number" value={creSellerPmt || ''} onChange={e => setCreSellerPmt(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Existing Mortgage Pmt (if Subject-To)</div><input type="number" value={creExistingPmt || ''} onChange={e => setCreExistingPmt(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Interest Rate %</div><input type="number" value={creRate || ''} onChange={e => setCreRate(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Amortization Term (mo)</div><input type="number" value={creAmort || ''} onChange={e => setCreAmort(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Balloon Term (mo)</div><input type="number" value={creBalloon || ''} onChange={e => setCreBalloon(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Entry Costs</div><input type="number" value={creEntry || ''} onChange={e => setCreEntry(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Closing Costs</div><input type="number" value={creClosing || ''} onChange={e => setCreClosing(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Assignment / Wholesale Fee</div><input type="number" value={creFee || ''} onChange={e => setCreFee(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Monthly Rent</div><input type="number" value={creRent || ''} onChange={e => setCreRent(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Other Monthly Income</div><input type="number" value={creOtherIncome || ''} onChange={e => setCreOtherIncome(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Taxes (mo)</div><input type="number" value={creTaxes || ''} onChange={e => setCreTaxes(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Insurance (mo)</div><input type="number" value={creIns || ''} onChange={e => setCreIns(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">HOA (mo)</div><input type="number" value={creHOA || ''} onChange={e => setCreHOA(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Utilities (mo)</div><input type="number" value={creUtil || ''} onChange={e => setCreUtil(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Vacancy %</div><input type="number" value={creVac || ''} onChange={e => setCreVac(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Maintenance %</div><input type="number" value={creMaint || ''} onChange={e => setCreMaint(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
            <div><div className="text-xs mb-1">Property Management %</div><input type="number" value={creMgmt || ''} onChange={e => setCreMgmt(Math.max(0, parseFloat(e.target.value) || 0))} className="input" /></div>
          </div>

          {/* Outputs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            <div className="bg-[#052E16] border border-[#22C55E]/40 rounded p-3 text-center"><div className="text-xs text-[#4ADE80]">TOTAL ENTRY COST</div><div className="text-2xl font-bold text-[#22C55E] mt-1">{formatCurrency(creTotalEntry)}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">MONTHLY CASH FLOW</div><div className="text-2xl font-bold mt-1">{formatCurrency(creMonthlyCF)}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">ANNUAL CASH FLOW</div><div className="text-2xl font-bold mt-1">{formatCurrency(creAnnualCF)}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">PAYBACK (MONTHS)</div><div className="text-2xl font-bold mt-1">{crePaybackMo === 999 ? '∞' : crePaybackMo}</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">CASH-ON-CASH</div><div className="text-2xl font-bold mt-1">{creCoC.toFixed(1)}%</div></div>
            <div className="bg-[#0F111A] border border-[#252A38] rounded p-3 text-center"><div className="text-xs">DEAL STRENGTH</div><div className={`text-2xl font-bold mt-1 ${creStrengthVal === 'Strong' ? 'text-[#22C55E]' : creStrengthVal === 'Moderate' ? 'text-[#FBBF24]' : 'text-red-400'}`}>{creStrengthVal}</div></div>
          </div>

          <div className="pt-4 border-t border-[#252A38] flex flex-wrap items-center gap-2">
            <button onClick={copyCreative} className="btn btn-ghost text-sm px-3 py-1.5"><Copy size={15} /> Copy Results</button>
            <button onClick={saveCreative} disabled={!selectedDealId} className="btn btn-ghost text-sm px-3 py-1.5 disabled:opacity-40 disabled:cursor-not-allowed" title={!selectedDealId ? 'Select a deal above first' : 'Save result to this deal'}><Save size={15} /> Save to Deal</button>
            <button onClick={exportCreativePDF} className="btn btn-ghost text-sm px-3 py-1.5"><Download size={15} /> Export PDF</button>
            <div className="ml-auto text-[11px] text-[#6B7280] hidden sm:block">All math is local • instant</div>
          </div>
        </div>
      )
    }

    // All other tabs safely disabled (should not reach here)
    return (
      <div className="p-8 text-center text-[#8B92A3]">
        <div className="text-lg mb-2">Coming soon, safely disabled.</div>
        <div className="text-sm">All calculators are now restored.</div>
      </div>
    )
  }

  return (
    <LocalDealCalcBoundary>
      <div className="max-w-[1100px] mx-auto px-4 pb-12">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-3">
            <Link to="/app/inventory" className="mt-1 text-[#8B92A3] hover:text-white transition-colors" title="Back to Inventory">
              <ChevronLeft size={20} />
            </Link>
            <div>
              <div className="flex items-center gap-3">
                <div className="text-3xl font-semibold tracking-[-0.5px]">Deal Calculator</div>
                <div className="px-2.5 py-0.5 text-[10px] font-bold tracking-[1px] rounded bg-[#22C55E] text-black">PRO</div>
              </div>
              <div className="text-[#8B92A3] text-sm -mt-0.5">All calculators active.</div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2 text-xs px-3 py-1.5 rounded-lg bg-[#171B26] border border-[#252A38] text-[#8B92A3]">
            <Calculator size={14} /> LOCAL • INSTANT • NO DATA SENT
          </div>
        </div>

        {/* Deal Selector Dropdown (Part 2) - safe, only affects this page */}
        <div className="mb-4">
          <div className="text-xs font-medium text-[#8B92A3] mb-1">Select Deal / Property (for prefill + Save to Deal)</div>
          <div className="flex gap-2 items-center">
            <input
              type="text"
              value={dealSearchTerm}
              onChange={e => setDealSearchTerm(e.target.value)}
              placeholder="Search deals..."
              className="input flex-1 text-sm py-1.5"
            />
            <select
              value={selectedDealId || ''}
              onChange={e => {
                const id = e.target.value || null
                setSelectedDealId(id)
                if (id) {
                  doPrefillFromDeal(id)
                  const d = useAppStore.getState().getDeal(id)
                  toast.success(`Prefilled Subject fields from ${d?.property?.address || 'selected deal'}`)
                } else {
                  // manual mode - leave subject as-is or clear if desired
                }
              }}
              className="select w-80 text-sm py-1.5"
            >
              <option value="">— No deal selected (manual mode) —</option>
              {[...(useAppStore.getState().getInventoryDeals?.() || []), ...(useAppStore.getState().getSubmissionsQueue?.() || [])]
                .filter(d => {
                  const q = dealSearchTerm.toLowerCase()
                  if (!q) return true
                  const addr = (d.property?.address || '').toLowerCase()
                  return addr.includes(q)
                })
                .slice(0, 50)
                .map(d => (
                  <option key={d.id} value={d.id}>
                    {d.property?.address || 'Unknown'}, {d.property?.city || ''} {d.property?.state || ''} • {d.property?.type || ''} • {d.status}
                  </option>
                ))}
            </select>
          </div>
          <div className="text-[11px] mt-1 text-[#6B7280]">
            {selectedDealId ? `Calculating for: ${useAppStore.getState().getDeal(selectedDealId)?.property?.address || 'selected property'}` : 'Manual mode — Save to Deal disabled.'}
          </div>
        </div>

        {/* Tab Switcher - safe, no horizontal scroll, wraps on small screens */}
        <div className="flex flex-wrap gap-1 pb-px mb-5 border-b border-[#252A38]">
          {tabs.map(tab => {
            const Icon = tab.icon
            const isActive = activeTab === tab.id
            const isEnabled = tab.id === 'arv' || tab.id === 'rehab' || tab.id === 'mao' || tab.id === 'rental' || tab.id === 'creative'
            return (
              <button
                key={tab.id}
                onClick={() => { if (!isEnabled) return; setActiveTab(tab.id); }}
                disabled={!isEnabled}
                className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-t-lg whitespace-nowrap transition-all border-b-2 -mb-px ${
                  isActive
                    ? 'bg-[#0F111A] border-[#22C55E] text-white'
                    : isEnabled
                      ? 'border-transparent text-[#8B92A3] hover:text-[#CBD5E1] hover:bg-[#171B26]/60'
                      : 'border-transparent text-[#6B7280] opacity-60 cursor-not-allowed'
                }`}
              >
                <Icon size={15} />
                {tab.label}
                {!isEnabled && (
                  <span className="ml-1 text-[9px] px-1.5 py-0.5 rounded bg-[#252A38] text-[#8B92A3]">
                    Coming Soon
                  </span>
                )}
              </button>
            )
          })}
        </div>

        {/* Content Card - always protected by the outer boundary */}
        <div className="card p-6 md:p-7">
          {renderTabContent()}
        </div>

        <div className="text-center text-[11px] text-[#6B7280] mt-8">
          ARV restored safely. Other tabs disabled. Works with or without a selected deal.
        </div>
      </div>
    </LocalDealCalcBoundary>
  )
}
