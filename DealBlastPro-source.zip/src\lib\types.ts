// Core domain types for Deal Blast Pro - schema safe

export type DealStatus =
  | 'Draft' | 'Submitted' | 'Needs Info' | 'Approved' | 'Active'
  | 'Blasted' | 'Offers Received' | 'Under Contract' | 'Closing' | 'Sold' | 'Dead'

export type PropertyType =
  | 'SFH' | 'Multifamily' | 'MHP' | 'Hotel' | 'Retail' | 'Storage' | 'Land' | 'Mixed-Use' | 'Other'

export type BuyerType =
  | 'Cash Buyer' | 'Hedge Fund' | 'JV Partner' | 'Lender' | 'Wholesaler' | 'Creative Buyer' | 'Agent'

export type BuyerStatus = 'New' | 'Active' | 'Hot' | 'Contacted' | 'Interested' | 'Do Not Contact' | 'Inactive'

export type OfferStatus = 'New' | 'Reviewing' | 'Accepted' | 'Rejected' | 'Countered'

export interface SubmitterInfo {
  name: string
  company?: string
  email: string
  phone: string
  role: string
  isOwner: boolean
  jvStructure?: string
  consent: boolean
}

export interface PropertyInfo {
  address: string
  city: string
  state: string
  zip: string
  county?: string
  type: PropertyType
  strategy: string
  beds?: number
  baths?: number
  units?: number
  sqft?: number
  lotSize?: number
  yearBuilt?: number
  occupancy: string
  description?: string
}

export interface PricingInfo {
  askingPrice?: number
  contractPrice?: number
  assignmentFee?: number
  buyerPrice?: number
  arv?: number
  rehab?: number
  currentRent?: number
  marketRent?: number
  grossMonthly?: number
  grossAnnual?: number
  noi?: number
  capRate?: number
  sellerFinance: boolean
  downPayment?: number
  monthlyPayment?: number
  interestRate?: number
  balloonTerm?: number
  amortization?: number
  pitiIncluded?: boolean
}

export interface DebtInfo {
  isFreeClear: boolean
  mortgageBalance?: number
  monthlyPayment?: number
  interestRate?: number
  arrears?: number
  taxesOwed?: number
  liens?: string
  helocBalance?: number
  otherDebt?: number
  titleCompany?: string
  titleContact?: string
  probate?: boolean
  foreclosure?: boolean
  codeViolations?: boolean
  eviction?: boolean
  ownershipIssues?: string
}

export interface ConditionInfo {
  roof?: string
  hvac?: string
  plumbing?: string
  electrical?: string
  foundation?: string
  majorRepairs?: string
  rehabNotes?: string
  occupancyStatus: string
  tenantDetails?: string
  leaseTerms?: string
  section8?: boolean
  walkthroughAvailable: boolean
  lockbox?: string
  photosVideosAvailable?: boolean
}

export interface ClosingInfo {
  closingDate?: string
  titleCompany?: string
  escrowOfficer?: string
  buyerEntity?: string
  emdAmount?: number
  emdDate?: string
  fundingStatus?: string
  commissionExpected?: number
  commissionPaid?: number
  closingNotes?: string
  checklist: Record<string, boolean>
}

export interface BuyerResponse {
  status: 'Interested' | 'Needs More Info' | 'Passed' | 'Made Offer' | 'NDA Requested' | 'BIO Sent' | 'No Response'
  date: string
  notes?: string
}

export interface BlastLog {
  id: string
  sentAt: string
  template: string
  subject: string
  recipientCount: number
  suppressedCount: number
  duplicateCount: number
  selectedDocNames: string[]
  ndaRequired: boolean
  sentBy: string
  status: 'Drafted' | 'Sent' | 'Follow-Up Needed' | 'Closed'
}

export interface DealSuppression {
  buyerId: string
  reason: string
  suppressedAt: string
}

export interface Doc {
  id: string
  category: string
  name: string
  url: string // object URL or data url for demo
  size?: number
  uploadedAt: string
  isRequired?: boolean
  isBuyerFacing?: boolean
  requiresNDA?: boolean
}

export interface Activity {
  id: string
  timestamp: string
  type: string
  description: string
  user?: string
  dealId?: string
}

export interface Offer {
  id: string
  buyerId?: string
  buyerName: string
  buyerEmail: string
  amount: number
  emd?: number
  financingType: string
  closingTimeline: string
  contingencies?: string
  status: OfferStatus
  notes?: string
  counterAmount?: number
  proofOfFunds?: string
  createdAt: string
  history: Array<{ ts: string; note: string }>
}

export interface Deal {
  id: string
  createdAt: string
  updatedAt: string
  status: DealStatus
  submitter: SubmitterInfo
  property: PropertyInfo
  pricing: PricingInfo
  debt: DebtInfo
  condition: ConditionInfo
  docs: Doc[]
  notes?: string
  closing?: ClosingInfo
  // Computed / runtime
  matchCount?: number
  source?: string
}

export interface Buyer {
  id: string
  name: string
  email: string
  phone?: string
  company?: string
  type: BuyerType
  markets: string[] // states or "Nationwide"
  cities?: string[]
  assetTypes: PropertyType[]
  budgetMin?: number
  budgetMax?: number
  unitMin?: number
  unitMax?: number
  capRateMin?: number
  rehabTolerance?: string
  sellerFinance: boolean
  creativeFinance: boolean
  notes?: string
  tags: string[]
  lastContacted?: string
  status: BuyerStatus
  strengthScore?: number
  createdAt: string
}

export interface MatchResult {
  buyer: Buyer
  score: number
  tier: 'Strong Match' | 'Possible Match' | 'Weak Match'
  reasons: string[]
  missing: string[]
}

export interface User {
  id: string
  name: string
  email: string
  company?: string
  role: 'Admin' | 'Team Member / VA' | 'Buyer' | 'Seller / Submitter' | 'Viewer'
  avatar?: string
}

export interface TrialState {
  isActive: boolean
  daysLeft: number
  endDate: string
  usage: {
    dealsSubmitted: number
    buyersImported: number
    blastsSent: number
    exports: number
  }
  isPaid: boolean
}

export interface AppSettings {
  requiredFieldsByType: Record<PropertyType, string[]>
  requiredDocsByType: Record<PropertyType, string[]>
  matchingWeights: {
    state: number
    city: number
    assetType: number
    budget: number
    units: number
    capRate: number
    sellerFinance: number
    creative: number
    rehab: number
    tags: number
  }
  blastTemplates: Record<string, { subject: string; body: string }>
  pipelineStatuses: DealStatus[]
  teamPermissions: Record<string, string[]>
}

export interface AppState {
  user: User | null
  trial: TrialState
  deals: Deal[]
  buyers: Buyer[]
  offers: Record<string, Offer[]>
  activities: Record<string, Activity[]>
  documents: Record<string, Doc[]> // per deal
  settings: AppSettings
  viewedDealIds: string[]
  viewedBuyerIds: string[]
  suppressionList: string[]
  sidebarOpen: boolean
  currentDealId: string | null // for terminal drawer

  // Operational state (blast, buyer responses, suppressions, follow-ups, attention)
  blastLogs: Record<string, BlastLog[]>
  buyerResponses: Record<string, Record<string, BuyerResponse>>
  dealSuppressions: Record<string, DealSuppression[]>
  followUps: any[]
  dismissedAttention: Record<string, { dismissedAt: string; issueKeys: string[] }>
}
