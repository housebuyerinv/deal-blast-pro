import { useState } from 'react'
import { Link } from 'react-router-dom'
import DealIntakeWizard from '../app/DealIntakeWizard'
import PublicNav from '../../components/layout/PublicNav'

export default function Portal() {
  const [showWizard, setShowWizard] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  return (
    <div className="min-h-screen bg-[#0A0C12]">
      <PublicNav />
      <div className="max-w-3xl mx-auto px-6 pt-6">
        <div className="text-sm text-[#8B92A3] mb-8">Public Submission Portal — secure intake for partners and bird dogs</div>

        <div className="text-center mb-8">
          <div className="inline px-4 py-1 bg-[#22C55E]/10 text-[#22C55E] rounded text-xs font-semibold tracking-widest mb-3">PUBLIC SUBMISSION PORTAL</div>
          <h1 className="text-4xl font-semibold tracking-tight">Submit a Deal</h1>
          <p className="text-[#8B92A3] mt-2">Submit your deal once. We’ll review the details, check for missing information, and organize it for qualified buyer outreach.</p>
        </div>

        {/* Trust Header */}
        <div className="card p-4 mb-6 text-sm bg-[#12151F] border border-[#252A38]">
          <strong>Trusted by professional dispo teams.</strong> We only collect the information needed to properly review, match, and market your opportunity to qualified buyers.
        </div>

        {/* Who Should Submit */}
        <div className="mb-6">
          <div className="font-medium mb-2">Who Should Submit?</div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
            {['Property Owners', 'Wholesalers', 'Real Estate Agents', 'JV Partners', 'Bird Dogs'].map(role => (
              <div key={role} className="panel p-3 text-center">{role}</div>
            ))}
          </div>
        </div>

        <div className="card p-8">
          <div className="mb-6 text-sm text-[#8B92A3]">Use the secure submission wizard to share your deal details for review. We’ll check the information and follow up if anything is missing.</div>
          
          <button onClick={() => setShowWizard(true)} className="btn btn-green w-full py-4 text-lg justify-center">
            Open Secure Submission Wizard
          </button>

          <div className="text-xs text-center mt-4 text-[#8B92A3]">
            We do not sell your deal information. Details are used only for review, organization, and buyer-matching inside Deal Blast Pro.
          </div>
        </div>

        {showWizard && (
          <div className="mt-6">
            <DealIntakeWizard 
              isPortal 
              submissionSource="Public Portal" 
              onComplete={(_deal) => {
                setShowWizard(false)
                setSubmitted(true)
              }} 
            />
          </div>
        )}

        {submitted && !showWizard && (
          <div className="card p-8 text-center mt-6">
            <div className="text-2xl font-semibold mb-4 text-[#22C55E]">Deal Submitted Successfully</div>
            <div className="text-[#C5CAD6] mb-6 max-w-md mx-auto">
              Thank you. Your deal has been submitted for review. We’ll check the details and follow up if anything else is needed.
            </div>
            <div className="text-xs text-[#8B92A3] mb-6">Estimated Review Time: 24–48 hours</div>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button onClick={() => { setSubmitted(false); setShowWizard(true) }} className="btn btn-green">Submit Another Deal</button>
              <Link to="/" className="btn btn-ghost">Exit to Home</Link>
            </div>
          </div>
        )}

        <div className="mt-6 text-xs text-center text-[#8B92A3]">Questions? Use the Contact page or submit your deal details through the portal.</div>

        <footer className="border-t border-[#252A38] mt-12 py-8 text-center text-xs text-[#8B92A3]">
          House Buyer Investments • Deal Blast Pro<br />
          <Link to="/pricing" className="hover:text-white">Pricing</Link> · 
          <Link to="/portal" className="hover:text-white">Submit Deal</Link> · 
          <Link to="/contact" className="hover:text-white">Contact</Link> · 
          <Link to="/privacy" className="hover:text-white">Privacy</Link> · 
          <Link to="/terms" className="hover:text-white">Terms</Link> · 
          <Link to="/security" className="hover:text-white">Security</Link>
        </footer>
      </div>
    </div>
  )
}
