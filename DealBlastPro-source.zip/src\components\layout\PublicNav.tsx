import { Link } from 'react-router-dom'

export default function PublicNav() {
  return (
    <nav className="border-b border-[#252A38] bg-[#0A0C12]/80 backdrop-blur sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 bg-[#22C55E] rounded flex items-center justify-center text-black font-black text-2xl">D</div>
            <div className="font-semibold text-xl tracking-[-1px]">DEAL BLAST PRO</div>
          </Link>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <Link to="/" className="hover:text-white">Home</Link>
          <Link to="/pricing" className="hover:text-white">Pricing</Link>
          <Link to="/portal" className="hover:text-white">Submit Deal</Link>
          <Link to="/contact" className="hover:text-white">Contact</Link>
          <Link to="/login" className="px-3 py-1.5 hover:text-white">Login</Link>
          <Link to="/register" className="btn btn-primary px-5 py-1.5 text-sm">Start Free Demo</Link>
        </div>
      </div>
    </nav>
  )
}
