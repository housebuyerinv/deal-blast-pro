import { useState, useEffect } from 'react'
import { useAppStore } from '../store/useAppStore'
import { X } from 'lucide-react'
import { toast } from 'sonner'

const TOUR_STEPS = [
  { id: 1, title: "Welcome to Deal Blast Pro", desc: "This is your Command Center — the heart of your dispo operation." },
  { id: 2, title: "Submit Deals via Portal", desc: "External submitters use the public portal for clean, structured intake." },
  { id: 3, title: "Review & Approve Submissions", desc: "Use the strong Approval Gate with Deal Quality Score before moving deals to Inventory." },
  { id: 4, title: "Inventory Hub", desc: "Only approved/active deals live here. Rich management terminal on click." },
  { id: 5, title: "Global Buyer CRM", desc: "Import, segment, heat scores, and deep profiles with match history." },
  { id: 6, title: "Buyer Segments & Matching", desc: "Saved segments + powerful weighted matching engine." },
  { id: 7, title: "Blast Builder", desc: "Templates, live preview, Gmail BCC batches, attachments, and logging." },
  { id: 8, title: "Follow-Up Task Center", desc: "Never miss a follow-up. Generate emails and track responses." },
  { id: 9, title: "Analytics & Pipeline", desc: "Real performance data + visual Kanban board for daily operations." },
  { id: 10, title: "Settings & Demo Controls", desc: "Team permissions, backend readiness, full data export/import." }
]

export default function OnboardingTour() {
  const [isOpen, setIsOpen] = useState(false)
  const [step, setStep] = useState(1)
  const { user } = useAppStore()

  const TOUR_COMPLETED_KEY = 'dealblastpro-tour-completed'

  useEffect(() => {
    if (!user) return
    const completed = localStorage.getItem(TOUR_COMPLETED_KEY)
    if (!completed) {
      // Show tour after short delay on first login
      const timer = setTimeout(() => setIsOpen(true), 1200)
      return () => clearTimeout(timer)
    }
  }, [user])

  const currentStep = TOUR_STEPS.find(s => s.id === step) || TOUR_STEPS[0]

  const next = () => {
    if (step < TOUR_STEPS.length) {
      setStep(step + 1)
    } else {
      completeTour()
    }
  }

  const prev = () => {
    if (step > 1) setStep(step - 1)
  }

  const skip = () => {
    completeTour()
  }

  const completeTour = () => {
    localStorage.setItem(TOUR_COMPLETED_KEY, 'true')
    setIsOpen(false)
    toast.success('Tour completed. You can restart it anytime from Settings.')
  }

  const restartTour = () => {
    localStorage.removeItem(TOUR_COMPLETED_KEY)
    setStep(1)
    setIsOpen(true)
  }

  // Expose restart function globally for Settings
  ;(window as any).restartDealBlastTour = restartTour

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/80 z-[300] flex items-center justify-center p-4">
      <div className="card w-full max-w-lg p-6 relative">
        <button onClick={skip} className="absolute top-4 right-4 text-[#8B92A3] hover:text-white">
          <X size={18} />
        </button>

        <div className="mb-4">
          <div className="text-xs text-[#8B92A3]">ONBOARDING TOUR • STEP {step} OF {TOUR_STEPS.length}</div>
          <div className="h-1 bg-[#252A38] mt-2 rounded">
            <div className="h-1 bg-[#22C55E] rounded" style={{ width: `${(step / TOUR_STEPS.length) * 100}%` }} />
          </div>
        </div>

        <div className="text-xl font-semibold mb-2">{currentStep.title}</div>
        <div className="text-[#C5CAD6] mb-6">{currentStep.desc}</div>

        <div className="flex justify-between">
          <button onClick={prev} disabled={step === 1} className="btn btn-ghost disabled:opacity-40">Previous</button>
          
          <div className="flex gap-2">
            <button onClick={skip} className="btn btn-ghost">Skip Tour</button>
            <button onClick={next} className="btn btn-primary">
              {step === TOUR_STEPS.length ? 'Finish' : 'Next'}
            </button>
          </div>
        </div>

        <div className="mt-4 text-center">
          <button 
            onClick={() => {
              // Trigger sample workflow
              const result = useAppStore.getState().runSampleWorkflow()
              completeTour()
              setTimeout(() => {
                useAppStore.getState().safeOpenDeal(result.dealId)
              }, 800)
            }} 
            className="text-sm text-[#3B82F6] hover:underline"
          >
            Or try a full sample workflow instead →
          </button>
        </div>
      </div>
    </div>
  )
}
