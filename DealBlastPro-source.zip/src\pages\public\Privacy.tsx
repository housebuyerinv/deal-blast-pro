
import { Link } from 'react-router-dom'

export default function Privacy() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12 text-[#E6E8EE]">
      <Link to="/" className="text-sm text-[#3B82F6]">← Back to home</Link>
      <h1 className="text-3xl font-semibold mt-6 mb-4">Privacy Policy</h1>

      <div className="prose prose-invert text-sm">
        <p className="text-amber-400 font-medium">⚠️ DRAFT PLACEHOLDER — Replace with real legal copy before launch.</p>

        <p>This is a placeholder privacy policy for the Deal Blast Pro demo application.</p>

        <h2 className="mt-6">Data We Collect (Demo)</h2>
        <ul>
          <li>All data you enter is stored only in your browser's localStorage.</li>
          <li>No data is sent to any server in the current demo version.</li>
          <li>We do not track or sell any information.</li>
        </ul>

        <h2 className="mt-6">Future Production Behavior</h2>
        <p>Once connected to a backend, we will collect the minimum data necessary to provide the service (deals, buyers, activity logs, etc.). Full details will be published here.</p>

        <p className="mt-8 text-xs text-[#8B92A3]">Last updated: Demo version • This is not legal advice.</p>

        <footer className="border-t border-[#252A38] mt-12 py-6 text-center text-xs text-[#8B92A3]">
          House Buyer Investments • Deal Blast Pro<br />
          <Link to="/pricing" className="hover:text-white">Pricing</Link> · 
          <Link to="/portal" className="hover:text-white">Submit Deal</Link> · 
          <Link to="/contact" className="hover:text-white">Contact</Link> · 
          <Link to="/privacy" className="hover:text-white">Privacy</Link> · 
          <Link to="/terms" className="hover:text-white">Terms</Link> · 
          <Link to="/security" className="hover:text-white">Security</Link>
        </footer>
      </div>
    </div>
  )
}
