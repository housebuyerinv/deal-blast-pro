
import { Link } from 'react-router-dom'

export default function Terms() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12 text-[#E6E8EE]">
      <Link to="/" className="text-sm text-[#3B82F6]">← Back to home</Link>
      <h1 className="text-3xl font-semibold mt-6 mb-4">Terms of Service</h1>

      <div className="prose prose-invert text-sm">
        <p className="text-amber-400 font-medium">⚠️ DRAFT PLACEHOLDER — Replace with real legal copy before launch.</p>

        <p>These are placeholder terms for the Deal Blast Pro demonstration application.</p>

        <h2 className="mt-6">Current Demo Status</h2>
        <p>This application is provided for demonstration and evaluation purposes only. All data is stored locally in your browser and may be lost at any time.</p>

        <h2 className="mt-6">No Warranty</h2>
        <p>The demo is provided "as is" with no guarantees of data retention, uptime, or accuracy.</p>

        <p className="mt-8 text-xs text-[#8B92A3]">Last updated: Demo version • This is not legal advice.</p>

        <footer className="border-t border-[#252A38] mt-12 py-6 text-center text-xs text-[#8B92A3]">
          House Buyer Investments • Deal Blast Pro<br />
          <Link to="/pricing" className="hover:text-white">Pricing</Link> · 
          <Link to="/portal" className="hover:text-white">Submit Deal</Link> · 
          <Link to="/contact" className="hover:text-white">Contact</Link> · 
          <Link to="/privacy" className="hover:text-white">Privacy</Link> · 
          <Link to="/terms" className="hover:text-white">Terms</Link> · 
          <Link to="/security" className="hover:text-white">Security</Link>
        </footer>
      </div>
    </div>
  )
}
