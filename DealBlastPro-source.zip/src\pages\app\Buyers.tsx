import React, { useState, useEffect } from 'react'
import { useAppStore } from '../../store/useAppStore'
import { useSearchParams } from 'react-router-dom'
import Papa from 'papaparse'
import { Upload, X, Building2, Home, TrendingUp, MapPin, Star, Flame, CheckSquare, Square, Warehouse, Hotel, Store, Building, Landmark } from 'lucide-react'
import { toast } from 'sonner'
import { Buyer } from '../../lib/types'
import Tooltip from '../../components/Tooltip'

interface ImportResult {
  total: number
  added: number
  dups: number
  suppressed: number
  invalid: number
  preview: Array<{ existing?: Buyer; incoming: any; action: string }>
}

export default function Buyers() {
  const { 
    buyers, isNewBuyer, markBuyerViewed, importBuyers, 
    addToSuppression, updateBuyer,
    getBuyerMatchHistory
  } = useAppStore()

  const [search, setSearch] = useState('')
  const [showImport, setShowImport] = useState(false)
  const [importResult, setImportResult] = useState<ImportResult | null>(null)
  const [pendingImport, setPendingImport] = useState<any[]>([]) // rows waiting for review/approve before any store write
  const [selectedBuyerIds, setSelectedBuyerIds] = useState<string[]>([])
  const [selectedBuyer, setSelectedBuyer] = useState<Buyer | null>(null) // Buyer profile drawer state
  const [editBuyer, setEditBuyer] = useState<any>({}) // for inline editing in drawer

  // Buyer Custom Lists (localStorage persisted)
  const [buyerLists, setBuyerLists] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('dbp_buyer_lists')
      return saved ? JSON.parse(saved) : []
    } catch { return [] }
  })
  const [showListModal, setShowListModal] = useState(false)
  const [newListName, setNewListName] = useState('')
  const [currentListId, setCurrentListId] = useState<string | null>(null) // for viewing a specific list

  // Sort & Filter state for Buyer DB
  const [sortMode, setSortMode] = useState('heat-high')
  const [activeFilters, setActiveFilters] = useState<string[]>([])
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)
  const [activeTab, setActiveTab] = useState('all') // all | segments | lists
  const [selectedSegment, setSelectedSegment] = useState<string | null>(null) // for viewing specific segment

  // Persist buyer lists
  React.useEffect(() => {
    try { localStorage.setItem('dbp_buyer_lists', JSON.stringify(buyerLists)) } catch {}
  }, [buyerLists])

  const toggleBuyerSelection = (id: string) => {
    setSelectedBuyerIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }

  // Base buyer set per user's spec: tab + selection first, then search/sort/filters on top
  let baseBuyers = buyers;

  if (activeTab === 'lists' && currentListId) {
    const list = buyerLists.find(l => l.id === currentListId);
    baseBuyers = buyers.filter(b => list && (list.buyerIds || []).includes(b.id));
  } else if (activeTab === 'segments' && selectedSegment) {
    const seg = [
      { name: 'Alabama Buyers', filter: (b: any) => (b.markets ?? []).some((m: any) => m.includes('AL')) },
      { name: 'Nationwide Buyers', filter: (b: any) => (b.markets ?? []).some((m: any) => ['Nationwide','Any'].includes(m)) },
      { name: 'Creative Finance Buyers', filter: (b: any) => b.creativeFinance || b.sellerFinance },
      { name: 'Seller Finance Buyers', filter: (b: any) => b.sellerFinance },
      { name: 'Cash Buyers', filter: (b: any) => !b.creativeFinance && !b.sellerFinance },
      { name: 'Hot Buyers', filter: (b: any) => b.status === 'Hot' },
      { name: 'High Budget Buyers', filter: (b: any) => (b.budgetMax || 0) >= 1000000 },
      { name: 'Multifamily Buyers', filter: (b: any) => (b.assetTypes ?? []).includes('Multifamily') },
    ].find(s => s.name === selectedSegment);
    if (seg) baseBuyers = buyers.filter(seg.filter);
  } else {
    baseBuyers = buyers;
  }

  // Apply search on the correct base
  let workingBuyers = baseBuyers.filter(b =>
    (b.name ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (b.email ?? '').toLowerCase().includes(search.toLowerCase()) ||
    (b.markets ?? []).some(m => (m ?? '').toLowerCase().includes(search.toLowerCase()))
  )

  // Apply filters on top of the base + search
  if (activeFilters.includes('creative')) workingBuyers = workingBuyers.filter(b => b.creativeFinance || b.sellerFinance)
  if (activeFilters.includes('hot')) workingBuyers = workingBuyers.filter(b => b.status === 'Hot')
  if (activeFilters.includes('seller')) workingBuyers = workingBuyers.filter(b => b.sellerFinance)
  if (activeFilters.includes('cash')) workingBuyers = workingBuyers.filter(b => !b.creativeFinance && !b.sellerFinance)
  if (activeFilters.includes('hedge')) workingBuyers = workingBuyers.filter(b => (b.type || '').toLowerCase().includes('hedge'))

  // Advanced dropdown filters (state and asset) - applied on top of base + search + button filters
  const stateFilter = activeFilters.find(f => f.startsWith('state:'));
  if (stateFilter) {
    const st = stateFilter.split(':')[1].toUpperCase();
    workingBuyers = workingBuyers.filter(b => {
      const markets = (b.markets ?? []).map((m: string) => (m || '').toUpperCase());
      return markets.includes(st) || markets.includes('NATIONWIDE') || markets.includes('ANY');
    });
  }

  const assetFilter = activeFilters.find(f => f.startsWith('asset:'));
  if (assetFilter) {
    const at = assetFilter.split(':')[1].toLowerCase();
    workingBuyers = workingBuyers.filter(b => {
      const assets = (b.assetTypes ?? []).map((a: string) => (a || '').toLowerCase());
      return assets.some((a: string) => a.includes(at) || at.includes(a));
    });
  }

  // Apply sort
  workingBuyers = [...workingBuyers].sort((a, b) => {
    if (sortMode === 'heat-high') return (b.strengthScore || 0) - (a.strengthScore || 0)
    if (sortMode === 'strength-high') return (b.strengthScore || 0) - (a.strengthScore || 0)
    if (sortMode === 'budget-high') return (b.budgetMax || 0) - (a.budgetMax || 0)
    if (sortMode === 'budget-low') return (a.budgetMax || 0) - (b.budgetMax || 0)
    if (sortMode === 'recent') return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    if (sortMode === 'type') return (a.type || '').localeCompare(b.type || '')
    return (b.strengthScore || 0) - (a.strengthScore || 0)
  })

  const getBuyerBorderColor = (b: any) => {
    if (b.creativeFinance || b.sellerFinance) return '#f59e0b'; // Amber - Creative/Seller Finance
    if (!b.creativeFinance && !b.sellerFinance) return '#22c55e'; // Green - Cash
    if ((b.type || '').toLowerCase().includes('hedge')) return '#ef4444'; // Red - Hedge
    if ((b.type || '').toLowerCase().includes('institutional')) return '#a855f7'; // Purple
    if ((b.type || '').toLowerCase().includes('jv') || (b.type || '').toLowerCase().includes('partner')) return '#06b6d4'; // Cyan
    if ((b.type || '').toLowerCase().includes('broker') || (b.type || '').toLowerCase().includes('agent')) return '#6b7280'; // Gray
    return '#22c55e'; // Default Emerald/Green
  }

  const filtered = workingBuyers

  const formatBudget = (min?: number, max?: number): string => {
    const fmt = (n: number): string => {
      if (!n || n <= 0) return ''
      const abs = Math.abs(n)
      if (abs >= 1000000000) return '$' + (abs / 1000000000).toFixed(1).replace(/\.0$/, '') + 'B'
      if (abs >= 1000000) return '$' + (abs / 1000000).toFixed(abs % 1000000 === 0 ? 0 : 1).replace(/\.0$/, '') + 'M'
      if (abs >= 1000) return '$' + Math.round(abs / 1000) + 'K'
      return '$' + abs.toLocaleString()
    }
    const minStr = min != null && min > 0 ? fmt(min) : ''
    const maxStr = max != null && max > 0 ? fmt(max) : ''
    if (minStr && maxStr) return `${minStr} – ${maxStr}`
    if (maxStr) return `Up to ${maxStr}`
    if (minStr) return `${minStr}+`
    return 'Budget Unknown'
  }

  // Support direct open of Buyer Profile Drawer from Dashboard Hot Buyers (or external links)
  const [searchParams, setSearchParams] = useSearchParams()
  useEffect(() => {
    const buyerId = searchParams.get('buyer')
    if (buyerId && !selectedBuyer) {
      const found = buyers.find(b => b.id === buyerId)
      if (found) {
        setSelectedBuyer(found)
        setEditBuyer(found)
        // Clear param so it doesn't re-open on every render
        setSearchParams({})
      }
    }
  }, [searchParams, buyers, selectedBuyer, setSearchParams])

  // Buyer import: parse only into pending review state. No store write until user approves in review screen.
  const handleFile = (file: File) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const rows = results.data as any[]
        const mapped: any[] = []
        let invalidCount = 0

        rows.forEach((r: any) => {
          const email = (r.Email || r.email || r['Email Address'] || '').trim()
          if (!email) { invalidCount++; return }

          const name = r.Name || r.name || r['Full Name'] || email.split('@')[0]
          const markets = (r.Markets || r.states || r['Target Markets'] || 'Any')
            .toString().split(/[,\|]/).map((s: string) => s.trim()).filter(Boolean)
          const assetTypes = (r.Property_Types || r['Asset Types'] || r.Category || 'SFH')
            .toString().split(/[,\|]/).map((s: string) => s.trim())

          mapped.push({
            _id: 'tmp_' + Date.now() + Math.random().toString(36).slice(2),
            name,
            email,
            phone: r.Phone || r.phone || '',
            company: r.Company || r.company || '',
            type: (r.Buyer_Type || r['Buyer Type'] || 'Cash Buyer'),
            markets: markets.length ? markets : ['Any'],
            assetTypes: assetTypes.length ? assetTypes : ['SFH'],
            budgetMin: parseFloat((r.Budget || r['Budget Min'] || '0').toString().replace(/[$,]/g, '')) || 0,
            budgetMax: parseFloat((r['Budget Max'] || r.Budget || '500000').toString().replace(/[$,]/g, '')) || 500000,
            sellerFinance: /seller|creative|finance/i.test(r.Finance_Type || r['Finance Type'] || ''),
            creativeFinance: /seller|creative|assumable/i.test(r.Finance_Type || r['Finance Type'] || ''),
            notes: r.Notes || r.notes || '',
            tags: (r.Tags || '').toString().split(/[,\|]/).map((t: string) => t.trim()).filter(Boolean),
            status: 'Active',
            _valid: true,
            _dup: false
          })
        })

        // Mark dups against current buyers (for review UI)
        const withDupFlag = mapped.map(m => ({
          ...m,
          _dup: buyers.some(b => b.email.toLowerCase() === m.email.toLowerCase())
        }))

        setPendingImport(withDupFlag)
        setImportResult(null)
        toast.info(`${mapped.length} rows ready for review. ${invalidCount} invalid skipped.`)
      }
    })
  }

  // Review screen actions (edit/remove/merge/approve)
  const updatePendingRow = (id: string, changes: any) => {
    setPendingImport(prev => prev.map(r => r._id === id ? { ...r, ...changes } : r))
  }
  const removePendingRow = (id: string) => {
    setPendingImport(prev => prev.filter(r => r._id !== id))
  }
  const toggleMergePending = (id: string) => {
    setPendingImport(prev => prev.map(r => r._id === id ? { ...r, _merge: !r._merge } : r))
  }

  const approveSelected = () => {
    const toApprove = pendingImport.filter(r => r._valid !== false)
    if (toApprove.length === 0) return
    const result = importBuyers(toApprove.map(({_id, _dup, _valid, _merge, ...rest}) => rest))
    toast.success(`Approved ${toApprove.length} buyers (${result.added} new, ${result.dups} dups handled)`)
    setPendingImport([])
    setShowImport(false)
  }
  const approveAllValid = () => approveSelected()
  const skipInvalid = () => {
    setPendingImport(prev => prev.filter(r => r._valid !== false && !r._dup))
  }

  return (
    <div>
      <div className="flex justify-between items-end mb-4">
        <div>
          <div className="text-xs tracking-[1.5px] text-[#8B92A3]">ASSET STRATEGY</div>
          <div className="text-2xl font-semibold">Global Buyer Database — {buyers.length} records</div>
        </div>
        <button onClick={() => setShowImport(true)} className="btn btn-primary flex items-center gap-2">
          <Upload size={16} /> Import Buyers (CSV / TXT)
        </button>
      </div>

      {/* Tabs for All Buyers / Segments / Lists */}
      <div className="flex gap-2 mb-3 text-sm border-b border-[#252A38] pb-1">
        <button onClick={() => { setActiveTab('all'); setCurrentListId(null); setSelectedSegment(null); }} className={`px-3 py-1 ${activeTab === 'all' ? 'border-b-2 border-[#22C55E] font-medium' : 'text-[#8B92A3]'}`}>All Buyers</button>
        <button onClick={() => { setActiveTab('segments'); setCurrentListId(null); setSelectedSegment(null); }} className={`px-3 py-1 ${activeTab === 'segments' ? 'border-b-2 border-[#22C55E] font-medium' : 'text-[#8B92A3]'}`}>Saved Segments</button>
        <button onClick={() => { setActiveTab('lists'); setCurrentListId(null); setSelectedSegment(null); }} className={`px-3 py-1 ${activeTab === 'lists' ? 'border-b-2 border-[#22C55E] font-medium' : 'text-[#8B92A3]'}`}>Custom Lists</button>
      </div>

      {(activeTab === 'all' || (activeTab === 'lists' && currentListId) || (activeTab === 'segments' && selectedSegment)) && (
      <div className="flex gap-3 mb-4">
        <input 
          className="input flex-1" 
          placeholder="Search name, email, market..." 
          value={search} 
          onChange={e => setSearch(e.target.value)} 
        />
        <select className="select text-xs" value={sortMode} onChange={e => setSortMode(e.target.value)}>
          <option value="heat-high">Sort: Heat High → Low</option>
          <option value="strength-high">Sort: Strength High → Low</option>
          <option value="budget-high">Sort: Budget High → Low</option>
          <option value="budget-low">Sort: Budget Low → High</option>
          <option value="recent">Sort: Recently Added</option>
          <option value="type">Sort: Buyer Type</option>
        </select>

        <div className="flex gap-1 text-xs">
          <button 
            onClick={() => setActiveFilters(prev => prev.includes('creative') ? prev.filter(x => x !== 'creative') : [...prev, 'creative'])} 
            className={`btn btn-ghost px-2 py-0.5 text-[10px] ${activeFilters.includes('creative') ? 'ring-1 ring-emerald-500 text-emerald-400' : ''}`}
          >Creative Only</button>
          <button 
            onClick={() => setActiveFilters(prev => prev.includes('hot') ? prev.filter(x => x !== 'hot') : [...prev, 'hot'])} 
            className={`btn btn-ghost px-2 py-0.5 text-[10px] ${activeFilters.includes('hot') ? 'ring-1 ring-orange-500 text-orange-400' : ''}`}
          >Hot</button>
          <button 
            onClick={() => setActiveFilters(prev => prev.includes('seller') ? prev.filter(x => x !== 'seller') : [...prev, 'seller'])} 
            className={`btn btn-ghost px-2 py-0.5 text-[10px] ${activeFilters.includes('seller') ? 'ring-1 ring-amber-500 text-amber-400' : ''}`}
          >Seller Finance</button>
          <button 
            onClick={() => setActiveFilters(prev => prev.includes('cash') ? prev.filter(x => x !== 'cash') : [...prev, 'cash'])} 
            className={`btn btn-ghost px-2 py-0.5 text-[10px] ${activeFilters.includes('cash') ? 'ring-1 ring-sky-500 text-sky-400' : ''}`}
          >Cash Buyers</button>
          <button 
            onClick={() => setActiveFilters(prev => prev.includes('hedge') ? prev.filter(x => x !== 'hedge') : [...prev, 'hedge'])} 
            className={`btn btn-ghost px-2 py-0.5 text-[10px] ${activeFilters.includes('hedge') ? 'ring-1 ring-purple-500 text-purple-400' : ''}`}
          >Hedge Funds</button>
        </div>

        <button onClick={() => setShowAdvancedFilters(!showAdvancedFilters)} className={`btn btn-ghost text-xs ${showAdvancedFilters ? 'ring-1 ring-blue-500' : ''}`}>Advanced Filters</button>
        <button onClick={() => { setSearch(''); setSortMode('heat-high'); setActiveFilters([]); setShowAdvancedFilters(false); setCurrentListId(null); setSelectedSegment(null); }} className="btn btn-ghost text-xs">Clear Filters</button>
        <button onClick={() => setSelectedBuyerIds(filtered.map(b => b.id))} className="btn btn-ghost text-xs">Select All</button>
        <button onClick={() => setSelectedBuyerIds([])} className="btn btn-ghost text-xs">Deselect All</button>
      </div>
      )}

      {/* Simple Advanced Filters Panel */}
      {showAdvancedFilters && (
        <div className="mb-3 p-3 bg-[#171B26] rounded text-xs">
          <div className="flex flex-wrap gap-2">
            <select className="select text-xs py-1 w-40" value={activeFilters.find(f => f.startsWith('state:'))?.split(':')[1] || 'All States'} onChange={e => {
              const val = e.target.value;
              if (val === 'All States') {
                setActiveFilters(prev => prev.filter(x => !x.startsWith('state:')));
              } else {
                setActiveFilters(prev => [...new Set([...prev.filter(x => !x.startsWith('state:')), `state:${val}`])]);
              }
            }}>
              <option value="All States">All States</option>
              <option value="Nationwide">Nationwide</option>
              <option value="Any">Any</option>
              <option value="AL">AL</option><option value="AK">AK</option><option value="AZ">AZ</option><option value="AR">AR</option>
              <option value="CA">CA</option><option value="CO">CO</option><option value="CT">CT</option><option value="DE">DE</option>
              <option value="FL">FL</option><option value="GA">GA</option><option value="HI">HI</option><option value="ID">ID</option>
              <option value="IL">IL</option><option value="IN">IN</option><option value="IA">IA</option><option value="KS">KS</option>
              <option value="KY">KY</option><option value="LA">LA</option><option value="ME">ME</option><option value="MD">MD</option>
              <option value="MA">MA</option><option value="MI">MI</option><option value="MN">MN</option><option value="MS">MS</option>
              <option value="MO">MO</option><option value="MT">MT</option><option value="NE">NE</option><option value="NV">NV</option>
              <option value="NH">NH</option><option value="NJ">NJ</option><option value="NM">NM</option><option value="NY">NY</option>
              <option value="NC">NC</option><option value="ND">ND</option><option value="OH">OH</option><option value="OK">OK</option>
              <option value="OR">OR</option><option value="PA">PA</option><option value="RI">RI</option><option value="SC">SC</option>
              <option value="SD">SD</option><option value="TN">TN</option><option value="TX">TX</option><option value="UT">UT</option>
              <option value="VT">VT</option><option value="VA">VA</option><option value="WA">WA</option><option value="WV">WV</option>
              <option value="WI">WI</option><option value="WY">WY</option>
            </select>
            <select className="select text-xs py-1 w-40" value={activeFilters.find(f => f.startsWith('asset:'))?.split(':')[1] || 'All Asset Types'} onChange={e => {
              const val = e.target.value;
              if (val === 'All Asset Types') {
                setActiveFilters(prev => prev.filter(x => !x.startsWith('asset:')));
              } else {
                setActiveFilters(prev => [...new Set([...prev.filter(x => !x.startsWith('asset:')), `asset:${val}`])]);
              }
            }}>
              <option value="All Asset Types">All Asset Types</option>
              <option value="Single Family">Single Family</option>
              <option value="Multifamily">Multifamily</option>
              <option value="Small Multifamily">Small Multifamily</option>
              <option value="Mobile Home Park">Mobile Home Park</option>
              <option value="Hotel">Hotel</option>
              <option value="Retail">Retail</option>
              <option value="Storage">Storage</option>
              <option value="Land">Land</option>
              <option value="Mixed Use">Mixed Use</option>
              <option value="Commercial">Commercial</option>
              <option value="Industrial">Industrial</option>
              <option value="Office">Office</option>
              <option value="Development">Development</option>
              <option value="Build-to-Rent">Build-to-Rent</option>
              <option value="Notes">Notes</option>
              <option value="Creative Finance">Creative Finance</option>
            </select>
            <button onClick={() => setActiveFilters([])} className="btn btn-ghost text-xs">Clear All Filters</button>
          </div>
          <div className="text-[10px] text-[#8B92A3] mt-1">Active: {activeFilters.length ? activeFilters.join(', ') : 'None'} (search + buttons also apply)</div>
        </div>
      )}

      {/* Bulk Actions Toolbar */}
      {selectedBuyerIds.length > 0 && (
        <div className="mb-3 flex flex-wrap gap-2 text-xs bg-[#171B26] p-2 rounded">
          <span className="text-[#8B92A3] mr-2">{selectedBuyerIds.length} selected</span>
          <button onClick={() => { /* export BCC */ const emails = buyers.filter(b => selectedBuyerIds.includes(b.id)).map(b => b.email).join(', '); navigator.clipboard.writeText(emails); toast.success('BCC copied'); }} className="btn btn-ghost px-2 py-0.5">Export BCC</button>
          <button onClick={() => { selectedBuyerIds.forEach(id => { const b = buyers.find(x => x.id === id); if (b) addToSuppression(b.email); }); setSelectedBuyerIds([]); toast.success('Suppressed selected'); }} className="btn btn-ghost px-2 py-0.5 text-amber-400">Suppress Selected</button>
          <button onClick={() => { if (confirm(`Delete ${selectedBuyerIds.length} buyers?`)) { setSelectedBuyerIds([]); toast('Deleted (demo)'); } }} className="btn btn-ghost px-2 py-0.5 text-red-400">Delete Selected</button>
          <button onClick={() => { setShowListModal(true); }} className="btn btn-ghost px-2 py-0.5 text-[#22C55E]">Add to List</button>
          {currentListId && <button onClick={() => {
            const list = buyerLists.find(l => l.id === currentListId);
            if (!list) return;
            const updatedLists = buyerLists.map(l => l.id === currentListId ? { ...l, buyerIds: (l.buyerIds || []).filter((id: string) => !selectedBuyerIds.includes(id)), updatedAt: Date.now() } : l);
            setBuyerLists(updatedLists);
            setSelectedBuyerIds([]);
            toast.success('Removed from list');
          }} className="btn btn-ghost px-2 py-0.5 text-red-400">Remove from List</button>}
          <button onClick={() => setSelectedBuyerIds([])} className="btn btn-ghost px-2 py-0.5">Clear Selection</button>
        </div>
      )}

      {(activeTab === 'all' || (activeTab === 'lists' && currentListId) || (activeTab === 'segments' && selectedSegment)) && (
      <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map(b => {
          const isSelected = selectedBuyerIds.includes(b.id);
          const hasCreative = b.creativeFinance || b.sellerFinance;
          const isCash = !b.creativeFinance && !b.sellerFinance;
          const company = (b.company ?? '') || 'Company Missing';
          const phone = (b.phone ?? '') || 'Phone Missing';
          const assetTypesSafe = b.assetTypes ?? [];
          const marketsSafe = b.markets ?? [];
          const heatScore = useAppStore.getState().getBuyerHeatScore(b.id);
          const strScore = b.strengthScore || 65;

          return (
            <div key={b.id} className={`card interactive-border buyer p-4 hover:border-[#3B82F6]/40 relative group flex flex-col ${selectedBuyerIds.includes(b.id) ? 'is-selected' : ''}`} style={{ '--border-color': getBuyerBorderColor(b) } as any}>
              {/* HEADER */}
              <div className="flex items-start justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <button onClick={(e) => { e.stopPropagation(); toggleBuyerSelection(b.id); }} className="text-[#8B92A3] hover:text-white">
                    {isSelected ? <CheckSquare size={16} className="text-[#22C55E]" /> : <Square size={16} />}
                  </button>
                  <div className="font-semibold text-base">{b.name}</div>
                </div>
                {isNewBuyer(b.id) && <span className="badge bg-[#22C55E] text-black text-[10px] px-1.5 py-0">NEW</span>}
                {(b.status === 'Hot') && <span className="badge bg-orange-500 text-black text-[10px] px-1.5 py-0">HOT</span>}
                {(() => {
                  const count = buyerLists.filter(l => (l.buyerIds || []).includes(b.id)).length;
                  return count > 0 ? <span className="text-[9px] text-[#8B92A3] ml-1">Lists:{count}</span> : null;
                })()}
              </div>

              {/* CONTACT */}
              <div className="text-xs text-[#8B92A3] truncate">{company}</div>
              <div className="text-sm text-[#3B82F6] truncate">{b.email}</div>
              <div className="text-xs text-[#8B92A3] mb-1">{phone}</div>

              {/* TARGET MARKETS — up to 3 rows (collapse only on 4th row) */}
              <div className="mt-3">
                <div className="text-[10px] uppercase tracking-[1px] text-[#8B92A3] mb-1 font-medium">Target Markets</div>
                <div className="flex flex-wrap gap-1.5 min-h-[18px]">
                  {(() => {
                    const states = marketsSafe.length ? marketsSafe : ['Any'];
                    const visible = states.slice(0, 15);
                    const extra = states.length - 15;
                    return (
                      <>
                        {visible.map((m: string, i: number) => (
                          <span key={i} className="badge bg-[#1F2937] text-[#93C5FD] text-[10px] px-1.5 py-0 flex items-center gap-0.5 border border-[#334155]">
                            <MapPin size={10} /> {m}
                          </span>
                        ))}
                        {extra > 0 && (
                          <Tooltip content={states.slice(15).join(', ')} position="top">
                            <span className="badge bg-[#1F2937] text-[#93C5FD] text-[10px] px-1.5 py-0 cursor-help border border-[#334155]">+{extra} more</span>
                          </Tooltip>
                        )}
                      </>
                    );
                  })()}
                </div>
              </div>

              {/* ASSET FOCUS — SHOW ALL (up to 3 rows, no collapse) */}
              <div className="mt-3">
                <div className="text-[10px] uppercase tracking-[1px] text-[#8B92A3] mb-1 font-medium">Asset Focus</div>
                <div className="flex flex-wrap gap-1.5 min-h-[18px]">
                  {(() => {
                    const assets = assetTypesSafe.filter((t: string) => !/creative|seller finance|cash|hedge/i.test(t));

                    const normalize = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
                    const iconMap: Record<string, any> = {
                      'SFH': Home, 'Single Family': Home, 'SingleFamily': Home,
                      'Multifamily': Building2, 'Multi Family': Building2,
                      'Small Multifamily': Building2, 'SmallMulti': Building2,
                      'MHP': Warehouse, 'Mobile Home': Warehouse,
                      'Hotel': Hotel,
                      'Retail': Store,
                      'Storage': Warehouse, 'Self Storage': Warehouse,
                      'Land': MapPin,
                      'Mixed Use': Building2, 'Mixed-Use': Building2, 'MixedUse': Building2,
                      'Commercial': Building,
                      'Value-Add': TrendingUp, 'Value Add': TrendingUp, 'ValueAdd': TrendingUp,
                      'Fix & Flip': Flame, 'Fix and Flip': Flame, 'FixFlip': Flame,
                    };
                    const emojiMap: Record<string, string> = {
                      'SFH': '🏠', 'Single Family': '🏠',
                      'Multifamily': '🏢', 'Small Multifamily': '🏘️',
                      'MHP': '🚐', 'Hotel': '🏨', 'Retail': '🏬', 'Storage': '📦',
                      'Land': '🗺️', 'Mixed Use': '🏗️', 'Commercial': '🏢',
                      'Value-Add': '📈', 'Fix & Flip': '🔥'
                    };

                    const getAssetStyle = (t: string) => {
                      const k = normalize(t);
                      if (k.startsWith('sf') || k.includes('single')) return 'bg-blue-500/15 text-blue-300 ring-1 ring-blue-400/30';
                      if (k.includes('smallmulti') || k.includes('smallmf')) return 'bg-indigo-500/15 text-indigo-300 ring-1 ring-indigo-400/30';
                      if (k.includes('multi')) return 'bg-purple-500/15 text-purple-300 ring-1 ring-purple-400/30';
                      if (k === 'mhp' || k.includes('mobile')) return 'bg-teal-500/15 text-teal-300 ring-1 ring-teal-400/30';
                      if (k.includes('hotel')) return 'bg-pink-500/15 text-pink-300 ring-1 ring-pink-400/30';
                      if (k.includes('retail')) return 'bg-orange-500/15 text-orange-300 ring-1 ring-orange-400/30';
                      if (k.includes('storage')) return 'bg-cyan-500/15 text-cyan-300 ring-1 ring-cyan-400/30';
                      if (k.includes('land')) return 'bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30';
                      if (k.includes('mixed')) return 'bg-violet-500/15 text-violet-300 ring-1 ring-violet-400/30';
                      if (k.includes('commercial')) return 'bg-slate-400/15 text-slate-300 ring-1 ring-slate-400/30';
                      if (k.includes('value')) return 'bg-amber-500/15 text-amber-300 ring-1 ring-amber-400/30';
                      if (k.includes('fix') || k.includes('flip')) return 'bg-red-500/15 text-red-300 ring-1 ring-red-400/30';
                      return 'bg-[#1F2937] text-[#CBD5E1] ring-1 ring-[#334155]';
                    };
                    const getIconFor = (t: string) => {
                      const k = normalize(t);
                      if (k.startsWith('sf') || k.includes('single')) return Home;
                      if (k.includes('multi')) return Building2;
                      if (k === 'mhp' || k.includes('mobile')) return Warehouse;
                      if (k.includes('hotel')) return Hotel;
                      if (k.includes('retail')) return Store;
                      if (k.includes('storage')) return Warehouse;
                      if (k.includes('land')) return MapPin;
                      if (k.includes('mixed')) return Building2;
                      if (k.includes('commercial')) return Building;
                      if (k.includes('value')) return TrendingUp;
                      if (k.includes('fix') || k.includes('flip')) return Flame;
                      return Landmark;
                    };

                    return (
                      <>
                        {assets.map((t: string, i: number) => {
                          const IconComp = getIconFor(t) || iconMap[t];
                          const style = getAssetStyle(t);
                          const label = t.length > 14 ? t.slice(0, 12) + '…' : t;
                          return (
                            <span
                              key={i}
                              className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-medium border ${style}`}
                              title={t}
                            >
                              {IconComp ? <IconComp size={13} /> : (emojiMap[t] || '📦')}
                              <span>{label}</span>
                            </span>
                          );
                        })}
                      </>
                    );
                  })()}
                </div>
              </div>

              {/* STRATEGY — up to 3 rows (collapse only on 4th row) */}
              <div className="mt-3">
                <div className="text-[10px] uppercase tracking-[1px] text-[#8B92A3] mb-1 font-medium">Strategy</div>
                <div className="flex flex-wrap gap-1.5 min-h-[18px]">
                  {hasCreative && (
                    <span className="badge bg-emerald-500/25 text-emerald-100 ring-1 ring-emerald-400 shadow-[0_0_5px_rgba(52,211,153,0.35)] text-[10px] px-2 py-0.5 flex items-center gap-1 font-semibold border border-emerald-400/30">
                      <Star size={11} className="text-emerald-300" /> Creative Only
                    </span>
                  )}
                  {b.sellerFinance && <span className="badge bg-amber-400/20 text-amber-200 ring-1 ring-amber-300 text-[10px] px-1.5 py-0.5 flex items-center gap-1 border border-amber-300/30">Seller Finance</span>}
                  {isCash && <span className="badge bg-blue-500/20 text-blue-200 ring-1 ring-blue-400/50 text-[10px] px-1.5 py-0.5 flex items-center gap-1 border border-blue-400/30">Cash Buyer</span>}
                  {((b.type ?? '').toLowerCase().includes('hedge')) && <span className="badge bg-purple-600/20 text-purple-200 ring-1 ring-purple-500/60 text-[10px] px-1.5 py-0.5 flex items-center gap-1 border border-purple-500/30">Hedge Fund</span>}
                  {((b.markets ?? []).includes('Nationwide')) && <span className="badge bg-[#1F2937] text-[#94A3B8] text-[10px] px-1.5 py-0.5 flex items-center gap-1 border border-[#334155]">Nationwide</span>}
                </div>
              </div>

              {/* BUDGET — polished centered green bar */}
              <div className="mt-auto">
                <div className="mt-3">
                  <div className="w-full rounded-xl bg-emerald-500/10 border border-emerald-900/50 px-4 py-2.5 text-center">
                    <div className="text-[10px] uppercase tracking-[1px] text-emerald-400/70 mb-0.5">Budget</div>
                    <div className="text-base font-semibold text-[#22C55E]">
                      {formatBudget(b.budgetMin, b.budgetMax)}
                    </div>
                  </div>
                </div>

                {/* HEAT / STR — glowing pills below budget */}
                <div className="mt-3 flex items-center gap-2">
                  <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 ring-1 ring-emerald-400/40 shadow-[0_0_4px_rgba(52,211,153,0.2)]">Heat {heatScore}</span>
                  <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 ring-1 ring-emerald-400/40 shadow-[0_0_4px_rgba(52,211,153,0.2)]">STR {strScore}</span>
                </div>

                {/* ACTIONS — full width at bottom */}
                <div className="mt-3 pt-3">
                <button
                  onClick={(e) => { e.stopPropagation(); markBuyerViewed(b.id); setSelectedBuyer(b); setEditBuyer({...b}); }}
                  className="btn btn-ghost text-xs w-full py-2"
                >
                  Review &amp; Edit Profile
                </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      )}

      {currentListId && (
        <div className="mb-2 text-xs bg-[#171B26] p-2 rounded flex items-center justify-between">
          Viewing list: <strong>{buyerLists.find(l => l.id === currentListId)?.name}</strong>
          <button onClick={() => setCurrentListId(null)} className="btn btn-ghost text-xs px-2 py-0.5">Show All</button>
        </div>
      )}
      {filtered.length === 0 && <div className="empty-state text-[#8B92A3]">No buyers match your search.</div>}

      {/* Buyer Segments - only in segments tab */}
      {activeTab === 'segments' && (
      <div className="mt-8">
        <div className="font-medium mb-3 flex items-center justify-between">
          <span>Saved Buyer Segments</span>
          {selectedSegment && <button onClick={() => setSelectedSegment(null)} className="btn btn-ghost text-xs">Show All Segments</button>}
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
          {[
            { name: 'Alabama Buyers', filter: (b: any) => (b.markets ?? []).some((m: string) => m.includes('AL')) },
            { name: 'Nationwide Buyers', filter: (b: any) => (b.markets ?? []).some((m: string) => ['Nationwide','Any'].includes(m)) },
            { name: 'Creative Finance Buyers', filter: (b: any) => b.creativeFinance || b.sellerFinance },
            { name: 'Seller Finance Buyers', filter: (b: any) => b.sellerFinance },
            { name: 'Cash Buyers', filter: (b: any) => !b.creativeFinance && !b.sellerFinance },
            { name: 'Hot Buyers', filter: (b: any) => b.status === 'Hot' },
            { name: 'High Budget Buyers', filter: (b: any) => (b.budgetMax || 0) >= 1000000 },
            { name: 'Multifamily Buyers', filter: (b: any) => (b.assetTypes ?? []).includes('Multifamily') },
          ].map(seg => {
            const count = buyers.filter(seg.filter).length
            return (
              <div key={seg.name} className="card p-3">
                <div className="flex justify-between">
                  <div>{seg.name}</div>
                  <div className="text-[#22C55E]">{count}</div>
                </div>
                <button onClick={() => {
                  const list = buyers.filter(seg.filter).map(b => b.email).join(', ')
                  navigator.clipboard.writeText(list)
                  toast.success(`${count} emails copied for ${seg.name}`)
                }} className="btn btn-ghost text-xs mt-2">Copy Gmail BCC</button>
                <button onClick={() => setSelectedSegment(seg.name)} className="btn btn-ghost text-xs mt-2">View Buyers</button>
              </div>
            )
          })}
        </div>
        <div className="text-xs text-[#8B92A3] mt-2">Segments auto-update. Use in Blast Builder by filtering buyers first.</div>
      </div>
      )}

      {/* Buyer Custom Lists - only in lists tab */}
      {activeTab === 'lists' && (
      <div className="mt-8">
        <div className="font-medium mb-3 flex items-center justify-between">
          <span>Buyer Lists</span>
          <button onClick={() => { setCurrentListId(null); }} className="btn btn-ghost text-xs">Show All Buyers</button>
        </div>
        {buyerLists.length === 0 ? (
          <div className="text-xs text-[#8B92A3]">No custom lists yet. Select buyers and use "Add to List".</div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
            {buyerLists.map(list => (
              <div key={list.id} className="card p-3">
                <div className="font-medium">{list.name}</div>
                <div className="text-xs text-[#8B92A3]">{(list.buyerIds || []).length} buyers • {new Date(list.createdAt).toLocaleDateString()}</div>
                {list.description && <div className="text-xs mt-1">{list.description}</div>}
                <div className="flex flex-wrap gap-2 mt-2 text-xs">
                  <button onClick={() => {
                    const emails = buyers.filter(b => (list.buyerIds || []).includes(b.id)).map(b => b.email).join(', ');
                    navigator.clipboard.writeText(emails);
                    toast.success(`BCC copied for ${list.name}`);
                  }} className="btn btn-ghost px-2 py-0.5">Copy BCC</button>
                  <button onClick={() => setCurrentListId(list.id)} className="btn btn-ghost px-2 py-0.5">View List</button>
                  <button onClick={() => {
                    if (confirm(`Delete list "${list.name}"?`)) {
                      setBuyerLists(prev => prev.filter(l => l.id !== list.id));
                      if (currentListId === list.id) setCurrentListId(null);
                    }
                  }} className="btn btn-ghost px-2 py-0.5 text-red-400">Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      )}

      {/* Buyer Profile Drawer - Upgraded Flow-style Intelligence Profile */}
      {selectedBuyer && (
        <div className="fixed inset-0 bg-black/70 z-[200] flex items-center justify-center p-4" onClick={() => setSelectedBuyer(null)}>
          <div className="card w-full max-w-4xl max-h-[92vh] overflow-auto p-6" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between mb-4">
              <div>
                <div className="text-2xl font-semibold">{editBuyer.name || selectedBuyer.name}</div>
                <div className="text-[#3B82F6]">{editBuyer.email || selectedBuyer.email}</div>
                <div className="text-xs mt-0.5 flex gap-3">
                  <span className="text-[#22C55E]">Heat: {useAppStore.getState().getBuyerHeatScore?.(selectedBuyer.id) ?? '—'}</span>
                  <span>STR: {editBuyer.strengthScore || 65}</span>
                  <span className="text-amber-400">Status: {editBuyer.status || selectedBuyer.status}</span>
                </div>
                {/* Member of Lists */}
                {(() => {
                  const memberLists = buyerLists.filter(l => (l.buyerIds || []).includes(selectedBuyer.id));
                  if (memberLists.length === 0) return null;
                  return (
                    <div className="text-xs mt-1 text-[#8B92A3]">Member of: {memberLists.map(l => l.name).join(', ')}</div>
                  );
                })()}
              </div>
              <button onClick={() => setSelectedBuyer(null)}><X size={20} /></button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-sm">
              {/* A. Core Information */}
              <div>
                <div className="font-semibold mb-2 text-base">Core Information</div>
                <div className="grid grid-cols-1 gap-2">
                  <div><div className="text-xs text-[#8B92A3]">Company / Entity</div><input className="input" value={editBuyer.company || ''} onChange={e => setEditBuyer({...editBuyer, company: e.target.value})} placeholder="Company Missing" /></div>
                  <div className="grid grid-cols-2 gap-2">
                    <div><div className="text-xs text-[#8B92A3]">Phone</div><input className="input" value={editBuyer.phone || ''} onChange={e => setEditBuyer({...editBuyer, phone: e.target.value})} placeholder="Phone Missing" /></div>
                    <div><div className="text-xs text-[#8B92A3]">Mobile</div><input className="input" value={editBuyer.mobile || ''} onChange={e => setEditBuyer({...editBuyer, mobile: e.target.value})} /></div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div><div className="text-xs text-[#8B92A3]">Buyer Type</div><input className="input" value={editBuyer.type || ''} onChange={e => setEditBuyer({...editBuyer, type: e.target.value})} /></div>
                    <div><div className="text-xs text-[#8B92A3]">Status</div>
                      <select className="select" value={editBuyer.status || 'Active'} onChange={e => setEditBuyer({...editBuyer, status: e.target.value})}>
                        <option>Active</option><option>Hot</option><option>New</option><option>Inactive</option>
                      </select>
                    </div>
                  </div>
                  <div><div className="text-xs text-[#8B92A3]">Lead Source / Channel</div><input className="input" value={editBuyer.leadSource || ''} onChange={e => setEditBuyer({...editBuyer, leadSource: e.target.value})} /></div>
                  <div><div className="text-xs text-[#8B92A3]">Notes / Buy Box Summary</div><textarea className="input h-20" value={editBuyer.notes || ''} onChange={e => setEditBuyer({...editBuyer, notes: e.target.value})} /></div>
                </div>
              </div>

              {/* B. Buy Box & Criteria */}
              <div>
                <div className="font-semibold mb-2 text-base">Buy Box & Criteria</div>
                <div className="grid grid-cols-2 gap-2">
                  <div><div className="text-xs text-[#8B92A3]">Budget Min</div><input className="input" type="number" value={editBuyer.budgetMin || ''} onChange={e => setEditBuyer({...editBuyer, budgetMin: parseInt(e.target.value)||0})} /></div>
                  <div><div className="text-xs text-[#8B92A3]">Budget Max</div><input className="input" type="number" value={editBuyer.budgetMax || ''} onChange={e => setEditBuyer({...editBuyer, budgetMax: parseInt(e.target.value)||0})} /></div>
                </div>
                <div className="mt-1 text-center text-sm font-medium text-[#22C55E]">
                  {formatBudget(editBuyer.budgetMin, editBuyer.budgetMax)}
                </div>
                <div className="mt-2 flex flex-wrap gap-2 text-xs">
                  <label className="flex items-center gap-1"><input type="checkbox" checked={!!editBuyer.creativeFinance} onChange={e => setEditBuyer({...editBuyer, creativeFinance: e.target.checked})} /> Creative Only</label>
                  <label className="flex items-center gap-1"><input type="checkbox" checked={!!editBuyer.sellerFinance} onChange={e => setEditBuyer({...editBuyer, sellerFinance: e.target.checked})} /> Seller Finance</label>
                  <label className="flex items-center gap-1"><input type="checkbox" checked={!!editBuyer.cashBuyer} onChange={e => setEditBuyer({...editBuyer, cashBuyer: e.target.checked})} /> Cash Buyer</label>
                  <label className="flex items-center gap-1"><input type="checkbox" checked={!!editBuyer.nationwide} onChange={e => setEditBuyer({...editBuyer, nationwide: e.target.checked})} /> Nationwide</label>
                </div>
              </div>

              {/* C. Target States - All 50 + Nationwide/Any */}
              <div className="lg:col-span-2">
                <div className="font-semibold mb-1.5 text-base">Target States</div>
                <div className="flex flex-wrap gap-1 text-[10px]">
                  {['Any','Nationwide','AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY'].map(st => {
                    const active = (editBuyer.markets || []).includes(st);
                    return <button key={st} type="button" onClick={() => {
                      const cur = editBuyer.markets || [];
                      const next = active ? cur.filter((x:string) => x !== st) : [...cur, st];
                      setEditBuyer({...editBuyer, markets: next});
                    }} className={`px-2 py-0.5 rounded border ${active ? 'bg-[#22C55E] text-black border-[#22C55E]' : 'bg-[#171B26] border-[#252A38] hover:border-[#3B82F6]'}`}>{st}</button>;
                  })}
                </div>
              </div>

              {/* D. Asset Focus */}
              <div className="lg:col-span-2">
                <div className="font-semibold mb-1.5 text-base">Asset Focus</div>
                <div className="flex flex-wrap gap-1 text-[10px]">
                  {['SFH','Multifamily','MHP','Hotel','Retail','Storage','Land','Mixed-Use','Commercial','Any'].map(t => {
                    const active = (editBuyer.assetTypes || []).includes(t);
                    return <button key={t} type="button" onClick={() => {
                      const cur = editBuyer.assetTypes || [];
                      const next = active ? cur.filter((x:string)=>x!==t) : [...cur, t];
                      setEditBuyer({...editBuyer, assetTypes: next});
                    }} className={`px-2 py-0.5 rounded border ${active ? 'bg-[#22C55E] text-black border-[#22C55E]' : 'bg-[#171B26] border-[#252A38] hover:border-[#3B82F6]'}`}>{t}</button>;
                  })}
                </div>
              </div>
            </div>

            {/* Match History */}
            <div className="mt-5">
              <div className="font-medium text-sm mb-2">Match History</div>
              <div className="space-y-1 text-xs max-h-48 overflow-auto">
                {getBuyerMatchHistory(selectedBuyer.id).length === 0 && <div className="text-[#8B92A3]">No match history yet.</div>}
                {getBuyerMatchHistory(selectedBuyer.id).slice(0, 6).map((h: any, idx: number) => (
                  <div key={idx} className="panel p-2 flex justify-between text-[10px]">
                    <span onClick={() => { setSelectedBuyer(null); useAppStore.getState().safeOpenDeal(h.deal.id); }} className="cursor-pointer hover:text-[#3B82F6]">{h.deal.property.address}</span>
                    <span className="text-[#22C55E]">{h.score}%</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-2 mt-5 pt-4 border-t border-[#252A38]">
              <button onClick={() => { updateBuyer(selectedBuyer.id, editBuyer); setSelectedBuyer(editBuyer); toast.success('Buyer updated'); }} className="btn btn-primary">Save Changes</button>
              <button onClick={() => { updateBuyer(selectedBuyer.id, { status: 'Hot' }); toast.success('Marked Hot'); }} className="btn btn-ghost">Mark Hot</button>
              <button onClick={() => { if (confirm(`Suppress ${selectedBuyer.name}?`)) { addToSuppression(selectedBuyer.email); toast.success('Suppressed'); } }} className="btn btn-ghost text-amber-400">Suppress</button>
              <button onClick={() => { if (confirm('Delete buyer?')) { setSelectedBuyer(null); toast('Deleted (demo)'); } }} className="btn btn-ghost text-red-400">Delete</button>
              <button onClick={() => { setShowListModal(true); }} className="btn btn-ghost text-[#22C55E]">Add to List</button>
              <button onClick={() => setSelectedBuyer(null)} className="btn btn-ghost ml-auto">Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Buyer Custom Lists Modal */}
      {showListModal && (
        <div className="fixed inset-0 bg-black/70 z-[300] flex items-center justify-center p-4" onClick={() => { setShowListModal(false); setNewListName(''); }}>
          <div className="card w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="text-lg font-semibold mb-4">Add to Buyer List</div>

            {buyerLists.length > 0 && (
              <div className="mb-4">
                <div className="text-xs text-[#8B92A3] mb-1">Existing Lists</div>
                {buyerLists.map(list => (
                  <button key={list.id} onClick={() => {
                    const idsToAdd = selectedBuyer ? [selectedBuyer.id] : selectedBuyerIds;
                    const updated = buyerLists.map(l => l.id === list.id ? { ...l, buyerIds: Array.from(new Set([...(l.buyerIds || []), ...idsToAdd])) , updatedAt: Date.now() } : l);
                    setBuyerLists(updated);
                    setShowListModal(false);
                    setSelectedBuyerIds([]);
                    toast.success(`Added to ${list.name}`);
                  }} className="w-full text-left btn btn-ghost px-3 py-1 mb-1 text-sm border border-[#252A38]">
                    {list.name} <span className="text-[#8B92A3] text-xs">({(list.buyerIds || []).length})</span>
                  </button>
                ))}
              </div>
            )}

            <div className="border-t border-[#252A38] pt-4">
              <div className="text-xs text-[#8B92A3] mb-1">Create New List</div>
              <input className="input mb-2" placeholder="List name (e.g. Alabama Buyers)" value={newListName} onChange={e => setNewListName(e.target.value)} />
              <button onClick={() => {
                if (!newListName.trim()) return;
                const newList = {
                  id: 'list_' + Date.now(),
                  name: newListName.trim(),
                  description: '',
                  buyerIds: selectedBuyer ? [selectedBuyer.id] : selectedBuyerIds,
                  tags: [],
                  createdAt: Date.now(),
                  updatedAt: Date.now()
                };
                setBuyerLists([...buyerLists, newList]);
                setShowListModal(false);
                setNewListName('');
                setSelectedBuyerIds([]);
                toast.success(`Created list "${newListName}" and added buyers`);
              }} className="btn btn-primary w-full" disabled={!newListName.trim()}>Create & Add</button>
            </div>

            <button onClick={() => { setShowListModal(false); setNewListName(''); }} className="btn btn-ghost w-full mt-3">Cancel</button>
          </div>
        </div>
      )}

      {/* IMPORT MODAL - Review screen before any store write. Supports repeat uploads. */}
      {showImport && (
        <div className="fixed inset-0 bg-black/70 z-[200] flex items-center justify-center p-4">
          <div className="card w-full max-w-4xl max-h-[92vh] overflow-auto p-6">
            <div className="flex justify-between mb-4">
              <div className="font-semibold text-lg">Import Buyers — Review & Approve</div>
              <button onClick={() => { setShowImport(false); setPendingImport([]); setImportResult(null) }}><X /></button>
            </div>

            {pendingImport.length === 0 && !importResult && (
              <div className="border border-dashed border-[#252A38] rounded-xl p-8 text-center">
                <Upload className="mx-auto mb-3" />
                <div className="mb-2">Drop or click to upload CSV/TXT</div>
                <div className="text-xs text-[#8B92A3] mb-4">Multiple uploads allowed. Review, edit, remove, merge dups, then approve.</div>
                <input type="file" accept=".csv,.txt" onChange={e => e.target.files && handleFile(e.target.files[0])} className="hidden" id="csv-upload" />
                <label htmlFor="csv-upload" className="btn btn-primary cursor-pointer">Choose File</label>
                <div className="text-[10px] text-[#8B92A3] mt-3">Columns auto-mapped: Email/Name/Markets/Property_Types/Budget/Finance_Type etc.</div>
              </div>
            )}

            {/* REVIEW SCREEN: edit/remove/merge/approve selected/all/skip invalid */}
            {pendingImport.length > 0 && (
              <>
                <div className="flex items-center justify-between mb-3">
                  <div className="text-sm font-medium">{pendingImport.length} rows ready for review • {pendingImport.filter(r => r._dup).length} dups detected</div>
                  <div className="flex gap-2 text-xs">
                    <button onClick={() => setPendingImport([])} className="btn btn-ghost px-3 py-1">Clear All</button>
                    <button onClick={skipInvalid} className="btn btn-ghost px-3 py-1">Skip Dups &amp; Invalid</button>
                    <button onClick={approveAllValid} className="btn btn-green px-3 py-1">Approve All Valid</button>
                  </div>
                </div>

                <div className="text-xs max-h-[420px] overflow-auto border border-[#252A38] rounded">
                  {pendingImport.map((row, _idx) => (
                    <div key={row._id} className="grid grid-cols-12 gap-2 px-3 py-2 border-b border-[#252A38] items-center text-xs">
                      <div className="col-span-3">
                        <input className="input text-xs py-0.5" value={row.name} onChange={e => updatePendingRow(row._id, {name: e.target.value})} />
                        <div className="text-[#3B82F6] truncate">{row.email}</div>
                      </div>
                      <div className="col-span-2">
                        <input className="input text-xs py-0.5" value={row.markets?.join(', ')} onChange={e => updatePendingRow(row._id, {markets: e.target.value.split(',').map((s:string)=>s.trim()).filter(Boolean)})} />
                      </div>
                      <div className="col-span-2 text-[10px] text-[#8B92A3]">{row.assetTypes?.join(', ')}</div>
                      <div className="col-span-2 text-[#22C55E] text-[10px]">{formatBudget(row.budgetMin, row.budgetMax)}</div>
                      <div className="col-span-3 flex gap-1 items-center">
                        {row._dup && <span className="text-amber-400">DUP</span>}
                        <button onClick={() => updatePendingRow(row._id, { _valid: !(row._valid === false) })} className="btn btn-ghost px-1 py-0 text-[10px]">{row._valid === false ? 'Mark Valid' : 'Valid'}</button>
                        <button onClick={() => toggleMergePending(row._id)} className="btn btn-ghost px-1 py-0 text-[10px] text-amber-400">{row._merge ? 'Unmerge' : 'Merge Dup'}</button>
                        <button onClick={() => removePendingRow(row._id)} className="text-red-400 px-1">Remove</button>
                        <button onClick={() => updatePendingRow(row._id, {status: row.status === 'Hot' ? 'Active' : 'Hot'})} className="btn btn-ghost px-1 py-0 text-[10px]">Hot</button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2 mt-4">
                  <button onClick={approveSelected} className="btn btn-green flex-1">Approve Selected / All Valid Buyers</button>
                  <button onClick={() => { setPendingImport([]); setShowImport(false) }} className="btn btn-ghost flex-1">Cancel &amp; Close (no import)</button>
                </div>
                <div className="text-[10px] text-[#8B92A3] mt-2">Repeat uploads allowed. Only approved rows are written to the buyer database.</div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
